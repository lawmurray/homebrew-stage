namespace birch {
#line 3 "src/SQLite3.birch"
SQLite3_::SQLite3_() :
    #line 3 "src/SQLite3.birch"
    base_type_() {
  //
}

#line 16 "src/SQLite3.birch"
void SQLite3_::open(const String& filename) {
  #line 17 "src/SQLite3.birch"

    assert(!this->db);
    auto res = sqlite3_open(filename.c_str(), &this->db);
    if (res != SQLITE_OK) {
      birch::error("sqlite3_open failed");
    }
    }

#line 29 "src/SQLite3.birch"
void SQLite3_::close() {
  #line 30 "src/SQLite3.birch"

    auto res = sqlite3_close(this->db);
    if (res != SQLITE_OK) {
      birch::error("sqlite3_close failed");
    }
    this->db = nullptr;
    }

#line 42 "src/SQLite3.birch"
SQLite3Statement SQLite3_::prepare(const String& sql) {
  SQLite3Statement stmt;
  #line 44 "src/SQLite3.birch"

    auto res = sqlite3_prepare_v2(this->db, sql.c_str(), sql.length(), &stmt->stmt, nullptr);
    if (res != SQLITE_OK) {
      birch::error("sqlite3_prepare_v2 failed");
    }
      #line 50 "src/SQLite3.birch"
  return stmt;
}

#line 56 "src/SQLite3.birch"
void SQLite3_::exec(const String& sql) {
  #line 57 "src/SQLite3.birch"

    auto res = sqlite3_exec(this->db, sql.c_str(), nullptr, nullptr, nullptr);
    if (res != SQLITE_OK) {
      birch::error("sqlite3_exec failed");
    }
    }

#line 3 "src/SQLite3.birch"
Object_* make_SQLite3_() {
  #line 3 "src/SQLite3.birch"
  return new SQLite3_();
  #line 3 "src/SQLite3.birch"
}
static int register_factory_SQLite3_ = ::register_factory("SQLite3", make_SQLite3_);

}
namespace birch {
#line 1 "src/SQLite3Statement.birch"
SQLite3Statement_::SQLite3Statement_() :
    #line 1 "src/SQLite3Statement.birch"
    base_type_() {
  //
}

#line 15 "src/SQLite3Statement.birch"
void SQLite3Statement_::bind(const Integer& i, const Integer& x) {
  #line 16 "src/SQLite3Statement.birch"

    auto res = sqlite3_bind_int(this->stmt, i, x);
    if (res != SQLITE_OK) {
      birch::error("sqlite3_bind_int failed");
    }
    }

#line 30 "src/SQLite3Statement.birch"
void SQLite3Statement_::bind(const Integer& i, const Real& x) {
  #line 31 "src/SQLite3Statement.birch"

    auto res = sqlite3_bind_double(this->stmt, i, x);
    if (res != SQLITE_OK) {
      birch::error("sqlite3_bind_double failed");
    }
    }

#line 45 "src/SQLite3Statement.birch"
void SQLite3Statement_::bind(const Integer& i, const String& x) {
  #line 46 "src/SQLite3Statement.birch"

    auto res = sqlite3_bind_text(this->stmt, i, x.c_str(), x.length(),
        SQLITE_TRANSIENT);
    if (res != SQLITE_OK) {
      birch::error("sqlite3_bind_text failed");
    }
    }

#line 60 "src/SQLite3Statement.birch"
void SQLite3Statement_::bindNull(const Integer& i) {
  #line 61 "src/SQLite3Statement.birch"

    auto res = sqlite3_bind_null(this->stmt, i);
    if (res != SQLITE_OK) {
      birch::error("sqlite3_bind_null failed");
    }
    }

#line 83 "src/SQLite3Statement.birch"
Boolean SQLite3Statement_::step() {
  #line 84 "src/SQLite3Statement.birch"

    auto res = sqlite3_step(this->stmt);
    if (res != SQLITE_ROW && res != SQLITE_DONE) {
      birch::error("sqlite3_step failed");
    }
    return (res == SQLITE_ROW);
    }

#line 96 "src/SQLite3Statement.birch"
Integer SQLite3Statement_::columnCount() {
  #line 97 "src/SQLite3Statement.birch"

    return sqlite3_column_count(this->stmt);
    }

#line 109 "src/SQLite3Statement.birch"
std::optional<Integer> SQLite3Statement_::columnInteger(const Integer& i) {
  #line 110 "src/SQLite3Statement.birch"

    if (sqlite3_column_type(this->stmt, i - 1) == SQLITE_INTEGER) {
      return (Integer)sqlite3_column_int64(this->stmt, i - 1);
    }
      #line 115 "src/SQLite3Statement.birch"
  return std::nullopt;
}

#line 125 "src/SQLite3Statement.birch"
std::optional<Real> SQLite3Statement_::columnReal(const Integer& i) {
  #line 126 "src/SQLite3Statement.birch"

    if (sqlite3_column_type(this->stmt, i - 1) == SQLITE_FLOAT) {
      return sqlite3_column_double(this->stmt, i - 1);
    }
      #line 131 "src/SQLite3Statement.birch"
  return birch::optional_cast<Real>(columnInteger(i));
}

#line 141 "src/SQLite3Statement.birch"
std::optional<String> SQLite3Statement_::columnString(const Integer& i) {
  #line 142 "src/SQLite3Statement.birch"

    if (sqlite3_column_type(this->stmt, i - 1) == SQLITE_TEXT) {
      return std::string(reinterpret_cast<const char*>(sqlite3_column_text(this->stmt, i - 1)));
    }
      #line 147 "src/SQLite3Statement.birch"
  return std::nullopt;
}

#line 155 "src/SQLite3Statement.birch"
Boolean SQLite3Statement_::columnNull(const Integer& i) {
  #line 156 "src/SQLite3Statement.birch"

    return sqlite3_column_type(this->stmt, i - 1) == SQLITE_NULL;
    }

#line 164 "src/SQLite3Statement.birch"
void SQLite3Statement_::reset() {
  #line 165 "src/SQLite3Statement.birch"

    auto res = sqlite3_reset(this->stmt);
    if (res != SQLITE_OK) {
      birch::error("sqlite3_reset failed");
    }
    }

#line 176 "src/SQLite3Statement.birch"
void SQLite3Statement_::finalize() {
  #line 177 "src/SQLite3Statement.birch"

    auto res = sqlite3_finalize(this->stmt);
    if (res != SQLITE_OK) {
      birch::error("sqlite3_finalize failed");
    }
    }

#line 1 "src/SQLite3Statement.birch"
Object_* make_SQLite3Statement_() {
  #line 1 "src/SQLite3Statement.birch"
  return new SQLite3Statement_();
  #line 1 "src/SQLite3Statement.birch"
}
static int register_factory_SQLite3Statement_ = ::register_factory("SQLite3Statement", make_SQLite3Statement_);

}
