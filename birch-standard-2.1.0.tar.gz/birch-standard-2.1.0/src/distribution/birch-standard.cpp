namespace birch {
#line 7 "src/distribution/AddDiscreteConstrainedDistribution.birch"
AddDiscreteConstrainedDistribution_::AddDiscreteConstrainedDistribution_(const numbirch::Array<Real,1>& p, const Integer& l, const Integer& y) :
    #line 7 "src/distribution/AddDiscreteConstrainedDistribution.birch"
    base_type_(),
    #line 12 "src/distribution/AddDiscreteConstrainedDistribution.birch"
    p(p),
    #line 17 "src/distribution/AddDiscreteConstrainedDistribution.birch"
    l(l),
    #line 22 "src/distribution/AddDiscreteConstrainedDistribution.birch"
    y(y) {
  //
}

#line 24 "src/distribution/AddDiscreteConstrainedDistribution.birch"
numbirch::Future<Integer> AddDiscreteConstrainedDistribution_::simulate() {
  #line 25 "src/distribution/AddDiscreteConstrainedDistribution.birch"
  return simulate_categorical(p) + l - 1;
}

#line 28 "src/distribution/AddDiscreteConstrainedDistribution.birch"
numbirch::Future<Real> AddDiscreteConstrainedDistribution_::logpdf(const numbirch::Future<Integer>& x) {
  #line 29 "src/distribution/AddDiscreteConstrainedDistribution.birch"
  return logpdf_categorical(x - l + 1, p);
}

#line 32 "src/distribution/AddDiscreteConstrainedDistribution.birch"
std::optional<Delay> AddDiscreteConstrainedDistribution_::update(const numbirch::Future<Integer>& x) {
  #line 33 "src/distribution/AddDiscreteConstrainedDistribution.birch"
  return Delta(y - x);
}

#line 36 "src/distribution/AddDiscreteConstrainedDistribution.birch"
std::optional<numbirch::Future<Integer>> AddDiscreteConstrainedDistribution_::lower() {
  #line 37 "src/distribution/AddDiscreteConstrainedDistribution.birch"
  return l;
}

#line 40 "src/distribution/AddDiscreteConstrainedDistribution.birch"
std::optional<numbirch::Future<Integer>> AddDiscreteConstrainedDistribution_::upper() {
  #line 41 "src/distribution/AddDiscreteConstrainedDistribution.birch"
  return l + length(p) - 1;
}

}
namespace birch {
#line 4 "src/distribution/AddDiscreteDeltaDistribution.birch"
AddDiscreteDeltaDistribution_::AddDiscreteDeltaDistribution_(const BoundedDiscreteDistribution& p, const BoundedDiscreteDistribution& q) :
    #line 4 "src/distribution/AddDiscreteDeltaDistribution.birch"
    base_type_(),
    #line 9 "src/distribution/AddDiscreteDeltaDistribution.birch"
    p(p),
    #line 14 "src/distribution/AddDiscreteDeltaDistribution.birch"
    q(q),
    #line 19 "src/distribution/AddDiscreteDeltaDistribution.birch"
    x(),
    #line 24 "src/distribution/AddDiscreteDeltaDistribution.birch"
    l(0),
    #line 29 "src/distribution/AddDiscreteDeltaDistribution.birch"
    u(0),
    #line 35 "src/distribution/AddDiscreteDeltaDistribution.birch"
    z(),
    #line 40 "src/distribution/AddDiscreteDeltaDistribution.birch"
    Z(Real(0.0)) {
  //
}

#line 42 "src/distribution/AddDiscreteDeltaDistribution.birch"
void AddDiscreteDeltaDistribution_::enumerate(const numbirch::Future<Integer>& x) {
  #line 43 "src/distribution/AddDiscreteDeltaDistribution.birch"
  if (!((bool(this->x))) || (*(this->x)) != (*(x))) {
    #line 44 "src/distribution/AddDiscreteDeltaDistribution.birch"
    l = max((*((*(p->lower())))), (*(x)) - (*((*(q->upper())))));
    #line 45 "src/distribution/AddDiscreteDeltaDistribution.birch"
    u = min((*((*(p->upper())))), (*(x)) - (*((*(q->lower())))));
    #line 46 "src/distribution/AddDiscreteDeltaDistribution.birch"
    if (l <= u) {
      #line 48 "src/distribution/AddDiscreteDeltaDistribution.birch"
      z = vector_lambda([=](const Integer& i) {
        auto n = l + i - 1;
        #line 50 "src/distribution/AddDiscreteDeltaDistribution.birch"
        return (*(p->logpdf(n))) + (*(q->logpdf((*(x)) - n)));
      }, u - l + 1);
      #line 52 "src/distribution/AddDiscreteDeltaDistribution.birch"
      Z = log_sum_exp(z);
      #line 53 "src/distribution/AddDiscreteDeltaDistribution.birch"
      z = norm_exp(z);
    } else {
      #line 55 "src/distribution/AddDiscreteDeltaDistribution.birch"
      Z = -(std::numeric_limits<Real>::infinity());
      #line 56 "src/distribution/AddDiscreteDeltaDistribution.birch"
      z = vector(Real(0.0), 0);
    }
    #line 58 "src/distribution/AddDiscreteDeltaDistribution.birch"
    this->x = (*(x));
  }
}

#line 62 "src/distribution/AddDiscreteDeltaDistribution.birch"
numbirch::Future<Integer> AddDiscreteDeltaDistribution_::simulate() {
  #line 63 "src/distribution/AddDiscreteDeltaDistribution.birch"
  return p->simulate() + q->simulate();
}

#line 66 "src/distribution/AddDiscreteDeltaDistribution.birch"
numbirch::Future<Real> AddDiscreteDeltaDistribution_::logpdf(const numbirch::Future<Integer>& x) {
  #line 67 "src/distribution/AddDiscreteDeltaDistribution.birch"
  enumerate(x);
  #line 68 "src/distribution/AddDiscreteDeltaDistribution.birch"
  return Z;
}

#line 71 "src/distribution/AddDiscreteDeltaDistribution.birch"
std::optional<Delay> AddDiscreteDeltaDistribution_::update(const numbirch::Future<Integer>& x) {
  #line 72 "src/distribution/AddDiscreteDeltaDistribution.birch"
  enumerate(x);
  #line 73 "src/distribution/AddDiscreteDeltaDistribution.birch"
  return construct<AddDiscreteConstrainedDistribution>(z, l, (*(x)));
}

#line 76 "src/distribution/AddDiscreteDeltaDistribution.birch"
std::optional<numbirch::Future<Integer>> AddDiscreteDeltaDistribution_::lower() {
  #line 77 "src/distribution/AddDiscreteDeltaDistribution.birch"
  return (*(p->lower())) + (*(q->lower()));
}

#line 80 "src/distribution/AddDiscreteDeltaDistribution.birch"
std::optional<numbirch::Future<Integer>> AddDiscreteDeltaDistribution_::upper() {
  #line 81 "src/distribution/AddDiscreteDeltaDistribution.birch"
  return (*(p->upper())) + (*(q->upper()));
}

#line 84 "src/distribution/AddDiscreteDeltaDistribution.birch"
void AddDiscreteDeltaDistribution_::constant() {
  #line 85 "src/distribution/AddDiscreteDeltaDistribution.birch"
  this->base_type_::constant();
  #line 86 "src/distribution/AddDiscreteDeltaDistribution.birch"
  p->constant();
  #line 87 "src/distribution/AddDiscreteDeltaDistribution.birch"
  q->constant();
}


/**
 * Create delta distribution.
 */
#line 94 "src/distribution/AddDiscreteDeltaDistribution.birch"
Distribution<Integer> Delta(const Add<Random<Integer>, Random<Integer>>& \u03bc) {
  auto l = \u03bc->l;
  auto r = \u03bc->r;
  #line 98 "src/distribution/AddDiscreteDeltaDistribution.birch"
  if (l->hasNext() && l->getNext()->isBoundedDiscrete() && r->hasNext() && r->getNext()->isBoundedDiscrete()) {
    #line 100 "src/distribution/AddDiscreteDeltaDistribution.birch"
    l->prune();
    #line 101 "src/distribution/AddDiscreteDeltaDistribution.birch"
    r->prune();
    auto p = construct<AddDiscreteDeltaDistribution>((*(l->getNext()->getBoundedDiscrete())), (*(r->getNext()->getBoundedDiscrete())));
    #line 105 "src/distribution/AddDiscreteDeltaDistribution.birch"
    l->setNext(p);
    #line 106 "src/distribution/AddDiscreteDeltaDistribution.birch"
    r->setNext(std::nullopt);
    #line 107 "src/distribution/AddDiscreteDeltaDistribution.birch"
    l->setSide(r);
    #line 108 "src/distribution/AddDiscreteDeltaDistribution.birch"
    r->setSide(l);
    #line 109 "src/distribution/AddDiscreteDeltaDistribution.birch"
    return p;
  } else {
    #line 110 "src/distribution/AddDiscreteDeltaDistribution.birch"
    if (l->hasNext() && l->getNext()->isBoundedDiscrete()) {
      auto x = handle_assume(Delta(r));
      #line 112 "src/distribution/AddDiscreteDeltaDistribution.birch"
      return Delta(l + x);
    } else {
      #line 113 "src/distribution/AddDiscreteDeltaDistribution.birch"
      if (r->hasNext() && r->getNext()->isBoundedDiscrete()) {
        auto x = handle_assume(Delta(l));
        #line 115 "src/distribution/AddDiscreteDeltaDistribution.birch"
        return Delta(x + r);
      } else {
        #line 117 "src/distribution/AddDiscreteDeltaDistribution.birch"
        return wrap_delta(\u03bc);
      }
    }
  }
}

}
namespace birch {
}
namespace birch {

/**
 * Create Bernoulli distribution.
 */
#line 68 "src/distribution/BetaBernoulliDistribution.birch"
Distribution<Boolean> Bernoulli(const Random<Real>& \u03c1) {
  #line 69 "src/distribution/BetaBernoulliDistribution.birch"
  if (\u03c1->hasNext() && \u03c1->getNext()->isBeta()) {
    #line 70 "src/distribution/BetaBernoulliDistribution.birch"
    \u03c1->prune();
    auto n3232_ = (*(\u03c1->getNext()->getBeta()));
    auto \u03b1 = std::move(std::get<0>(n3232_));
    auto \u03b2 = std::move(std::get<1>(n3232_));
    auto p = wrap_beta_bernoulli(\u03b1, \u03b2);
    #line 73 "src/distribution/BetaBernoulliDistribution.birch"
    \u03c1->setNext(p);
    #line 74 "src/distribution/BetaBernoulliDistribution.birch"
    return p;
  } else {
    #line 76 "src/distribution/BetaBernoulliDistribution.birch"
    return wrap_bernoulli(\u03c1);
  }
}

}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
#line 4 "src/distribution/BoundedDiscreteDistribution.birch"
BoundedDiscreteDistribution_::BoundedDiscreteDistribution_() :
    #line 4 "src/distribution/BoundedDiscreteDistribution.birch"
    base_type_() {
  //
}

#line 5 "src/distribution/BoundedDiscreteDistribution.birch"
Boolean BoundedDiscreteDistribution_::isBoundedDiscrete() {
  #line 6 "src/distribution/BoundedDiscreteDistribution.birch"
  return true;
}

#line 9 "src/distribution/BoundedDiscreteDistribution.birch"
std::optional<BoundedDiscreteDistribution> BoundedDiscreteDistribution_::getBoundedDiscrete() {
  #line 10 "src/distribution/BoundedDiscreteDistribution.birch"
  return membirch::Shared<this_type_>(this);
}

}
namespace birch {
}
namespace birch {
}
namespace birch {
#line 173 "src/distribution/ConwayMaxwellPoissonDistribution.birch"
numbirch::Array<Real,1> p_conway_maxwell_poisson(const Real& \u03bc, const Real& \u03bd, const Integer& n) {
  auto log_\u03bb = \u03bd * log(\u03bc);
  auto log_xf = Real(0.0);
  numbirch::Array<Real,1> z(numbirch::make_shape(n + 1));
  #line 177 "src/distribution/ConwayMaxwellPoissonDistribution.birch"
  for (int x = int(1); x <= int((n + 1)); ++x) {
    #line 178 "src/distribution/ConwayMaxwellPoissonDistribution.birch"
    z(x) = (x - 1) * log_\u03bb - \u03bd * log_xf;
    #line 179 "src/distribution/ConwayMaxwellPoissonDistribution.birch"
    log_xf = log_xf + log(x);
  }
  #line 181 "src/distribution/ConwayMaxwellPoissonDistribution.birch"
  return norm_exp(z);
}

}
namespace birch {
}
namespace birch {

/**
 * Create categorical distribution.
 */
#line 69 "src/distribution/DirichletCategoricalDistribution.birch"
Distribution<Integer> Categorical(const Random<numbirch::Array<Real,1>>& \u03c1) {
  #line 70 "src/distribution/DirichletCategoricalDistribution.birch"
  if (\u03c1->hasNext() && \u03c1->getNext()->isDirichlet()) {
    #line 71 "src/distribution/DirichletCategoricalDistribution.birch"
    \u03c1->prune();
    auto \u03b1 = (*(\u03c1->getNext()->getDirichlet()));
    auto p = wrap_dirichlet_categorical(\u03b1);
    #line 74 "src/distribution/DirichletCategoricalDistribution.birch"
    \u03c1->setNext(p);
    #line 75 "src/distribution/DirichletCategoricalDistribution.birch"
    return p;
  } else {
    #line 76 "src/distribution/DirichletCategoricalDistribution.birch"
    if (\u03c1->hasNext() && \u03c1->getNext()->isRestaurant()) {
      #line 77 "src/distribution/DirichletCategoricalDistribution.birch"
      \u03c1->prune();
      auto n3233_ = (*(\u03c1->getNext()->getRestaurant()));
      auto \u03b1 = std::move(std::get<0>(n3233_));
      auto \u03b8 = std::move(std::get<1>(n3233_));
      auto n = std::move(std::get<2>(n3233_));
      auto p = wrap_restaurant_categorical(\u03b1, \u03b8, n);
      #line 80 "src/distribution/DirichletCategoricalDistribution.birch"
      \u03c1->setNext(p);
      #line 81 "src/distribution/DirichletCategoricalDistribution.birch"
      return p;
    } else {
      #line 83 "src/distribution/DirichletCategoricalDistribution.birch"
      return wrap_categorical(\u03c1);
    }
  }
}

}
namespace birch {
}
namespace birch {
}
namespace birch {
#line 6 "src/distribution/DiscreteDeltaDistribution.birch"
DiscreteDeltaDistribution_::DiscreteDeltaDistribution_(const BoundedDiscreteDistribution& p) :
    #line 6 "src/distribution/DiscreteDeltaDistribution.birch"
    base_type_(),
    #line 11 "src/distribution/DiscreteDeltaDistribution.birch"
    p(p) {
  //
}

#line 13 "src/distribution/DiscreteDeltaDistribution.birch"
Boolean DiscreteDeltaDistribution_::supportsLazy() {
  #line 14 "src/distribution/DiscreteDeltaDistribution.birch"
  return p->supportsLazy();
}

#line 17 "src/distribution/DiscreteDeltaDistribution.birch"
numbirch::Future<Integer> DiscreteDeltaDistribution_::simulate() {
  #line 18 "src/distribution/DiscreteDeltaDistribution.birch"
  return p->simulate();
}

#line 21 "src/distribution/DiscreteDeltaDistribution.birch"
std::optional<numbirch::Future<Integer>> DiscreteDeltaDistribution_::simulateLazy() {
  #line 22 "src/distribution/DiscreteDeltaDistribution.birch"
  return p->simulateLazy();
}

#line 25 "src/distribution/DiscreteDeltaDistribution.birch"
numbirch::Future<Real> DiscreteDeltaDistribution_::logpdf(const numbirch::Future<Integer>& x) {
  #line 26 "src/distribution/DiscreteDeltaDistribution.birch"
  return p->logpdf(x);
}

#line 29 "src/distribution/DiscreteDeltaDistribution.birch"
std::optional<numbirch::Future<Real>> DiscreteDeltaDistribution_::logpdfLazy(const numbirch::Future<Integer>& x) {
  #line 30 "src/distribution/DiscreteDeltaDistribution.birch"
  return p->logpdfLazy(x);
}

#line 33 "src/distribution/DiscreteDeltaDistribution.birch"
std::optional<Delay> DiscreteDeltaDistribution_::update(const numbirch::Future<Integer>& x) {
  #line 34 "src/distribution/DiscreteDeltaDistribution.birch"
  return Delta(x);
}

#line 37 "src/distribution/DiscreteDeltaDistribution.birch"
std::optional<Delay> DiscreteDeltaDistribution_::updateLazy(const Expression<Integer>& x) {
  #line 38 "src/distribution/DiscreteDeltaDistribution.birch"
  return Delta(x);
}

#line 41 "src/distribution/DiscreteDeltaDistribution.birch"
std::optional<Expression<Real>> DiscreteDeltaDistribution_::hoist() {
  #line 42 "src/distribution/DiscreteDeltaDistribution.birch"
  return p->hoist();
}

#line 45 "src/distribution/DiscreteDeltaDistribution.birch"
std::optional<numbirch::Future<Integer>> DiscreteDeltaDistribution_::lower() {
  #line 46 "src/distribution/DiscreteDeltaDistribution.birch"
  return p->lower();
}

#line 49 "src/distribution/DiscreteDeltaDistribution.birch"
std::optional<numbirch::Future<Integer>> DiscreteDeltaDistribution_::upper() {
  #line 50 "src/distribution/DiscreteDeltaDistribution.birch"
  return p->upper();
}

#line 53 "src/distribution/DiscreteDeltaDistribution.birch"
void DiscreteDeltaDistribution_::constant() {
  #line 54 "src/distribution/DiscreteDeltaDistribution.birch"
  this->base_type_::constant();
  #line 55 "src/distribution/DiscreteDeltaDistribution.birch"
  p->constant();
}


/**
 * Create delta distribution.
 */
#line 62 "src/distribution/DiscreteDeltaDistribution.birch"
Distribution<Integer> Delta(const Random<Integer>& \u03bc) {
  #line 63 "src/distribution/DiscreteDeltaDistribution.birch"
  if (\u03bc->hasNext() && \u03bc->getNext()->isBoundedDiscrete()) {
    #line 64 "src/distribution/DiscreteDeltaDistribution.birch"
    \u03bc->prune();
    auto p = construct<DiscreteDeltaDistribution>((*(\u03bc->getNext()->getBoundedDiscrete())));
    #line 67 "src/distribution/DiscreteDeltaDistribution.birch"
    \u03bc->setNext(p);
    #line 68 "src/distribution/DiscreteDeltaDistribution.birch"
    return p;
  } else {
    #line 70 "src/distribution/DiscreteDeltaDistribution.birch"
    return wrap_delta(\u03bc);
  }
}

}
namespace birch {
#line 4 "src/distribution/DiscreteDistribution.birch"
DiscreteDistribution_::DiscreteDistribution_() :
    #line 4 "src/distribution/DiscreteDistribution.birch"
    base_type_() {
  //
}

#line 5 "src/distribution/DiscreteDistribution.birch"
Boolean DiscreteDistribution_::isDiscrete() {
  #line 6 "src/distribution/DiscreteDistribution.birch"
  return true;
}

#line 9 "src/distribution/DiscreteDistribution.birch"
std::optional<DiscreteDistribution> DiscreteDistribution_::getDiscrete() {
  #line 10 "src/distribution/DiscreteDistribution.birch"
  return membirch::Shared<this_type_>(this);
}

}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {

/**
 * Create exponential distribution.
 */
#line 108 "src/distribution/GammaExponentialDistribution.birch"
Distribution<Real> Exponential(const Random<Real>& \u03bb) {
  #line 109 "src/distribution/GammaExponentialDistribution.birch"
  return Exponential(Real(1.0) * \u03bb);
}

}
namespace birch {

/**
 * Create Poisson distribution.
 */
#line 116 "src/distribution/GammaPoissonDistribution.birch"
Distribution<Integer> Poisson(const Random<Real>& \u03bb) {
  #line 117 "src/distribution/GammaPoissonDistribution.birch"
  return Poisson(Real(1.0) * \u03bb);
}


/**
 * Create Poisson distribution.
 */
#line 123 "src/distribution/GammaPoissonDistribution.birch"
Distribution<Integer> Poisson(const Mul<Random<Real>, Random<Real>>& \u03bb) {
  auto a = \u03bb->l;
  auto b = \u03bb->r;
  #line 127 "src/distribution/GammaPoissonDistribution.birch"
  if (a->hasNext() && a->getNext()->isGamma()) {
    #line 128 "src/distribution/GammaPoissonDistribution.birch"
    a->prune();
    auto n3234_ = (*(a->getNext()->getGamma()));
    auto k = std::move(std::get<0>(n3234_));
    auto \u03b8 = std::move(std::get<1>(n3234_));
    auto p = wrap_gamma_poisson(b, k, \u03b8);
    #line 131 "src/distribution/GammaPoissonDistribution.birch"
    a->setNext(p);
    #line 132 "src/distribution/GammaPoissonDistribution.birch"
    return p;
  } else {
    #line 133 "src/distribution/GammaPoissonDistribution.birch"
    if (b->hasNext() && b->getNext()->isGamma()) {
      #line 134 "src/distribution/GammaPoissonDistribution.birch"
      b->prune();
      auto n3235_ = (*(b->getNext()->getGamma()));
      auto k = std::move(std::get<0>(n3235_));
      auto \u03b8 = std::move(std::get<1>(n3235_));
      auto p = wrap_gamma_poisson(a, k, \u03b8);
      #line 137 "src/distribution/GammaPoissonDistribution.birch"
      b->setNext(p);
      #line 138 "src/distribution/GammaPoissonDistribution.birch"
      return p;
    } else {
      #line 140 "src/distribution/GammaPoissonDistribution.birch"
      return wrap_poisson(\u03bb);
    }
  }
}

}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {

/**
 * Create multivariate Gaussian distribution.
 */
#line 201 "src/distribution/MultivariateNormalInverseWishartMultivariateGaussianDistribution.birch"
Distribution<numbirch::Array<Real,1>> MultivariateGaussian(const Random<numbirch::Array<Real,1>>& \u03bc, const Random<numbirch::Array<Real,2>>& \u03a3) {
  #line 203 "src/distribution/MultivariateNormalInverseWishartMultivariateGaussianDistribution.birch"
  return MultivariateGaussian(Real(1.0) * \u03bc + Real(0.0), Real(1.0) * \u03a3);
}

}
namespace birch {
}
namespace birch {
#line 7 "src/distribution/NegateDiscreteDeltaDistribution.birch"
NegateDiscreteDeltaDistribution_::NegateDiscreteDeltaDistribution_(const BoundedDiscreteDistribution& p) :
    #line 7 "src/distribution/NegateDiscreteDeltaDistribution.birch"
    base_type_(),
    #line 12 "src/distribution/NegateDiscreteDeltaDistribution.birch"
    p(p) {
  //
}

#line 14 "src/distribution/NegateDiscreteDeltaDistribution.birch"
Boolean NegateDiscreteDeltaDistribution_::supportsLazy() {
  #line 15 "src/distribution/NegateDiscreteDeltaDistribution.birch"
  return p->supportsLazy();
}

#line 18 "src/distribution/NegateDiscreteDeltaDistribution.birch"
numbirch::Future<Integer> NegateDiscreteDeltaDistribution_::simulate() {
  #line 19 "src/distribution/NegateDiscreteDeltaDistribution.birch"
  return -(p->simulate());
}

#line 22 "src/distribution/NegateDiscreteDeltaDistribution.birch"
std::optional<numbirch::Future<Integer>> NegateDiscreteDeltaDistribution_::simulateLazy() {
  #line 23 "src/distribution/NegateDiscreteDeltaDistribution.birch"
  return -((*(p->simulateLazy())));
}

#line 26 "src/distribution/NegateDiscreteDeltaDistribution.birch"
numbirch::Future<Real> NegateDiscreteDeltaDistribution_::logpdf(const numbirch::Future<Integer>& x) {
  #line 27 "src/distribution/NegateDiscreteDeltaDistribution.birch"
  return p->logpdf(-(x));
}

#line 30 "src/distribution/NegateDiscreteDeltaDistribution.birch"
std::optional<numbirch::Future<Real>> NegateDiscreteDeltaDistribution_::logpdfLazy(const numbirch::Future<Integer>& x) {
  #line 31 "src/distribution/NegateDiscreteDeltaDistribution.birch"
  return p->logpdfLazy(-(x));
}

#line 34 "src/distribution/NegateDiscreteDeltaDistribution.birch"
std::optional<Delay> NegateDiscreteDeltaDistribution_::update(const numbirch::Future<Integer>& x) {
  #line 35 "src/distribution/NegateDiscreteDeltaDistribution.birch"
  return Delta(-(x));
}

#line 38 "src/distribution/NegateDiscreteDeltaDistribution.birch"
std::optional<Delay> NegateDiscreteDeltaDistribution_::updateLazy(const Expression<Integer>& x) {
  #line 39 "src/distribution/NegateDiscreteDeltaDistribution.birch"
  return Delta(-(x));
}

#line 42 "src/distribution/NegateDiscreteDeltaDistribution.birch"
std::optional<Expression<Real>> NegateDiscreteDeltaDistribution_::hoist() {
  #line 43 "src/distribution/NegateDiscreteDeltaDistribution.birch"
  return p->hoist();
}

#line 46 "src/distribution/NegateDiscreteDeltaDistribution.birch"
std::optional<numbirch::Future<Integer>> NegateDiscreteDeltaDistribution_::lower() {
  auto l = p->upper();
  #line 48 "src/distribution/NegateDiscreteDeltaDistribution.birch"
  if ((bool(l))) {
    #line 49 "src/distribution/NegateDiscreteDeltaDistribution.birch"
    return -((*(l)));
  } else {
    #line 51 "src/distribution/NegateDiscreteDeltaDistribution.birch"
    return std::nullopt;
  }
}

#line 55 "src/distribution/NegateDiscreteDeltaDistribution.birch"
std::optional<numbirch::Future<Integer>> NegateDiscreteDeltaDistribution_::upper() {
  auto l = p->lower();
  #line 57 "src/distribution/NegateDiscreteDeltaDistribution.birch"
  if ((bool(l))) {
    #line 58 "src/distribution/NegateDiscreteDeltaDistribution.birch"
    return -((*(l)));
  } else {
    #line 60 "src/distribution/NegateDiscreteDeltaDistribution.birch"
    return std::nullopt;
  }
}

#line 64 "src/distribution/NegateDiscreteDeltaDistribution.birch"
void NegateDiscreteDeltaDistribution_::constant() {
  #line 65 "src/distribution/NegateDiscreteDeltaDistribution.birch"
  this->base_type_::constant();
  #line 66 "src/distribution/NegateDiscreteDeltaDistribution.birch"
  p->constant();
}


/**
 * Create delta distribution.
 */
#line 73 "src/distribution/NegateDiscreteDeltaDistribution.birch"
Distribution<Integer> Delta(const Neg<Random<Integer>>& \u03bc) {
  auto m = \u03bc->m;
  #line 75 "src/distribution/NegateDiscreteDeltaDistribution.birch"
  if (m->hasNext() && m->getNext()->isBoundedDiscrete()) {
    #line 76 "src/distribution/NegateDiscreteDeltaDistribution.birch"
    m->prune();
    auto p = construct<NegateDiscreteDeltaDistribution>((*(m->getNext()->getBoundedDiscrete())));
    #line 79 "src/distribution/NegateDiscreteDeltaDistribution.birch"
    m->setNext(p);
    #line 80 "src/distribution/NegateDiscreteDeltaDistribution.birch"
    return p;
  } else {
    #line 82 "src/distribution/NegateDiscreteDeltaDistribution.birch"
    return wrap_delta(\u03bc);
  }
}

}
namespace birch {
}
namespace birch {
}
namespace birch {

/**
 * Create Gaussian distribution.
 */
#line 181 "src/distribution/NormalInverseGammaGaussianDistribution.birch"
Distribution<Real> Gaussian(const Random<Real>& \u03bc, const Random<Real>& \u03c32) {
  #line 182 "src/distribution/NormalInverseGammaGaussianDistribution.birch"
  return Gaussian(Real(1.0) * \u03bc + Real(0.0), Real(1.0) * \u03c32);
}

}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
#line 8 "src/distribution/SubtractDiscreteConstrainedDistribution.birch"
SubtractDiscreteConstrainedDistribution_::SubtractDiscreteConstrainedDistribution_(const numbirch::Array<Real,1>& p, const Integer& l, const Integer& y) :
    #line 8 "src/distribution/SubtractDiscreteConstrainedDistribution.birch"
    base_type_(),
    #line 13 "src/distribution/SubtractDiscreteConstrainedDistribution.birch"
    p(p),
    #line 18 "src/distribution/SubtractDiscreteConstrainedDistribution.birch"
    l(l),
    #line 23 "src/distribution/SubtractDiscreteConstrainedDistribution.birch"
    y(y) {
  //
}

#line 25 "src/distribution/SubtractDiscreteConstrainedDistribution.birch"
numbirch::Future<Integer> SubtractDiscreteConstrainedDistribution_::simulate() {
  #line 26 "src/distribution/SubtractDiscreteConstrainedDistribution.birch"
  return simulate_categorical(p) + l - 1;
}

#line 29 "src/distribution/SubtractDiscreteConstrainedDistribution.birch"
numbirch::Future<Real> SubtractDiscreteConstrainedDistribution_::logpdf(const numbirch::Future<Integer>& x) {
  #line 30 "src/distribution/SubtractDiscreteConstrainedDistribution.birch"
  return logpdf_categorical(x - l + 1, p);
}

#line 33 "src/distribution/SubtractDiscreteConstrainedDistribution.birch"
std::optional<Delay> SubtractDiscreteConstrainedDistribution_::update(const numbirch::Future<Integer>& x) {
  #line 34 "src/distribution/SubtractDiscreteConstrainedDistribution.birch"
  return Delta(x - y);
}

#line 37 "src/distribution/SubtractDiscreteConstrainedDistribution.birch"
std::optional<numbirch::Future<Integer>> SubtractDiscreteConstrainedDistribution_::lower() {
  #line 38 "src/distribution/SubtractDiscreteConstrainedDistribution.birch"
  return l;
}

#line 41 "src/distribution/SubtractDiscreteConstrainedDistribution.birch"
std::optional<numbirch::Future<Integer>> SubtractDiscreteConstrainedDistribution_::upper() {
  #line 42 "src/distribution/SubtractDiscreteConstrainedDistribution.birch"
  return l + length(p) - 1;
}

}
namespace birch {
#line 4 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
SubtractDiscreteDeltaDistribution_::SubtractDiscreteDeltaDistribution_(const BoundedDiscreteDistribution& p, const BoundedDiscreteDistribution& q) :
    #line 4 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    base_type_(),
    #line 9 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    p(p),
    #line 14 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    q(q),
    #line 19 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    x(),
    #line 24 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    l(0),
    #line 29 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    u(0),
    #line 35 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    z(),
    #line 40 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    Z(Real(0.0)) {
  //
}

#line 42 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
void SubtractDiscreteDeltaDistribution_::enumerate(const numbirch::Future<Integer>& x) {
  #line 43 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
  if (!((bool(this->x))) || (*(this->x)) != (*(x))) {
    #line 44 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    l = max((*((*(p->lower())))), (*(x)) + (*((*(q->lower())))));
    #line 45 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    u = min((*((*(p->upper())))), (*(x)) + (*((*(q->upper())))));
    #line 46 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    Z = -(std::numeric_limits<Real>::infinity());
    #line 47 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    if (l <= u) {
      #line 49 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
      z = vector_lambda([=](const Integer& i) {
        auto n = l + i - 1;
        #line 51 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
        return (*(p->logpdf(n))) + (*(q->logpdf(n - (*(x)))));
      }, u - l + 1);
      #line 53 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
      Z = log_sum_exp(z);
      #line 54 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
      z = norm_exp(z);
    }
    #line 56 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    this->x = (*(x));
  }
}

#line 60 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
numbirch::Future<Integer> SubtractDiscreteDeltaDistribution_::simulate() {
  #line 61 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
  return p->simulate() - q->simulate();
}

#line 64 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
numbirch::Future<Real> SubtractDiscreteDeltaDistribution_::logpdf(const numbirch::Future<Integer>& x) {
  #line 65 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
  enumerate(x);
  #line 66 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
  return Z;
}

#line 69 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
std::optional<Delay> SubtractDiscreteDeltaDistribution_::update(const numbirch::Future<Integer>& x) {
  #line 70 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
  enumerate(x);
  #line 71 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
  return construct<SubtractDiscreteConstrainedDistribution>(z, l, (*(x)));
}

#line 74 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
std::optional<numbirch::Future<Integer>> SubtractDiscreteDeltaDistribution_::lower() {
  #line 75 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
  return (*(p->lower())) - (*(q->upper()));
}

#line 78 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
std::optional<numbirch::Future<Integer>> SubtractDiscreteDeltaDistribution_::upper() {
  #line 79 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
  return (*(p->upper())) - (*(q->lower()));
}

#line 82 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
void SubtractDiscreteDeltaDistribution_::constant() {
  #line 83 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
  this->base_type_::constant();
  #line 84 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
  p->constant();
  #line 85 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
  q->constant();
}


/**
 * Create delta distribution.
 */
#line 92 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
Distribution<Integer> Delta(const Sub<Random<Integer>, Random<Integer>>& \u03bc) {
  auto l = \u03bc->l;
  auto r = \u03bc->r;
  #line 96 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
  if (l->hasNext() && l->getNext()->isBoundedDiscrete() && r->hasNext() && r->getNext()->isBoundedDiscrete()) {
    #line 98 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    l->prune();
    #line 99 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    r->prune();
    auto p = construct<SubtractDiscreteDeltaDistribution>((*(l->getNext()->getBoundedDiscrete())), (*(r->getNext()->getBoundedDiscrete())));
    #line 103 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    l->setNext(p);
    #line 104 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    r->setNext(std::nullopt);
    #line 105 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    l->setSide(r);
    #line 106 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    r->setSide(l);
    #line 107 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    return p;
  } else {
    #line 108 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
    if (l->hasNext() && l->getNext()->isBoundedDiscrete()) {
      auto x = handle_assume(Delta(r));
      #line 110 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
      return Delta(l - x);
    } else {
      #line 111 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
      if (r->hasNext() && r->getNext()->isBoundedDiscrete()) {
        auto x = handle_assume(Delta(l));
        #line 113 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
        return Delta(x - r);
      } else {
        #line 115 "src/distribution/SubtractDiscreteDeltaDistribution.birch"
        return wrap_delta(\u03bc);
      }
    }
  }
}

}
namespace birch {
}
namespace birch {
#line 114 "src/distribution/UniformIntegerDistribution.birch"
Integer quantile_uniform_int(const Real& P, const Integer& l, const Integer& u) {
  auto P1 = wait(P);
  auto l1 = wait(l);
  auto u1 = wait(u);
  #line 118 "src/distribution/UniformIntegerDistribution.birch"
  return l1 + cast<Integer>(P1 * (u1 - l1));
}

}
namespace birch {
}
namespace birch {
}
