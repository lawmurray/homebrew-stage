namespace birch {
#line 1 "src/expression/ArgsVisitor.birch"
ArgsVisitor_::ArgsVisitor_() :
    #line 1 "src/expression/ArgsVisitor.birch"
    base_type_(),
    #line 9 "src/expression/ArgsVisitor.birch"
    x((numbirch::make_shape(1024))),
    #line 15 "src/expression/ArgsVisitor.birch"
    g((numbirch::make_shape(1024))),
    #line 20 "src/expression/ArgsVisitor.birch"
    n(0) {
  //
}

#line 27 "src/expression/ArgsVisitor.birch"
std::tuple<numbirch::Array<Real,1>, numbirch::Array<Real,1>> ArgsVisitor_::args() {
  #line 28 "src/expression/ArgsVisitor.birch"
  return std::make_tuple(x(std::make_pair(1, n)), g(std::make_pair(1, n)));
}

#line 36 "src/expression/ArgsVisitor.birch"
void ArgsVisitor_::visit(const Random<Real>& v) {
  #line 37 "src/expression/ArgsVisitor.birch"
  reserve(n + 1);
  auto y = (*(v->x));
  #line 39 "src/expression/ArgsVisitor.birch"

    x.slice(n + 1) = y;
      #line 42 "src/expression/ArgsVisitor.birch"
  if ((bool(v->g))) {
    auto z = (*(v->g));
    #line 44 "src/expression/ArgsVisitor.birch"

      g.slice(n + 1) = z;
        } else {
    #line 48 "src/expression/ArgsVisitor.birch"

      g.slice(n + 1) = Real(0);
        }
  #line 52 "src/expression/ArgsVisitor.birch"
  n = n + 1;
}

#line 60 "src/expression/ArgsVisitor.birch"
void ArgsVisitor_::visit(const Random<Integer>& v) {
  #line 61 "src/expression/ArgsVisitor.birch"
  v->g = std::nullopt;
}

#line 69 "src/expression/ArgsVisitor.birch"
void ArgsVisitor_::visit(const Random<Boolean>& v) {
  #line 70 "src/expression/ArgsVisitor.birch"
  v->g = std::nullopt;
}

#line 78 "src/expression/ArgsVisitor.birch"
void ArgsVisitor_::visit(const Random<numbirch::Array<Real,1>>& v) {
  auto m = size((*(v->x)));
  #line 80 "src/expression/ArgsVisitor.birch"
  reserve(n + m);
  #line 81 "src/expression/ArgsVisitor.birch"
  x(std::make_pair((n + 1), (n + m))) = (*(v->x));
  #line 82 "src/expression/ArgsVisitor.birch"
  if ((bool(v->g))) {
    #line 83 "src/expression/ArgsVisitor.birch"
    g(std::make_pair((n + 1), (n + m))) = (*(v->g));
  } else {
    #line 85 "src/expression/ArgsVisitor.birch"
    g(std::make_pair((n + 1), (n + m))) = Real(0.0);
  }
  #line 87 "src/expression/ArgsVisitor.birch"
  v->g = std::nullopt;
  #line 88 "src/expression/ArgsVisitor.birch"
  n = n + m;
}

#line 96 "src/expression/ArgsVisitor.birch"
void ArgsVisitor_::visit(const Random<numbirch::Array<Integer,1>>& v) {
  #line 97 "src/expression/ArgsVisitor.birch"
  v->g = std::nullopt;
}

#line 105 "src/expression/ArgsVisitor.birch"
void ArgsVisitor_::visit(const Random<numbirch::Array<Real,2>>& v) {
  auto m = size((*(v->x)));
  #line 107 "src/expression/ArgsVisitor.birch"
  reserve(n + m);
  #line 108 "src/expression/ArgsVisitor.birch"
  x(std::make_pair((n + 1), (n + m))) = vec((*(v->x)));
  #line 109 "src/expression/ArgsVisitor.birch"
  if ((bool(v->g))) {
    #line 110 "src/expression/ArgsVisitor.birch"
    g(std::make_pair((n + 1), (n + m))) = vec((*(v->g)));
  } else {
    #line 112 "src/expression/ArgsVisitor.birch"
    g(std::make_pair((n + 1), (n + m))) = Real(0.0);
  }
  #line 114 "src/expression/ArgsVisitor.birch"
  v->g = std::nullopt;
  #line 115 "src/expression/ArgsVisitor.birch"
  n = n + m;
}

#line 123 "src/expression/ArgsVisitor.birch"
void ArgsVisitor_::reserve(const Integer& m) {
  auto k = length(x);
  #line 125 "src/expression/ArgsVisitor.birch"
  while (k < m) {
    #line 126 "src/expression/ArgsVisitor.birch"
    k = 2 * k;
  }
  #line 128 "src/expression/ArgsVisitor.birch"
  if (k > length(x)) {
    numbirch::Array<Real,1> y(numbirch::make_shape(k));
    numbirch::Array<Real,1> h(numbirch::make_shape(k));
    #line 131 "src/expression/ArgsVisitor.birch"
    y(std::make_pair(1, n)) = x(std::make_pair(1, n));
    #line 132 "src/expression/ArgsVisitor.birch"
    h(std::make_pair(1, n)) = g(std::make_pair(1, n));
    #line 133 "src/expression/ArgsVisitor.birch"
    x = y;
    #line 134 "src/expression/ArgsVisitor.birch"
    g = h;
  }
  #line 136 "src/expression/ArgsVisitor.birch"
  assert(length(x) == length(g));
  #line 137 "src/expression/ArgsVisitor.birch"
  assert(length(x) >= m);
}

#line 1 "src/expression/ArgsVisitor.birch"
Object_* make_ArgsVisitor_() {
  #line 1 "src/expression/ArgsVisitor.birch"
  return new ArgsVisitor_();
  #line 1 "src/expression/ArgsVisitor.birch"
}
static int register_factory_ArgsVisitor_ = ::register_factory("ArgsVisitor", make_ArgsVisitor_);

}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
#line 1 "src/expression/MoveVisitor.birch"
MoveVisitor_::MoveVisitor_(const numbirch::Array<Real,1>& x) :
    #line 1 "src/expression/MoveVisitor.birch"
    base_type_(),
    #line 10 "src/expression/MoveVisitor.birch"
    x(x),
    #line 15 "src/expression/MoveVisitor.birch"
    n(0) {
  //
}

#line 20 "src/expression/MoveVisitor.birch"
Boolean MoveVisitor_::isFinished() {
  #line 21 "src/expression/MoveVisitor.birch"
  return n == length(x);
}

#line 29 "src/expression/MoveVisitor.birch"
void MoveVisitor_::visit(const Random<Real>& v) {
  #line 30 "src/expression/MoveVisitor.birch"

    auto y = x.slice(n + 1);
      #line 33 "src/expression/MoveVisitor.birch"
  v->x = y;
  #line 34 "src/expression/MoveVisitor.birch"
  v->g = std::nullopt;
  #line 35 "src/expression/MoveVisitor.birch"
  n = n + 1;
}

#line 43 "src/expression/MoveVisitor.birch"
void MoveVisitor_::visit(const Random<Integer>& v) {
}

#line 52 "src/expression/MoveVisitor.birch"
void MoveVisitor_::visit(const Random<Boolean>& v) {
}

#line 61 "src/expression/MoveVisitor.birch"
void MoveVisitor_::visit(const Random<numbirch::Array<Real,1>>& v) {
  auto m = length(v);
  #line 63 "src/expression/MoveVisitor.birch"
  v->x = x(std::make_pair((n + 1), (n + m)));
  #line 64 "src/expression/MoveVisitor.birch"
  v->g = std::nullopt;
  #line 65 "src/expression/MoveVisitor.birch"
  n = n + m;
}

#line 73 "src/expression/MoveVisitor.birch"
void MoveVisitor_::visit(const Random<numbirch::Array<Integer,1>>& v) {
}

#line 82 "src/expression/MoveVisitor.birch"
void MoveVisitor_::visit(const Random<numbirch::Array<Real,2>>& v) {
  auto r = rows(v);
  auto c = columns(v);
  #line 85 "src/expression/MoveVisitor.birch"
  v->x = mat(x(std::make_pair((n + 1), (n + r * c))), c);
  #line 86 "src/expression/MoveVisitor.birch"
  v->g = std::nullopt;
  #line 87 "src/expression/MoveVisitor.birch"
  n = n + r * c;
}

}
namespace birch {
}
namespace birch {
}
namespace birch {
}
