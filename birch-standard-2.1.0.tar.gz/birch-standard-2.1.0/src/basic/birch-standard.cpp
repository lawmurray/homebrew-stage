namespace birch {
}
namespace birch {
#line 97 "src/basic/Delay.birch"
Delay_::Delay_() :
    #line 97 "src/basic/Delay.birch"
    base_type_(),
    #line 101 "src/basic/Delay.birch"
    next(),
    #line 108 "src/basic/Delay.birch"
    side() {
  //
}

#line 113 "src/basic/Delay.birch"
Boolean Delay_::hasNext() {
  #line 114 "src/basic/Delay.birch"
  return (bool(next));
}

#line 122 "src/basic/Delay.birch"
void Delay_::setNext(const std::optional<Delay>& node) {
  #line 123 "src/basic/Delay.birch"
  this->next = node;
}

#line 129 "src/basic/Delay.birch"
Delay Delay_::getNext() {
  #line 130 "src/basic/Delay.birch"
  assert((bool(next)));
  #line 131 "src/basic/Delay.birch"
  return (*(next));
}

#line 137 "src/basic/Delay.birch"
std::optional<Delay> Delay_::takeNext() {
  auto r = next;
  #line 139 "src/basic/Delay.birch"
  next = std::nullopt;
  #line 140 "src/basic/Delay.birch"
  return r;
}

#line 154 "src/basic/Delay.birch"
std::optional<Delay> Delay_::getNext(const Integer& n) {
  #line 155 "src/basic/Delay.birch"
  assert(n > 0);
  #line 156 "src/basic/Delay.birch"
  if (n == 1) {
    #line 157 "src/basic/Delay.birch"
    return next;
  } else {
    #line 158 "src/basic/Delay.birch"
    if ((bool(next))) {
      #line 159 "src/basic/Delay.birch"
      return (*(next))->getNext(n - 1);
    } else {
      #line 161 "src/basic/Delay.birch"
      return std::nullopt;
    }
  }
}

#line 168 "src/basic/Delay.birch"
Boolean Delay_::hasSide() {
  #line 169 "src/basic/Delay.birch"
  return (bool(side));
}

#line 177 "src/basic/Delay.birch"
void Delay_::setSide(const std::optional<Delay>& node) {
  #line 178 "src/basic/Delay.birch"
  this->side = node;
}

#line 184 "src/basic/Delay.birch"
Delay Delay_::getSide() {
  #line 185 "src/basic/Delay.birch"
  assert((bool(side)));
  #line 186 "src/basic/Delay.birch"
  return (*(side));
}

#line 192 "src/basic/Delay.birch"
std::optional<Delay> Delay_::takeSide() {
  auto r = side;
  #line 194 "src/basic/Delay.birch"
  side = std::nullopt;
  #line 195 "src/basic/Delay.birch"
  return r;
}

#line 209 "src/basic/Delay.birch"
std::optional<Delay> Delay_::getSide(const Integer& n) {
  #line 210 "src/basic/Delay.birch"
  assert(n > 0);
  #line 211 "src/basic/Delay.birch"
  if (n == 1) {
    #line 212 "src/basic/Delay.birch"
    return side;
  } else {
    #line 213 "src/basic/Delay.birch"
    if ((bool(side))) {
      #line 214 "src/basic/Delay.birch"
      return (*(side))->getSide(n - 1);
    } else {
      #line 216 "src/basic/Delay.birch"
      return std::nullopt;
    }
  }
}

#line 225 "src/basic/Delay.birch"
Boolean Delay_::isInternal() {
  #line 226 "src/basic/Delay.birch"
  return (bool(next)) && (*(next))->next != membirch::Shared<this_type_>(this);
}

#line 233 "src/basic/Delay.birch"
Boolean Delay_::isSubordinate() {
  #line 234 "src/basic/Delay.birch"
  return false;
}

#line 240 "src/basic/Delay.birch"
void Delay_::setSubordinate() {
  #line 241 "src/basic/Delay.birch"
  assert(false);
}

#line 251 "src/basic/Delay.birch"
Delay Delay_::prune() {
  #line 252 "src/basic/Delay.birch"
  assert(!((bool(next))));
  #line 253 "src/basic/Delay.birch"
  return membirch::Shared<this_type_>(this);
}

#line 259 "src/basic/Delay.birch"
std::optional<Expression<Real>> Delay_::hoist() {
  #line 260 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 266 "src/basic/Delay.birch"
void Delay_::constant() {
}

#line 273 "src/basic/Delay.birch"
Boolean Delay_::isRandom() {
  #line 274 "src/basic/Delay.birch"
  return false;
}

#line 280 "src/basic/Delay.birch"
Boolean Delay_::isDistribution() {
  #line 281 "src/basic/Delay.birch"
  return false;
}

#line 284 "src/basic/Delay.birch"
Boolean Delay_::isGaussian() {
  #line 285 "src/basic/Delay.birch"
  return false;
}

#line 288 "src/basic/Delay.birch"
std::optional<std::tuple<Expression<Real>, Expression<Real>>> Delay_::getGaussian() {
  #line 289 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 292 "src/basic/Delay.birch"
Boolean Delay_::isBeta() {
  #line 293 "src/basic/Delay.birch"
  return false;
}

#line 296 "src/basic/Delay.birch"
std::optional<std::tuple<Expression<Real>, Expression<Real>>> Delay_::getBeta() {
  #line 297 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 300 "src/basic/Delay.birch"
Boolean Delay_::isGamma() {
  #line 301 "src/basic/Delay.birch"
  return false;
}

#line 304 "src/basic/Delay.birch"
std::optional<std::tuple<Expression<Real>, Expression<Real>>> Delay_::getGamma() {
  #line 305 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 308 "src/basic/Delay.birch"
Boolean Delay_::isInverseGamma() {
  #line 309 "src/basic/Delay.birch"
  return false;
}

#line 312 "src/basic/Delay.birch"
std::optional<std::tuple<Expression<Real>, Expression<Real>>> Delay_::getInverseGamma() {
  #line 313 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 316 "src/basic/Delay.birch"
Boolean Delay_::isInverseWishart() {
  #line 317 "src/basic/Delay.birch"
  return false;
}

#line 320 "src/basic/Delay.birch"
std::optional<std::tuple<Expression<numbirch::Array<Real,2>>, Expression<Real>>> Delay_::getInverseWishart() {
  #line 321 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 324 "src/basic/Delay.birch"
Boolean Delay_::isNormalInverseGamma() {
  #line 325 "src/basic/Delay.birch"
  return false;
}

#line 328 "src/basic/Delay.birch"
std::optional<std::tuple<Expression<Real>, Expression<Real>, Expression<Real>, Expression<Real>>> Delay_::getNormalInverseGamma() {
  #line 330 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 333 "src/basic/Delay.birch"
Boolean Delay_::isDirichlet() {
  #line 334 "src/basic/Delay.birch"
  return false;
}

#line 337 "src/basic/Delay.birch"
std::optional<Expression<numbirch::Array<Real,1>>> Delay_::getDirichlet() {
  #line 338 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 341 "src/basic/Delay.birch"
Boolean Delay_::isRestaurant() {
  #line 342 "src/basic/Delay.birch"
  return false;
}

#line 345 "src/basic/Delay.birch"
std::optional<std::tuple<Expression<Real>, Expression<Real>, Expression<numbirch::Array<Integer,1>>>> Delay_::getRestaurant() {
  #line 347 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 350 "src/basic/Delay.birch"
Boolean Delay_::isMultivariateGaussian() {
  #line 351 "src/basic/Delay.birch"
  return false;
}

#line 354 "src/basic/Delay.birch"
std::optional<std::tuple<Expression<numbirch::Array<Real,1>>, Expression<numbirch::Array<Real,2>>>> Delay_::getMultivariateGaussian() {
  #line 356 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 359 "src/basic/Delay.birch"
Boolean Delay_::isMultivariateNormalInverseGamma() {
  #line 360 "src/basic/Delay.birch"
  return false;
}

#line 363 "src/basic/Delay.birch"
std::optional<std::tuple<Expression<numbirch::Array<Real,1>>, Expression<numbirch::Array<Real,2>>, Expression<Real>, Expression<Real>>> Delay_::getMultivariateNormalInverseGamma() {
  #line 365 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 368 "src/basic/Delay.birch"
Boolean Delay_::isMultivariateNormalInverseWishart() {
  #line 369 "src/basic/Delay.birch"
  return false;
}

#line 372 "src/basic/Delay.birch"
std::optional<std::tuple<Expression<numbirch::Array<Real,1>>, Expression<Real>, Expression<numbirch::Array<Real,2>>, Expression<Real>>> Delay_::getMultivariateNormalInverseWishart() {
  #line 374 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 377 "src/basic/Delay.birch"
Boolean Delay_::isMatrixGaussian() {
  #line 378 "src/basic/Delay.birch"
  return false;
}

#line 381 "src/basic/Delay.birch"
std::optional<std::tuple<Expression<numbirch::Array<Real,2>>, Expression<numbirch::Array<Real,2>>, Expression<numbirch::Array<Real,2>>>> Delay_::getMatrixGaussian() {
  #line 383 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 386 "src/basic/Delay.birch"
Boolean Delay_::isMatrixNormalInverseWishart() {
  #line 387 "src/basic/Delay.birch"
  return false;
}

#line 390 "src/basic/Delay.birch"
std::optional<std::tuple<Expression<numbirch::Array<Real,2>>, Expression<numbirch::Array<Real,2>>, Expression<numbirch::Array<Real,2>>, Expression<Real>>> Delay_::getMatrixNormalInverseWishart() {
  #line 392 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 395 "src/basic/Delay.birch"
Boolean Delay_::isDiscrete() {
  #line 396 "src/basic/Delay.birch"
  return false;
}

#line 399 "src/basic/Delay.birch"
std::optional<DiscreteDistribution> Delay_::getDiscrete() {
  #line 400 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 403 "src/basic/Delay.birch"
Boolean Delay_::isBoundedDiscrete() {
  #line 404 "src/basic/Delay.birch"
  return false;
}

#line 407 "src/basic/Delay.birch"
std::optional<BoundedDiscreteDistribution> Delay_::getBoundedDiscrete() {
  #line 408 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 411 "src/basic/Delay.birch"
std::optional<std::tuple<Expression<numbirch::Array<Real,1>>, Expression<numbirch::Array<Real,1>>, Expression<numbirch::Array<Real,2>>, Expression<Real>, Expression<Real>, Expression<Real>, Expression<Real>>> Delay_::getMultivariateNormalInverseGammaGaussian() {
  #line 415 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 418 "src/basic/Delay.birch"
std::optional<std::tuple<Expression<numbirch::Array<Real,1>>, Expression<numbirch::Array<Real,2>>, Expression<numbirch::Array<Real,1>>, Expression<numbirch::Array<Real,2>>, Expression<Real>, Expression<Real>, Expression<numbirch::Array<Real,1>>, Expression<numbirch::Array<Real,1>>>> Delay_::joinMultivariateNormalInverseGammaGaussian() {
  #line 422 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 425 "src/basic/Delay.birch"
std::optional<std::tuple<Expression<numbirch::Array<Real,1>>, Expression<numbirch::Array<Real,1>>, Expression<numbirch::Array<Real,2>>, Expression<numbirch::Array<Real,2>>, Expression<numbirch::Array<Real,2>>, Expression<Real>, Expression<Real>>> Delay_::getMatrixNormalInverseWishartMultivariateGaussian(const Expression<numbirch::Array<Real,1>>& x) {
  #line 429 "src/basic/Delay.birch"
  return std::nullopt;
}

#line 432 "src/basic/Delay.birch"
std::optional<std::tuple<Expression<numbirch::Array<Real,2>>, Expression<numbirch::Array<Real,2>>, Expression<numbirch::Array<Real,2>>, Expression<numbirch::Array<Real,2>>, Expression<numbirch::Array<Real,2>>, Expression<Real>, Expression<numbirch::Array<Real,2>>>> Delay_::joinMatrixNormalInverseWishartMultivariateGaussian() {
  #line 436 "src/basic/Delay.birch"
  return std::nullopt;
}

}
namespace birch {
}
namespace birch {

/**
 * Modulus.
 */
#line 14 "src/basic/Integer.birch"
Integer mod(const Integer& x, const Integer& y) {
  #line 15 "src/basic/Integer.birch"

  return x % y;
  }


/**
 * Maximum of two values.
 */
#line 23 "src/basic/Integer.birch"
Integer max(const Integer& x, const Integer& y) {
  #line 24 "src/basic/Integer.birch"

  return std::max(x, y);
  }


/**
 * Minimum of two values.
 */
#line 32 "src/basic/Integer.birch"
Integer min(const Integer& x, const Integer& y) {
  #line 33 "src/basic/Integer.birch"

  return std::min(x, y);
  }

}
namespace birch {
#line 4 "src/basic/Model.birch"
Model_::Model_() :
    #line 4 "src/basic/Model.birch"
    base_type_(),
    #line 8 "src/basic/Model.birch"
    \u039e(),
    #line 13 "src/basic/Model.birch"
    \u03a6(),
    #line 18 "src/basic/Model.birch"
    \u03c0() {
  //
}

#line 23 "src/basic/Model.birch"
void Model_::simulate() {
}

#line 32 "src/basic/Model.birch"
void Model_::simulate(const Integer& t) {
}

#line 36 "src/basic/Model.birch"
void Model_::hoist() {
  #line 37 "src/basic/Model.birch"
  \u03c0 = std::nullopt;
  #line 38 "src/basic/Model.birch"
  for (int i = int(1); i <= int(\u039e->size()); ++i) {
    #line 39 "src/basic/Model.birch"
    for (int j = int(1); j <= int(\u039e(i)->size()); ++j) {
      #line 40 "src/basic/Model.birch"
      if (!(\u039e(i)(j)->isSubordinate())) {
        auto \u03be = \u039e(i)(j)->hoist();
        #line 42 "src/basic/Model.birch"
        if ((bool(\u03be))) {
          #line 43 "src/basic/Model.birch"
          if ((bool(\u03c0))) {
            #line 44 "src/basic/Model.birch"
            \u03c0 = box((*(\u03c0)) + (*(\u03be)));
          } else {
            #line 46 "src/basic/Model.birch"
            \u03c0 = (*(\u03be));
          }
        }
      }
    }
  }
  #line 52 "src/basic/Model.birch"
  for (int i = int(1); i <= int(\u03a6->size()); ++i) {
    #line 53 "src/basic/Model.birch"
    for (int j = int(1); j <= int(\u03a6(i)->size()); ++j) {
      auto \u03c6 = \u03a6(i)(j);
      #line 55 "src/basic/Model.birch"
      if ((bool(\u03c0))) {
        #line 56 "src/basic/Model.birch"
        \u03c0 = box((*(\u03c0)) + \u03c6);
      } else {
        #line 58 "src/basic/Model.birch"
        \u03c0 = \u03c6;
      }
    }
  }
}

#line 64 "src/basic/Model.birch"
void Model_::constant(const Integer& nlags) {
  #line 65 "src/basic/Model.birch"
  \u03c0 = std::nullopt;
  #line 66 "src/basic/Model.birch"
  while (\u039e->size() >= nlags) {
    #line 67 "src/basic/Model.birch"
    for (int j = int(1); j <= int(\u039e->front()->size()); ++j) {
      #line 68 "src/basic/Model.birch"
      \u039e->front()(j)->constant();
    }
    #line 70 "src/basic/Model.birch"
    \u039e->popFront();
  }
  #line 72 "src/basic/Model.birch"
  while (\u03a6->size() >= nlags) {
    #line 73 "src/basic/Model.birch"
    for (int j = int(1); j <= int(\u03a6->front()->size()); ++j) {
      #line 74 "src/basic/Model.birch"
      \u03a6->front()(j)->constant();
    }
    #line 76 "src/basic/Model.birch"
    \u03a6->popFront();
  }
}

#line 83 "src/basic/Model.birch"
void Model_::read(const Buffer& buffer) {
  #line 84 "src/basic/Model.birch"
  this->base_type_::read(buffer);
}

#line 90 "src/basic/Model.birch"
void Model_::read(const Integer& t, const Buffer& buffer) {
}

#line 97 "src/basic/Model.birch"
void Model_::write(const Buffer& buffer) {
  #line 98 "src/basic/Model.birch"
  this->base_type_::write(buffer);
}

#line 104 "src/basic/Model.birch"
void Model_::write(const Integer& t, const Buffer& buffer) {
}

}
namespace birch {
}
namespace birch {
#line 4 "src/basic/Object.birch"
Object_::Object_() :
    #line 4 "src/basic/Object.birch"
    base_type_() {
  //
}

#line 10 "src/basic/Object.birch"
void Object_::read(const Buffer& buffer) {
}

#line 19 "src/basic/Object.birch"
void Object_::write(const Buffer& buffer) {
}

#line 29 "src/basic/Object.birch"
void Object_::read(const Integer& t, const Buffer& buffer) {
}

#line 39 "src/basic/Object.birch"
void Object_::write(const Integer& t, const Buffer& buffer) {
}


/**
 * Identity comparison.
 */
#line 47 "src/basic/Object.birch"
Boolean operator==(const Object& x, const Object& y) {
  #line 48 "src/basic/Object.birch"

  return x.get() == y.get();
  }


/**
 * Identity comparison.
 */
#line 56 "src/basic/Object.birch"
Boolean operator!=(const Object& x, const Object& y) {
  #line 57 "src/basic/Object.birch"
  return !((x == y));
}

}
namespace birch {
#line 1 "src/basic/ProgressBar.birch"
ProgressBar_::ProgressBar_() :
    #line 1 "src/basic/ProgressBar.birch"
    base_type_(),
    #line 8 "src/basic/ProgressBar.birch"
    out(stderr_),
    #line 13 "src/basic/ProgressBar.birch"
    current(-(1)),
    #line 18 "src/basic/ProgressBar.birch"
    maximum(80) {
  //
}

#line 30 "src/basic/ProgressBar.birch"
void ProgressBar_::update(const Real& progress) {
  #line 31 "src/basic/ProgressBar.birch"
  assert(Real(0.0) <= progress && progress <= Real(1.0));
  auto old = current;
  #line 33 "src/basic/ProgressBar.birch"
  current = cast<Integer>(progress * maximum);
  #line 34 "src/basic/ProgressBar.birch"
  if (current != old) {
    #line 36 "src/basic/ProgressBar.birch"
    out->flush();
    #line 37 "src/basic/ProgressBar.birch"
    if (old >= 0) {
      #line 39 "src/basic/ProgressBar.birch"
      out->print(String("\033[1A\r"));
    }
    #line 41 "src/basic/ProgressBar.birch"
    for (int i = int(1); i <= int(current); ++i) {
      #line 42 "src/basic/ProgressBar.birch"
      out->print(String("\u25a0"));
    }
    #line 44 "src/basic/ProgressBar.birch"
    for (int i = int((current + 1)); i <= int(maximum); ++i) {
      #line 45 "src/basic/ProgressBar.birch"
      out->print(String("\u25a1"));
    }
    #line 47 "src/basic/ProgressBar.birch"
    out->print(String("\n"));
    #line 48 "src/basic/ProgressBar.birch"
    out->flush();
  }
}

#line 1 "src/basic/ProgressBar.birch"
Object_* make_ProgressBar_() {
  #line 1 "src/basic/ProgressBar.birch"
  return new ProgressBar_();
  #line 1 "src/basic/ProgressBar.birch"
}
static int register_factory_ProgressBar_ = ::register_factory("ProgressBar", make_ProgressBar_);

}
namespace birch {

/**
 * Modulus.
 */
#line 16 "src/basic/Real.birch"
Real mod(const Real& x, const Real& y) {
  #line 17 "src/basic/Real.birch"

  return std::fmod(x, y);
  }


/**
 * Maximum of two values.
 */
#line 25 "src/basic/Real.birch"
Real max(const Real& x, const Real& y) {
  #line 26 "src/basic/Real.birch"

  return std::max(x, y);
  }


/**
 * Minimum of two values.
 */
#line 34 "src/basic/Real.birch"
Real min(const Real& x, const Real& y) {
  #line 35 "src/basic/Real.birch"

  return std::min(x, y);
  }

}
namespace birch {

/**
 * Convert to string.
 */
#line 13 "src/basic/String.birch"
String to_string(const Real& x) {
  #line 14 "src/basic/String.birch"

  std::stringstream buf;
  if (x == (int64_t)x) {
    buf << (int64_t)x << ".0";
  } else {
    buf << std::scientific << std::setprecision(14) << x;
  }
  return buf.str();
  }


/**
 * Convert to string.
 */
#line 28 "src/basic/String.birch"
String to_string(const numbirch::Future<Real>& x) {
  #line 29 "src/basic/String.birch"
  return to_string((*(x)));
}


/**
 * Convert to string.
 */
#line 35 "src/basic/String.birch"
String to_string(const Integer& x) {
  #line 36 "src/basic/String.birch"

  return std::to_string(x);
  }


/**
 * Convert to string.
 */
#line 44 "src/basic/String.birch"
String to_string(const numbirch::Future<Integer>& x) {
  #line 45 "src/basic/String.birch"
  return to_string((*(x)));
}


/**
 * Convert to string.
 */
#line 51 "src/basic/String.birch"
String to_string(const Boolean& x) {
  #line 52 "src/basic/String.birch"
  if (x) {
    #line 53 "src/basic/String.birch"
    return String("true");
  } else {
    #line 55 "src/basic/String.birch"
    return String("false");
  }
}


/**
 * Convert to string.
 */
#line 62 "src/basic/String.birch"
String to_string(const numbirch::Future<Boolean>& x) {
  #line 63 "src/basic/String.birch"
  return to_string((*(x)));
}


/**
 * Convert to string.
 */
#line 69 "src/basic/String.birch"
String to_string(const String& x) {
  #line 70 "src/basic/String.birch"
  return x;
}


/**
 * String concatenation.
 */
#line 183 "src/basic/String.birch"
String operator+(const String& x, const Boolean& y) {
  #line 184 "src/basic/String.birch"
  return x + to_string(y);
}


/**
 * String concatenation.
 */
#line 190 "src/basic/String.birch"
String operator+(const String& x, const Real& y) {
  #line 191 "src/basic/String.birch"
  return x + to_string(y);
}


/**
 * String concatenation.
 */
#line 197 "src/basic/String.birch"
String operator+(const String& x, const Integer& y) {
  #line 198 "src/basic/String.birch"
  return x + to_string(y);
}


/**
 * String concatenation.
 */
#line 204 "src/basic/String.birch"
String operator+(const String& x, const numbirch::Array<Boolean,1>& y) {
  #line 205 "src/basic/String.birch"
  return x + to_string(y);
}


/**
 * String concatenation.
 */
#line 211 "src/basic/String.birch"
String operator+(const String& x, const numbirch::Array<Real,1>& y) {
  #line 212 "src/basic/String.birch"
  return x + to_string(y);
}


/**
 * String concatenation.
 */
#line 218 "src/basic/String.birch"
String operator+(const String& x, const numbirch::Array<Integer,1>& y) {
  #line 219 "src/basic/String.birch"
  return x + to_string(y);
}


/**
 * String concatenation.
 */
#line 225 "src/basic/String.birch"
String operator+(const String& x, const numbirch::Array<Boolean,2>& y) {
  #line 226 "src/basic/String.birch"
  return x + to_string(y);
}


/**
 * String concatenation.
 */
#line 232 "src/basic/String.birch"
String operator+(const String& x, const numbirch::Array<Real,2>& y) {
  #line 233 "src/basic/String.birch"
  return x + to_string(y);
}


/**
 * String concatenation.
 */
#line 239 "src/basic/String.birch"
String operator+(const String& x, const numbirch::Array<Integer,2>& y) {
  #line 240 "src/basic/String.birch"
  return x + to_string(y);
}


/**
 * String concatenation.
 */
#line 246 "src/basic/String.birch"
String operator+(const Boolean& x, const String& y) {
  #line 247 "src/basic/String.birch"
  return to_string(x) + y;
}


/**
 * String concatenation.
 */
#line 253 "src/basic/String.birch"
String operator+(const Real& x, const String& y) {
  #line 254 "src/basic/String.birch"
  return to_string(x) + y;
}


/**
 * String concatenation.
 */
#line 260 "src/basic/String.birch"
String operator+(const Integer& x, const String& y) {
  #line 261 "src/basic/String.birch"
  return to_string(x) + y;
}


/**
 * String concatenation.
 */
#line 267 "src/basic/String.birch"
String operator+(const numbirch::Array<Boolean,1>& x, const String& y) {
  #line 268 "src/basic/String.birch"
  return to_string(x) + y;
}


/**
 * String concatenation.
 */
#line 274 "src/basic/String.birch"
String operator+(const numbirch::Array<Real,1>& x, const String& y) {
  #line 275 "src/basic/String.birch"
  return to_string(x) + y;
}


/**
 * String concatenation.
 */
#line 281 "src/basic/String.birch"
String operator+(const numbirch::Array<Integer,1>& x, const String& y) {
  #line 282 "src/basic/String.birch"
  return to_string(x) + y;
}


/**
 * String concatenation.
 */
#line 288 "src/basic/String.birch"
String operator+(const numbirch::Array<Boolean,2>& x, const String& y) {
  #line 289 "src/basic/String.birch"
  return to_string(x) + y;
}


/**
 * String concatenation.
 */
#line 295 "src/basic/String.birch"
String operator+(const numbirch::Array<Real,2>& x, const String& y) {
  #line 296 "src/basic/String.birch"
  return to_string(x) + y;
}


/**
 * String concatenation.
 */
#line 302 "src/basic/String.birch"
String operator+(const numbirch::Array<Integer,2>& x, const String& y) {
  #line 303 "src/basic/String.birch"
  return to_string(x) + y;
}


/**
 * Length of a string.
 */
#line 309 "src/basic/String.birch"
Integer length(const String& x) {
  #line 310 "src/basic/String.birch"

  return x.length();
  }

}
