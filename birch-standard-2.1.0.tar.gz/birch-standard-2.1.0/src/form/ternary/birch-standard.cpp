namespace birch {
#line 34 "src/form/ternary/LogZConwayMaxwellPoisson.birch"
Real logz_conway_maxwell_poisson(const Real& \u03bc, const Real& \u03bd, const Integer& n) {
  auto log_\u03bb = \u03bd * log(\u03bc);
  auto mode = min(\u03bc, cast<Real>(n));
  auto mx = mode * log_\u03bb - \u03bd * lfact(mode);
  auto log_xf = Real(0.0);
  auto Z = exp(-(mx));
  #line 45 "src/form/ternary/LogZConwayMaxwellPoisson.birch"
  for (int x = int(1); x <= int(n); ++x) {
    #line 46 "src/form/ternary/LogZConwayMaxwellPoisson.birch"
    log_xf = log_xf + log(x);
    #line 47 "src/form/ternary/LogZConwayMaxwellPoisson.birch"
    Z = Z + exp(x * log_\u03bb - \u03bd * log_xf - mx);
  }
  #line 49 "src/form/ternary/LogZConwayMaxwellPoisson.birch"
  return mx + log(Z);
}

}
namespace birch {
}
namespace birch {
}
namespace birch {
}
