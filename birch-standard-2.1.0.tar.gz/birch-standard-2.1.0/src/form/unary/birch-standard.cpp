namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {

/**
 * Create identity matrix.
 *
 * @param n Number of rows and columns.
 */
#line 60 "src/form/unary/Diagonal.birch"
numbirch::Array<Real,2> identity(const Integer& n) {
  #line 61 "src/form/unary/Diagonal.birch"
  return diagonal(Real(1.0), n);
}

}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
namespace birch {
}
