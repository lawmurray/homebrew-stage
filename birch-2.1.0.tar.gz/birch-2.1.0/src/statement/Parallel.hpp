/**
 * @file
 */
#pragma once

#include "src/statement/Statement.hpp"
#include "src/expression/Expression.hpp"
#include "src/common/Annotated.hpp"
#include "src/common/Braced.hpp"

namespace birch {
/**
 * Parallel loop.
 *
 * @ingroup statement
 */
class Parallel: public Statement,
    public Annotated,
    public Braced {
public:
  /**
   * Constructor.
   *
   * @param annotation Annotation.
   * @param index Index.
   * @param from From expression.
   * @param to To expression.
   * @param braces Body of loop.
   * @param loc Location.
   */
  Parallel(const Annotation annotation, Statement* index, Expression* from,
      Expression* to, Statement* braces, Location* loc = nullptr);

  virtual void accept(Visitor* visitor) const;

  /**
   * Index.
   */
  Statement* index;

  /**
   * From expression.
   */
  Expression* from;

  /**
   * To expression.
   */
  Expression* to;
};
}
