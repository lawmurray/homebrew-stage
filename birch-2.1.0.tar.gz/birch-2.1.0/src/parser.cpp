/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Skeleton implementation for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2021 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C GLR parser skeleton written by Paul Hilfinger.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "glr.c"

/* Pure parsers.  */
#define YYPURE 0







# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "src/parser.hpp"

/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_PROGRAM = 3,                    /* PROGRAM  */
  YYSYMBOL_CLASS = 4,                      /* CLASS  */
  YYSYMBOL_STRUCT = 5,                     /* STRUCT  */
  YYSYMBOL_TYPE = 6,                       /* TYPE  */
  YYSYMBOL_FUNCTION = 7,                   /* FUNCTION  */
  YYSYMBOL_OPERATOR = 8,                   /* OPERATOR  */
  YYSYMBOL_AUTO = 9,                       /* AUTO  */
  YYSYMBOL_LET = 10,                       /* LET  */
  YYSYMBOL_IF = 11,                        /* IF  */
  YYSYMBOL_ELSE = 12,                      /* ELSE  */
  YYSYMBOL_FOR = 13,                       /* FOR  */
  YYSYMBOL_IN = 14,                        /* IN  */
  YYSYMBOL_WHILE = 15,                     /* WHILE  */
  YYSYMBOL_DO = 16,                        /* DO  */
  YYSYMBOL_WITH = 17,                      /* WITH  */
  YYSYMBOL_ASSERT = 18,                    /* ASSERT  */
  YYSYMBOL_RETURN = 19,                    /* RETURN  */
  YYSYMBOL_FACTOR = 20,                    /* FACTOR  */
  YYSYMBOL_PHANTOM = 21,                   /* PHANTOM  */
  YYSYMBOL_CPP = 22,                       /* CPP  */
  YYSYMBOL_HPP = 23,                       /* HPP  */
  YYSYMBOL_THIS = 24,                      /* THIS  */
  YYSYMBOL_SUPER = 25,                     /* SUPER  */
  YYSYMBOL_GLOBAL = 26,                    /* GLOBAL  */
  YYSYMBOL_PARALLEL = 27,                  /* PARALLEL  */
  YYSYMBOL_DYNAMIC = 28,                   /* DYNAMIC  */
  YYSYMBOL_ABSTRACT = 29,                  /* ABSTRACT  */
  YYSYMBOL_OVERRIDE = 30,                  /* OVERRIDE  */
  YYSYMBOL_FINAL = 31,                     /* FINAL  */
  YYSYMBOL_ACYCLIC = 32,                   /* ACYCLIC  */
  YYSYMBOL_NIL = 33,                       /* NIL  */
  YYSYMBOL_DOUBLE_BRACE_OPEN = 34,         /* DOUBLE_BRACE_OPEN  */
  YYSYMBOL_DOUBLE_BRACE_CLOSE = 35,        /* DOUBLE_BRACE_CLOSE  */
  YYSYMBOL_NAME = 36,                      /* NAME  */
  YYSYMBOL_BOOL_LITERAL = 37,              /* BOOL_LITERAL  */
  YYSYMBOL_INT_LITERAL = 38,               /* INT_LITERAL  */
  YYSYMBOL_REAL_LITERAL = 39,              /* REAL_LITERAL  */
  YYSYMBOL_STRING_LITERAL = 40,            /* STRING_LITERAL  */
  YYSYMBOL_LEFT_OP = 41,                   /* LEFT_OP  */
  YYSYMBOL_RIGHT_OP = 42,                  /* RIGHT_OP  */
  YYSYMBOL_LEFT_TILDE_OP = 43,             /* LEFT_TILDE_OP  */
  YYSYMBOL_RIGHT_TILDE_OP = 44,            /* RIGHT_TILDE_OP  */
  YYSYMBOL_LEFT_QUERY_OP = 45,             /* LEFT_QUERY_OP  */
  YYSYMBOL_AND_OP = 46,                    /* AND_OP  */
  YYSYMBOL_OR_OP = 47,                     /* OR_OP  */
  YYSYMBOL_LE_OP = 48,                     /* LE_OP  */
  YYSYMBOL_GE_OP = 49,                     /* GE_OP  */
  YYSYMBOL_EQ_OP = 50,                     /* EQ_OP  */
  YYSYMBOL_NE_OP = 51,                     /* NE_OP  */
  YYSYMBOL_RANGE_OP = 52,                  /* RANGE_OP  */
  YYSYMBOL_53_ = 53,                       /* '('  */
  YYSYMBOL_54_ = 54,                       /* ')'  */
  YYSYMBOL_55_ = 55,                       /* '['  */
  YYSYMBOL_56_ = 56,                       /* ']'  */
  YYSYMBOL_57_ = 57,                       /* '?'  */
  YYSYMBOL_58_ = 58,                       /* '\\'  */
  YYSYMBOL_59_ = 59,                       /* ','  */
  YYSYMBOL_60_ = 60,                       /* '.'  */
  YYSYMBOL_61_ = 61,                       /* '!'  */
  YYSYMBOL_62_ = 62,                       /* '+'  */
  YYSYMBOL_63_ = 63,                       /* '-'  */
  YYSYMBOL_64_ = 64,                       /* '*'  */
  YYSYMBOL_65_ = 65,                       /* '/'  */
  YYSYMBOL_66_ = 66,                       /* '<'  */
  YYSYMBOL_67_ = 67,                       /* '>'  */
  YYSYMBOL_68_ = 68,                       /* '~'  */
  YYSYMBOL_69_ = 69,                       /* ':'  */
  YYSYMBOL_70___ = 70,                     /* '_'  */
  YYSYMBOL_71_ = 71,                       /* ';'  */
  YYSYMBOL_72_ = 72,                       /* '='  */
  YYSYMBOL_73_ = 73,                       /* '{'  */
  YYSYMBOL_74_ = 74,                       /* '}'  */
  YYSYMBOL_75_ = 75,                       /* '&'  */
  YYSYMBOL_YYACCEPT = 76,                  /* $accept  */
  YYSYMBOL_name = 77,                      /* name  */
  YYSYMBOL_bool_literal = 78,              /* bool_literal  */
  YYSYMBOL_int_literal = 79,               /* int_literal  */
  YYSYMBOL_real_literal = 80,              /* real_literal  */
  YYSYMBOL_string_literal = 81,            /* string_literal  */
  YYSYMBOL_literal = 82,                   /* literal  */
  YYSYMBOL_identifier = 83,                /* identifier  */
  YYSYMBOL_parens_expression = 84,         /* parens_expression  */
  YYSYMBOL_sequence_expression = 85,       /* sequence_expression  */
  YYSYMBOL_cast_expression = 86,           /* cast_expression  */
  YYSYMBOL_function_expression = 87,       /* function_expression  */
  YYSYMBOL_this_expression = 88,           /* this_expression  */
  YYSYMBOL_super_expression = 89,          /* super_expression  */
  YYSYMBOL_nil_expression = 90,            /* nil_expression  */
  YYSYMBOL_primary_expression = 91,        /* primary_expression  */
  YYSYMBOL_slice_expression = 92,          /* slice_expression  */
  YYSYMBOL_slice_expression_list = 93,     /* slice_expression_list  */
  YYSYMBOL_slice = 94,                     /* slice  */
  YYSYMBOL_postfix_expression = 95,        /* postfix_expression  */
  YYSYMBOL_query_expression = 96,          /* query_expression  */
  YYSYMBOL_prefix_operator = 97,           /* prefix_operator  */
  YYSYMBOL_prefix_expression = 98,         /* prefix_expression  */
  YYSYMBOL_multiplicative_operator = 99,   /* multiplicative_operator  */
  YYSYMBOL_multiplicative_expression = 100, /* multiplicative_expression  */
  YYSYMBOL_additive_operator = 101,        /* additive_operator  */
  YYSYMBOL_additive_expression = 102,      /* additive_expression  */
  YYSYMBOL_relational_operator = 103,      /* relational_operator  */
  YYSYMBOL_relational_expression = 104,    /* relational_expression  */
  YYSYMBOL_equality_operator = 105,        /* equality_operator  */
  YYSYMBOL_equality_expression = 106,      /* equality_expression  */
  YYSYMBOL_logical_and_operator = 107,     /* logical_and_operator  */
  YYSYMBOL_logical_and_expression = 108,   /* logical_and_expression  */
  YYSYMBOL_logical_or_operator = 109,      /* logical_or_operator  */
  YYSYMBOL_logical_or_expression = 110,    /* logical_or_expression  */
  YYSYMBOL_assign_operator = 111,          /* assign_operator  */
  YYSYMBOL_assign_expression = 112,        /* assign_expression  */
  YYSYMBOL_expression = 113,               /* expression  */
  YYSYMBOL_optional_expression = 114,      /* optional_expression  */
  YYSYMBOL_expression_list = 115,          /* expression_list  */
  YYSYMBOL_span_expression = 116,          /* span_expression  */
  YYSYMBOL_span_list = 117,                /* span_list  */
  YYSYMBOL_brackets = 118,                 /* brackets  */
  YYSYMBOL_parameters = 119,               /* parameters  */
  YYSYMBOL_optional_parameters = 120,      /* optional_parameters  */
  YYSYMBOL_parameter_list = 121,           /* parameter_list  */
  YYSYMBOL_parameter = 122,                /* parameter  */
  YYSYMBOL_options = 123,                  /* options  */
  YYSYMBOL_option_list = 124,              /* option_list  */
  YYSYMBOL_option = 125,                   /* option  */
  YYSYMBOL_arguments = 126,                /* arguments  */
  YYSYMBOL_optional_arguments = 127,       /* optional_arguments  */
  YYSYMBOL_shape = 128,                    /* shape  */
  YYSYMBOL_generics = 129,                 /* generics  */
  YYSYMBOL_generic_list = 130,             /* generic_list  */
  YYSYMBOL_generic = 131,                  /* generic  */
  YYSYMBOL_optional_generics = 132,        /* optional_generics  */
  YYSYMBOL_generic_arguments = 133,        /* generic_arguments  */
  YYSYMBOL_generic_argument_list = 134,    /* generic_argument_list  */
  YYSYMBOL_generic_argument = 135,         /* generic_argument  */
  YYSYMBOL_optional_generic_arguments = 136, /* optional_generic_arguments  */
  YYSYMBOL_init_operator = 137,            /* init_operator  */
  YYSYMBOL_global_variable_declaration = 138, /* global_variable_declaration  */
  YYSYMBOL_member_variable_declaration = 139, /* member_variable_declaration  */
  YYSYMBOL_member_phantom_declaration = 140, /* member_phantom_declaration  */
  YYSYMBOL_local_variable_declaration = 141, /* local_variable_declaration  */
  YYSYMBOL_tuple_variable = 142,           /* tuple_variable  */
  YYSYMBOL_tuple_variables = 143,          /* tuple_variables  */
  YYSYMBOL_tuple_variables_declaration = 144, /* tuple_variables_declaration  */
  YYSYMBOL_function_declaration = 145,     /* function_declaration  */
  YYSYMBOL_146_1 = 146,                    /* $@1  */
  YYSYMBOL_member_function_annotation = 147, /* member_function_annotation  */
  YYSYMBOL_member_function_declaration = 148, /* member_function_declaration  */
  YYSYMBOL_149_2 = 149,                    /* $@2  */
  YYSYMBOL_150_3 = 150,                    /* $@3  */
  YYSYMBOL_program_declaration = 151,      /* program_declaration  */
  YYSYMBOL_152_4 = 152,                    /* $@4  */
  YYSYMBOL_binary_operator = 153,          /* binary_operator  */
  YYSYMBOL_binary_operator_declaration = 154, /* binary_operator_declaration  */
  YYSYMBOL_155_5 = 155,                    /* $@5  */
  YYSYMBOL_unary_operator = 156,           /* unary_operator  */
  YYSYMBOL_unary_operator_declaration = 157, /* unary_operator_declaration  */
  YYSYMBOL_158_6 = 158,                    /* $@6  */
  YYSYMBOL_assignment_operator_declaration = 159, /* assignment_operator_declaration  */
  YYSYMBOL_160_7 = 160,                    /* $@7  */
  YYSYMBOL_conversion_operator_declaration = 161, /* conversion_operator_declaration  */
  YYSYMBOL_162_8 = 162,                    /* $@8  */
  YYSYMBOL_slice_operator_declaration = 163, /* slice_operator_declaration  */
  YYSYMBOL_164_9 = 164,                    /* $@9  */
  YYSYMBOL_class_annotation = 165,         /* class_annotation  */
  YYSYMBOL_class_declaration = 166,        /* class_declaration  */
  YYSYMBOL_167_10 = 167,                   /* $@10  */
  YYSYMBOL_168_11 = 168,                   /* $@11  */
  YYSYMBOL_169_12 = 169,                   /* $@12  */
  YYSYMBOL_struct_declaration = 170,       /* struct_declaration  */
  YYSYMBOL_171_13 = 171,                   /* $@13  */
  YYSYMBOL_172_14 = 172,                   /* $@14  */
  YYSYMBOL_173_15 = 173,                   /* $@15  */
  YYSYMBOL_basic_declaration = 174,        /* basic_declaration  */
  YYSYMBOL_cpp = 175,                      /* cpp  */
  YYSYMBOL_hpp = 176,                      /* hpp  */
  YYSYMBOL_expression_statement = 177,     /* expression_statement  */
  YYSYMBOL_if = 178,                       /* if  */
  YYSYMBOL_for_variable_declaration = 179, /* for_variable_declaration  */
  YYSYMBOL_for = 180,                      /* for  */
  YYSYMBOL_parallel_annotation = 181,      /* parallel_annotation  */
  YYSYMBOL_parallel = 182,                 /* parallel  */
  YYSYMBOL_while = 183,                    /* while  */
  YYSYMBOL_do_while = 184,                 /* do_while  */
  YYSYMBOL_with = 185,                     /* with  */
  YYSYMBOL_block = 186,                    /* block  */
  YYSYMBOL_assertion = 187,                /* assertion  */
  YYSYMBOL_return = 188,                   /* return  */
  YYSYMBOL_factor = 189,                   /* factor  */
  YYSYMBOL_statement = 190,                /* statement  */
  YYSYMBOL_statements = 191,               /* statements  */
  YYSYMBOL_optional_statements = 192,      /* optional_statements  */
  YYSYMBOL_class_statement = 193,          /* class_statement  */
  YYSYMBOL_class_statements = 194,         /* class_statements  */
  YYSYMBOL_optional_class_statements = 195, /* optional_class_statements  */
  YYSYMBOL_struct_statement = 196,         /* struct_statement  */
  YYSYMBOL_struct_statements = 197,        /* struct_statements  */
  YYSYMBOL_optional_struct_statements = 198, /* optional_struct_statements  */
  YYSYMBOL_file_statement = 199,           /* file_statement  */
  YYSYMBOL_file_statements = 200,          /* file_statements  */
  YYSYMBOL_optional_file_statements = 201, /* optional_file_statements  */
  YYSYMBOL_file = 202,                     /* file  */
  YYSYMBOL_return_type = 203,              /* return_type  */
  YYSYMBOL_optional_return_type = 204,     /* optional_return_type  */
  YYSYMBOL_optional_auto_return_type = 205, /* optional_auto_return_type  */
  YYSYMBOL_braces = 206,                   /* braces  */
  YYSYMBOL_optional_braces = 207,          /* optional_braces  */
  YYSYMBOL_class_braces = 208,             /* class_braces  */
  YYSYMBOL_optional_class_braces = 209,    /* optional_class_braces  */
  YYSYMBOL_struct_braces = 210,            /* struct_braces  */
  YYSYMBOL_optional_struct_braces = 211,   /* optional_struct_braces  */
  YYSYMBOL_double_braces = 212,            /* double_braces  */
  YYSYMBOL_named_type = 213,               /* named_type  */
  YYSYMBOL_primary_type = 214,             /* primary_type  */
  YYSYMBOL_type = 215,                     /* type  */
  YYSYMBOL_type_list = 216                 /* type_list  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;


/* Default (constant) value used for initialization for null
   right-hand sides.  Unlike the standard yacc.c template, here we set
   the default value of $$ to a zeroed-out value.  Since the default
   value is undefined, this behavior is technically correct.  */
static YYSTYPE yyval_default;
static YYLTYPE yyloc_default
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
  = { 1, 1, 1, 1 }
# endif
;


/* Unqualified %code blocks.  */
#line 6 "src/parser.ypp"

  #include "src/expression/all.hpp"
  #include "src/statement/all.hpp"
  #include "src/type/all.hpp"

  /**
   * Raw string stack.
   */
  std::stack<std::string> raws;

  /**
   * Push the current raw string onto the stack, and restart it.
   */
  void push_raw() {
    raws.push(raw.str());
    raw.str("");
  }

  /**
   * Pop a raw string from the stack.
   */
  std::string pop_raw() {
    std::string raw = raws.top();
    raws.pop();
    return raw;
  }

  /**
   * Make a location, without documentation string.
   */
  birch::Location* make_loc(YYLTYPE& loc) {
    return new birch::Location(compiler->file, loc.first_line, loc.last_line,
        loc.first_column, loc.last_column);
  }

  /**
   * Make a location, with documentation string.
   */
  birch::Location* make_doc_loc(YYLTYPE& loc) {
    return new birch::Location(compiler->file, loc.first_line, loc.last_line,
        loc.first_column, loc.last_column, pop_raw());
  }

  /**
   * Make an empty name.
   */
  birch::Name* empty_name(YYLTYPE& loc) {
    return new birch::Name();
  }

  /**
   * Make an empty expression.
   */
  birch::Expression* empty_expr(YYLTYPE& loc) {
    return new birch::EmptyExpression(make_loc(loc));
  }

  /**
   * Make an empty statement.
   */
  birch::Statement* empty_stmt(YYLTYPE& loc) {
    return new birch::EmptyStatement(make_loc(loc));
  }

  /**
   * Make an empty type.
   */
  birch::Type* empty_type(YYLTYPE& loc) {
    return new birch::EmptyType(make_loc(loc));
  }

#line 391 "src/parser.cpp"

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif
#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YYFREE
# define YYFREE free
#endif
#ifndef YYMALLOC
# define YYMALLOC malloc
#endif
#ifndef YYREALLOC
# define YYREALLOC realloc
#endif

#ifdef __cplusplus
  typedef bool yybool;
# define yytrue true
# define yyfalse false
#else
  /* When we move to stdbool, get rid of the various casts to yybool.  */
  typedef signed char yybool;
# define yytrue 1
# define yyfalse 0
#endif

#ifndef YYSETJMP
# include <setjmp.h>
# define YYJMP_BUF jmp_buf
# define YYSETJMP(Env) setjmp (Env)
/* Pacify Clang and ICC.  */
# define YYLONGJMP(Env, Val)                    \
 do {                                           \
   longjmp (Env, Val);                          \
   YY_ASSERT (0);                               \
 } while (yyfalse)
#endif

#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* The _Noreturn keyword of C11.  */
#ifndef _Noreturn
# if (defined __cplusplus \
      && ((201103 <= __cplusplus && !(__GNUC__ == 4 && __GNUC_MINOR__ == 7)) \
          || (defined _MSC_VER && 1900 <= _MSC_VER)))
#  define _Noreturn [[noreturn]]
# elif ((!defined __cplusplus || defined __clang__) \
        && (201112 <= (defined __STDC_VERSION__ ? __STDC_VERSION__ : 0) \
            || (!defined __STRICT_ANSI__ \
                && (4 < __GNUC__ + (7 <= __GNUC_MINOR__) \
                    || (defined __apple_build_version__ \
                        ? 6000000 <= __apple_build_version__ \
                        : 3 < __clang_major__ + (5 <= __clang_minor__))))))
   /* _Noreturn works as-is.  */
# elif (2 < __GNUC__ + (8 <= __GNUC_MINOR__) || defined __clang__ \
        || 0x5110 <= __SUNPRO_C)
#  define _Noreturn __attribute__ ((__noreturn__))
# elif 1200 <= (defined _MSC_VER ? _MSC_VER : 0)
#  define _Noreturn __declspec (noreturn)
# else
#  define _Noreturn
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  42
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   550

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  76
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  141
/* YYNRULES -- Number of rules.  */
#define YYNRULES  287
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  492
/* YYMAXRHS -- Maximum number of symbols on right-hand side of rule.  */
#define YYMAXRHS 10
/* YYMAXLEFT -- Maximum number of symbols to the left of a handle
   accessed by $0, $-1, etc., in any rule.  */
#define YYMAXLEFT 0

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   307

/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    61,     2,     2,     2,     2,    75,     2,
      53,    54,    64,    62,    59,    63,    60,    65,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    69,    71,
      66,    72,    67,    57,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    55,    58,    56,     2,    70,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    73,     2,    74,    68,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52
};

#if YYDEBUG
/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   170,   170,   178,   182,   186,   190,   194,   195,   196,
     197,   201,   205,   209,   213,   217,   221,   225,   229,   233,
     234,   235,   236,   237,   238,   239,   240,   244,   245,   249,
     250,   254,   258,   259,   260,   261,   262,   263,   264,   270,
     271,   275,   276,   277,   281,   282,   286,   287,   291,   292,
     296,   297,   301,   302,   306,   307,   308,   309,   318,   319,
     323,   324,   328,   329,   333,   337,   338,   342,   346,   347,
     351,   352,   353,   354,   355,   359,   360,   364,   368,   369,
     373,   374,   378,   382,   383,   387,   391,   392,   396,   397,
     401,   402,   406,   410,   411,   415,   416,   420,   421,   425,
     426,   430,   431,   435,   436,   440,   441,   445,   446,   450,
     454,   455,   459,   460,   464,   465,   469,   473,   474,   483,
     484,   485,   489,   490,   491,   492,   493,   497,   498,   499,
     500,   501,   505,   509,   510,   511,   512,   513,   514,   515,
     519,   523,   524,   528,   532,   532,   536,   537,   538,   539,
     545,   545,   546,   546,   550,   550,   554,   555,   556,   557,
     558,   559,   563,   563,   567,   571,   571,   575,   575,   579,
     579,   583,   583,   587,   588,   589,   590,   591,   595,   595,
     596,   596,   597,   597,   601,   601,   602,   602,   603,   603,
     607,   608,   609,   613,   617,   621,   625,   626,   627,   631,
     635,   639,   645,   646,   650,   654,   658,   662,   666,   670,
     674,   678,   679,   680,   681,   682,   683,   684,   685,   686,
     687,   688,   689,   690,   691,   695,   696,   700,   701,   705,
     706,   707,   708,   709,   710,   711,   715,   716,   720,   721,
     725,   726,   727,   731,   732,   736,   737,   741,   742,   743,
     744,   745,   746,   747,   748,   749,   750,   754,   755,   759,
     760,   764,   768,   772,   773,   777,   778,   782,   786,   787,
     791,   795,   796,   800,   804,   805,   809,   818,   819,   823,
     824,   828,   829,   830,   831,   832,   836,   837
};
#endif

#define YYPACT_NINF (-356)
#define YYTABLE_NINF (-261)

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     208,    25,    25,    25,    25,    15,    60,    60,  -356,    86,
    -356,  -356,    54,  -356,  -356,  -356,  -356,  -356,   138,  -356,
    -356,  -356,  -356,  -356,   316,  -356,  -356,   149,   109,   113,
     153,    15,    11,  -356,   122,   155,  -356,  -356,  -356,    51,
      25,  -356,  -356,    29,  -356,   -17,    25,  -356,    25,   143,
    -356,  -356,   139,   150,    84,  -356,    51,   152,   162,  -356,
       9,   166,  -356,   172,   191,   187,   -20,   129,    25,  -356,
     181,   177,   178,   212,  -356,    25,  -356,  -356,  -356,   186,
    -356,   483,    25,   216,   203,     6,  -356,   184,    25,  -356,
    -356,   353,   131,  -356,  -356,  -356,  -356,   120,   189,   465,
      -9,    51,  -356,    25,  -356,   424,  -356,  -356,  -356,   210,
     225,  -356,    25,    38,  -356,  -356,    51,  -356,  -356,  -356,
    -356,    51,  -356,  -356,  -356,  -356,  -356,  -356,  -356,  -356,
    -356,  -356,  -356,  -356,  -356,  -356,  -356,  -356,  -356,  -356,
      25,   227,   192,    51,  -356,  -356,   218,   229,   215,  -356,
    -356,  -356,  -356,   226,  -356,  -356,  -356,  -356,  -356,   465,
    -356,   465,   143,   223,  -356,  -356,  -356,  -356,  -356,  -356,
    -356,  -356,  -356,  -356,  -356,   232,  -356,  -356,   276,  -356,
     465,  -356,   123,   136,    58,   185,   247,   222,  -356,   235,
     241,   237,  -356,   238,   242,   245,  -356,   234,  -356,   236,
      25,   240,   117,  -356,    25,    66,   465,    25,   465,   239,
     465,   465,   465,   465,   295,  -356,    44,   243,  -356,  -356,
    -356,  -356,  -356,  -356,   282,  -356,  -356,  -356,  -356,  -356,
    -356,  -356,  -356,   424,  -356,   246,  -356,  -356,    25,   254,
     257,  -356,    94,  -356,  -356,   215,   -20,   215,   263,   212,
    -356,  -356,    51,    25,   272,   255,   212,   270,    25,   465,
    -356,    25,  -356,  -356,  -356,  -356,   465,   465,   465,   465,
     465,  -356,  -356,  -356,  -356,  -356,   465,   465,   465,  -356,
     192,   465,  -356,  -356,  -356,  -356,  -356,    25,    79,   465,
      31,    25,    31,   239,  -356,   321,   239,   315,   239,   269,
    -356,   271,   273,    25,    51,  -356,   328,  -356,  -356,  -356,
    -356,  -356,  -356,    25,   274,  -356,  -356,  -356,    94,  -356,
     277,  -356,   212,  -356,  -356,   284,  -356,  -356,  -356,   -20,
     300,  -356,   296,   303,   304,  -356,  -356,   123,   136,    58,
     185,   247,  -356,  -356,  -356,  -356,   289,   257,  -356,   130,
    -356,  -356,  -356,   465,  -356,   302,   308,   465,   352,   465,
    -356,   465,  -356,  -356,  -356,  -356,   356,   412,    25,    38,
     301,    51,  -356,  -356,  -356,   -20,  -356,  -356,   465,   465,
    -356,   465,  -356,  -356,    25,    16,  -356,  -356,   336,  -356,
    -356,   360,  -356,  -356,  -356,  -356,  -356,   130,  -356,   299,
     305,    25,    31,   310,    17,   322,   311,   465,  -356,   124,
     312,   465,   371,  -356,  -356,   413,   -20,  -356,   333,  -356,
    -356,    79,    15,    25,    51,    25,  -356,  -356,    25,  -356,
    -356,  -356,  -356,   465,  -356,  -356,  -356,   465,  -356,   343,
    -356,   329,  -356,   331,   465,  -356,   132,   332,   465,  -356,
    -356,  -356,   143,  -356,   349,   -20,    15,   338,   239,   465,
    -356,  -356,   358,  -356,   346,  -356,   347,   212,   -20,   377,
    -356,   143,  -356,  -356,   239,   465,  -356,  -356,  -356,  -356,
    -356,   212,  -356,   239,   -20,   -20,  -356,  -356,  -356,  -356,
     -20,  -356
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int16 yydefact[] =
{
     177,     0,     0,     0,     0,   111,     0,     0,   173,   174,
     175,     2,     0,   247,   248,   249,   250,   251,     0,   252,
     253,   254,   255,   256,   177,   259,   261,     0,     0,   111,
       0,   111,     0,   110,     0,     0,   193,   194,   176,     0,
       0,   258,     1,     0,   154,    89,     0,   192,     0,     0,
     105,   109,     0,   107,     0,   276,     0,   118,   279,   281,
       0,   111,    93,     0,     0,    95,     0,     0,     0,    88,
     186,     0,     0,   264,   106,     0,    43,    41,    42,     0,
     164,     0,     0,   286,     0,     0,   117,   277,     0,   119,
     120,     0,     0,   282,   283,   121,   122,     0,     0,     0,
      89,     0,    94,     0,   269,   228,   268,   155,    86,     0,
      90,   188,     0,     0,   190,   191,   266,   263,   265,   144,
     108,     0,    64,    67,    56,    57,    60,    61,    50,    51,
      46,    47,    54,    55,   156,   157,   158,   159,   160,   161,
       0,     0,     0,     0,   280,   112,     0,   114,   116,   278,
     284,    16,    17,     0,    18,     3,     4,     5,     6,     0,
      99,     0,     0,   118,     7,     8,     9,    10,    19,    20,
      21,    22,    23,    24,    25,     0,    26,    32,    39,    44,
       0,    48,    52,    58,    62,    65,    68,    75,    77,    80,
       0,   103,    82,    83,     0,     0,   125,     0,   123,     0,
       0,   180,    97,    96,     0,     0,     0,     0,     0,     0,
       0,     0,    79,    79,     0,   201,   118,     0,   211,   212,
     224,   213,   214,   215,     0,   216,   217,   218,   219,   220,
     221,   222,   223,   225,   227,     0,   207,    87,     0,     0,
     102,   275,   246,   274,   187,   262,     0,    92,     0,   264,
     287,   113,     0,     0,     0,     0,   264,    11,     0,     0,
      40,     0,    38,    36,    37,    45,     0,     0,     0,     0,
       0,    70,    72,    73,    71,    74,     0,     0,     0,   100,
       0,     0,    85,   285,   126,   124,   182,     0,     0,     0,
       0,     0,     0,     0,   199,     0,     0,     0,     0,     0,
      78,     0,     0,     0,     0,   195,     0,   226,   267,    91,
     189,   101,   184,     0,     0,   240,   241,   242,   243,   245,
       0,   145,   264,   165,   115,   118,    34,    12,    13,     0,
       0,    33,    29,     0,    28,    35,    49,    53,    59,    63,
      66,    69,    76,    81,   104,    84,     0,   102,   272,   239,
     271,   181,    98,     0,   140,   141,     0,     0,   198,     0,
     204,     0,   206,   208,   209,   210,     0,     0,     0,     0,
       0,     0,   244,   273,   162,     0,    11,    15,     0,     0,
      31,     0,   183,   178,     0,     0,   146,   148,   147,   229,
     230,     0,   231,   232,   233,   234,   235,   236,   238,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   135,     0,
       0,     0,     0,   185,   132,     0,     0,   166,     0,    30,
      27,     0,   111,     0,     0,     0,   169,   149,     0,   237,
     270,   133,   142,     0,   134,   197,   196,     0,   205,     0,
     138,     0,   136,     0,     0,   127,     0,     0,     0,   163,
      14,   179,     0,   167,     0,     0,   111,     0,     0,     0,
     139,   137,     0,   130,     0,   128,     0,   264,     0,     0,
     170,     0,   143,   200,     0,     0,   131,   129,   152,   168,
     171,   264,   203,     0,     0,     0,   150,   202,   153,   172,
       0,   151
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -356,     0,  -356,  -356,  -356,  -356,  -356,   -41,  -356,  -356,
    -356,  -356,  -356,  -356,  -356,  -356,  -356,    41,  -356,  -356,
    -356,   367,  -158,   341,   159,   348,   168,   357,   158,   364,
     160,   366,   182,   285,  -356,  -356,   194,   -79,   262,  -142,
    -356,   195,  -336,   -40,   359,  -228,   -48,  -356,   375,  -356,
     -52,   141,   213,  -356,   417,  -356,   -24,  -356,   244,  -356,
     -42,  -267,  -356,  -311,  -308,  -356,  -356,    93,  -356,  -356,
    -356,  -356,  -356,  -356,  -356,  -356,  -356,  -356,  -356,  -356,
    -356,  -356,  -356,  -356,  -356,  -356,  -356,  -356,  -356,  -356,
    -356,  -356,  -356,  -356,  -356,  -356,  -356,  -356,  -356,   -89,
    -221,  -356,    91,  -270,  -356,  -356,  -356,  -356,  -356,  -356,
    -356,  -356,  -356,  -356,  -356,   266,  -356,  -356,   103,  -356,
    -356,   188,  -356,  -356,   484,  -356,  -356,  -355,  -356,  -238,
     -70,  -234,  -356,    88,  -356,   142,   500,   -19,  -356,   -25,
     369
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,   163,   164,   165,   166,   167,   168,   169,   170,   171,
     172,   173,   174,   175,   176,   177,   332,   333,   263,   178,
     179,   180,   181,   266,   182,   267,   183,   268,   184,   269,
     185,   270,   186,   139,   187,   277,   188,   189,   301,   190,
     193,   194,    97,    69,    70,   109,   110,    44,    64,    65,
     311,   312,   195,    33,    52,    53,    34,    86,   146,   147,
     257,    99,    13,   315,   316,   218,   355,   356,   219,    14,
     246,   391,   392,   490,   484,    15,    66,   140,    16,   416,
      82,    17,   375,   393,   468,   394,   455,   395,   485,    18,
      19,   421,   288,   346,    20,   369,   113,   239,    21,    22,
      23,   221,   222,   295,   223,   224,   225,   226,   227,   228,
     229,   230,   231,   232,   233,   234,   235,   397,   398,   399,
     318,   319,   320,    24,    25,    26,    27,   117,   118,   119,
     106,   107,   350,   351,   243,   244,    36,    58,    59,    83,
      84
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      12,    28,    29,    30,    31,    45,    81,    49,    98,    73,
     309,   323,   321,   192,    60,    87,   220,   254,   329,   255,
     199,   317,   265,   353,    12,   357,   217,    71,   206,    72,
     426,   409,    51,   366,   141,   236,    67,   100,   389,    57,
      61,   390,    11,    63,    67,   197,    57,    11,    57,   111,
      89,   104,    90,   105,    79,    68,    57,   423,   424,    56,
     148,    11,    91,   200,    92,    11,    93,    79,    57,   150,
      94,   425,    89,   145,    90,    51,   202,    95,    50,   446,
      96,    32,    79,    62,   374,    57,   389,    11,    57,   390,
     105,   245,   248,   240,    35,   377,   247,   317,   412,    95,
     411,    57,    11,    63,    56,   216,   124,   125,   336,   241,
      85,   242,    57,   304,   480,   313,    57,     7,    38,   291,
      11,    57,   256,    39,   132,   133,   264,   293,   396,   296,
      11,   298,   299,   300,   300,   433,   343,   384,   385,   297,
      79,   417,    40,    57,   220,    76,    77,    78,   448,    42,
     348,   313,   349,     7,   217,   151,   152,   153,   289,   386,
     387,   388,    43,   236,   154,    11,    11,    11,   155,   156,
     157,   158,   142,    91,    93,    54,   396,    91,    94,    32,
     334,   286,   449,   108,   159,    91,   161,   130,   131,   162,
      55,   196,    76,    77,    78,   440,    67,   454,   128,   129,
      57,   191,   192,   463,   290,   292,    74,   294,  -260,    75,
     352,     1,   326,     2,     3,     4,     5,   331,    85,    46,
     335,   470,    88,   358,    47,    48,   360,   148,   362,   478,
       6,     7,    32,   216,   479,   126,   127,     8,    79,     9,
      10,   101,   314,   486,    11,   102,   103,   112,   114,   115,
     488,   489,    57,   325,   116,   121,   491,   144,   325,   149,
     198,   325,   191,   271,   237,   272,   273,   274,   347,   123,
     142,   142,    93,    93,   400,   143,    94,    94,   403,   367,
     405,   249,   406,   376,   238,   251,   253,    57,   252,    85,
     275,   354,   258,   122,   278,   279,   280,   281,   282,   418,
     334,   283,   420,   294,    57,   284,   287,   285,   303,   306,
      91,   328,   105,   370,   305,   410,  -257,   322,   314,     1,
     308,     2,     3,     4,     5,   310,   327,   330,   439,    91,
     361,   259,   443,   260,   436,   359,   261,   262,     6,     7,
     363,   368,   364,   371,   365,     8,   415,     9,    10,   314,
      85,   373,    11,   378,   457,   379,   381,   441,   458,   380,
     382,   401,   402,   447,   404,   462,   427,   428,   294,   466,
     407,    57,   414,   430,   437,   453,   431,   151,   152,   153,
     474,   434,   438,   442,   422,   444,   154,   450,   473,    11,
     155,   156,   157,   158,   464,   459,   483,   314,   452,   245,
     460,   354,   461,   465,   482,   469,   159,   160,   161,   472,
     475,   162,   467,   487,    76,    77,    78,   476,   477,   424,
     419,    80,   134,    79,    57,    79,   337,   339,   456,   135,
     340,   481,   471,   204,   205,   206,   338,   207,   136,   208,
     209,   210,   211,   212,   213,   137,     6,   138,   151,   152,
     153,   214,   215,    89,    89,    90,    90,   154,   341,   201,
      11,   155,   156,   157,   158,    91,    91,    92,    92,    93,
      93,   342,   276,    94,    94,   302,   345,   159,   203,   161,
      95,    95,   162,   408,   445,    76,    77,    78,   383,   151,
     152,   153,   120,   344,   432,   435,   324,   105,   154,   307,
     429,    11,   155,   156,   157,   158,   372,    37,    41,   451,
       0,   413,   250,     0,     0,     0,     0,     0,   159,     0,
     161,     0,     0,   162,     0,     0,    76,    77,    78,   122,
     123,   124,   125,   126,   127,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   128,   129,   130,   131,   132,
     133
};

static const yytype_int16 yycheck[] =
{
       0,     1,     2,     3,     4,    29,    54,    31,    60,    49,
     238,   249,   246,    92,    39,    57,   105,   159,   256,   161,
      99,   242,   180,   290,    24,   292,   105,    46,    11,    48,
     385,   367,    32,   303,    82,   105,    53,    61,   349,    39,
      40,   349,    36,    43,    53,    97,    46,    36,    48,    68,
      41,    71,    43,    73,    54,    72,    56,    41,    42,    53,
      85,    36,    53,    72,    55,    36,    57,    67,    68,    88,
      61,    55,    41,    67,    43,    75,   101,    68,    67,   415,
      71,    66,    82,    54,   322,    85,   397,    36,    88,   397,
      73,   116,   140,   112,    34,   329,   121,   318,   368,    68,
     367,   101,    36,   103,    53,   105,    48,    49,   266,    71,
      66,    73,   112,    69,   469,    21,   116,    23,    32,    53,
      36,   121,   162,    69,    66,    67,   178,   206,   349,   208,
      36,   210,   211,   212,   213,   402,   278,     7,     8,   209,
     140,   375,     4,   143,   233,    61,    62,    63,   415,     0,
      71,    21,    73,    23,   233,    24,    25,    26,    41,    29,
      30,    31,    53,   233,    33,    36,    36,    36,    37,    38,
      39,    40,    55,    53,    57,    53,   397,    53,    61,    66,
     259,   200,   416,    54,    53,    53,    55,    64,    65,    58,
      35,    71,    61,    62,    63,    71,    53,   425,    62,    63,
     200,    70,   281,    71,   204,   205,    67,   207,     0,    59,
     289,     3,   253,     5,     6,     7,     8,   258,    66,    66,
     261,   455,    60,   293,    71,    72,   296,   252,   298,   467,
      22,    23,    66,   233,   468,    50,    51,    29,   238,    31,
      32,    69,   242,   481,    36,    54,    59,    66,    71,    71,
     484,   485,   252,   253,    42,    69,   490,    54,   258,    75,
      71,   261,    70,    41,    54,    43,    44,    45,   287,    47,
      55,    55,    57,    57,   353,    59,    61,    61,   357,   304,
     359,    54,   361,   325,    59,    67,    60,   287,    59,    66,
      68,   291,    60,    46,    59,    54,    59,    59,    56,   378,
     379,    56,   381,   303,   304,    71,    66,    71,    13,    27,
      53,    56,    73,   313,    71,   367,     0,    54,   318,     3,
      74,     5,     6,     7,     8,    71,    54,    57,   407,    53,
      15,    55,   411,    57,   404,    14,    60,    61,    22,    23,
      71,    13,    71,    69,    71,    29,   371,    31,    32,   349,
      66,    74,    36,    53,   433,    59,    52,   409,   437,    56,
      71,    59,    54,   415,    12,   444,    30,     7,   368,   448,
      14,   371,    71,    74,    52,   423,    71,    24,    25,    26,
     459,    71,    71,    71,   384,    14,    33,    54,   458,    36,
      37,    38,    39,    40,   446,    52,   475,   397,   422,   424,
      71,   401,    71,    71,   474,    56,    53,    54,    55,    71,
      52,    58,   452,   483,    61,    62,    63,    71,    71,    42,
     379,    54,    81,   423,   424,   425,   267,   269,   428,    81,
     270,   471,   456,     9,    10,    11,   268,    13,    81,    15,
      16,    17,    18,    19,    20,    81,    22,    81,    24,    25,
      26,    27,    28,    41,    41,    43,    43,    33,   276,   100,
      36,    37,    38,    39,    40,    53,    53,    55,    55,    57,
      57,   277,   187,    61,    61,   213,   281,    53,   103,    55,
      68,    68,    58,    71,    71,    61,    62,    63,   347,    24,
      25,    26,    75,   280,   401,   404,   252,    73,    33,   233,
     397,    36,    37,    38,    39,    40,   318,     7,    24,   421,
      -1,   369,   143,    -1,    -1,    -1,    -1,    -1,    53,    -1,
      55,    -1,    -1,    58,    -1,    -1,    61,    62,    63,    46,
      47,    48,    49,    50,    51,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    62,    63,    64,    65,    66,
      67
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     3,     5,     6,     7,     8,    22,    23,    29,    31,
      32,    36,    77,   138,   145,   151,   154,   157,   165,   166,
     170,   174,   175,   176,   199,   200,   201,   202,    77,    77,
      77,    77,    66,   129,   132,    34,   212,   212,    32,    69,
       4,   200,     0,    53,   123,   132,    66,    71,    72,   132,
      67,    77,   130,   131,    53,    35,    53,    77,   213,   214,
     215,    77,    54,    77,   124,   125,   152,    53,    72,   119,
     120,   213,   213,   119,    67,    59,    61,    62,    63,    77,
      97,   122,   156,   215,   216,    66,   133,   136,    60,    41,
      43,    53,    55,    57,    61,    68,    71,   118,   126,   137,
     132,    69,    54,    59,    71,    73,   206,   207,    54,   121,
     122,   213,    66,   172,    71,    71,    42,   203,   204,   205,
     130,    69,    46,    47,    48,    49,    50,    51,    62,    63,
      64,    65,    66,    67,    99,   101,   103,   105,   107,   109,
     153,   122,    55,    59,    54,    67,   134,   135,   215,    75,
     213,    24,    25,    26,    33,    37,    38,    39,    40,    53,
      54,    55,    58,    77,    78,    79,    80,    81,    82,    83,
      84,    85,    86,    87,    88,    89,    90,    91,    95,    96,
      97,    98,   100,   102,   104,   106,   108,   110,   112,   113,
     115,    70,   113,   116,   117,   128,    71,   126,    71,   113,
      72,   120,   215,   124,     9,    10,    11,    13,    15,    16,
      17,    18,    19,    20,    27,    28,    77,   113,   141,   144,
     175,   177,   178,   180,   181,   182,   183,   184,   185,   186,
     187,   188,   189,   190,   191,   192,   206,    54,    59,   173,
     213,    71,    73,   210,   211,   215,   146,   215,   122,    54,
     216,    67,    59,    60,   115,   115,   119,   136,    60,    55,
      57,    60,    61,    94,   126,    98,    99,   101,   103,   105,
     107,    41,    43,    44,    45,    68,   109,   111,    59,    54,
      59,    59,    56,    56,    71,    71,   213,    66,   168,    41,
      77,    53,    77,   113,    77,   179,   113,   206,   113,   113,
     113,   114,   114,    13,    69,    71,    27,   191,    74,   121,
      71,   126,   127,    21,    77,   139,   140,   176,   196,   197,
     198,   207,    54,   205,   134,    77,    83,    54,    56,   205,
      57,    83,    92,    93,   113,    83,    98,   100,   102,   104,
     106,   108,   112,   115,   128,   117,   169,   213,    71,    73,
     208,   209,   113,   137,    77,   142,   143,   137,   206,    14,
     206,    15,   206,    71,    71,    71,   179,   215,    13,   171,
      77,    69,   197,    74,   205,   158,   136,   207,    53,    59,
      56,    52,    71,   127,     7,     8,    29,    30,    31,   139,
     140,   147,   148,   159,   161,   163,   176,   193,   194,   195,
     113,    59,    54,   113,    12,   113,   113,    14,    71,   118,
     126,   137,   179,   211,    71,   215,   155,   207,   113,    93,
     113,   167,    77,    41,    42,    55,   203,    30,     7,   194,
      74,    71,   143,   137,    71,   178,   206,    52,    71,   113,
      71,   126,    71,   113,    14,    71,   118,   126,   137,   207,
      54,   209,   132,   122,   121,   162,    77,   113,   113,    52,
      71,    71,   113,    71,   126,    71,   113,   119,   160,    56,
     207,   132,    71,   206,   113,    52,    71,    71,   205,   207,
     203,   119,   206,   113,   150,   164,   205,   206,   207,   207,
     149,   207
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_uint8 yyr1[] =
{
       0,    76,    77,    78,    79,    80,    81,    82,    82,    82,
      82,    83,    84,    85,    86,    87,    88,    89,    90,    91,
      91,    91,    91,    91,    91,    91,    91,    92,    92,    93,
      93,    94,    95,    95,    95,    95,    95,    95,    95,    96,
      96,    97,    97,    97,    98,    98,    99,    99,   100,   100,
     101,   101,   102,   102,   103,   103,   103,   103,   104,   104,
     105,   105,   106,   106,   107,   108,   108,   109,   110,   110,
     111,   111,   111,   111,   111,   112,   112,   113,   114,   114,
     115,   115,   116,   117,   117,   118,   119,   119,   120,   120,
     121,   121,   122,   123,   123,   124,   124,   125,   125,   126,
     126,   127,   127,   128,   128,   129,   129,   130,   130,   131,
     132,   132,   133,   133,   134,   134,   135,   136,   136,   137,
     137,   137,   138,   138,   138,   138,   138,   139,   139,   139,
     139,   139,   140,   141,   141,   141,   141,   141,   141,   141,
     142,   143,   143,   144,   146,   145,   147,   147,   147,   147,
     149,   148,   150,   148,   152,   151,   153,   153,   153,   153,
     153,   153,   155,   154,   156,   158,   157,   160,   159,   162,
     161,   164,   163,   165,   165,   165,   165,   165,   167,   166,
     168,   166,   169,   166,   171,   170,   172,   170,   173,   170,
     174,   174,   174,   175,   176,   177,   178,   178,   178,   179,
     180,   181,   182,   182,   183,   184,   185,   186,   187,   188,
     189,   190,   190,   190,   190,   190,   190,   190,   190,   190,
     190,   190,   190,   190,   190,   191,   191,   192,   192,   193,
     193,   193,   193,   193,   193,   193,   194,   194,   195,   195,
     196,   196,   196,   197,   197,   198,   198,   199,   199,   199,
     199,   199,   199,   199,   199,   199,   199,   200,   200,   201,
     201,   202,   203,   204,   204,   205,   205,   206,   207,   207,
     208,   209,   209,   210,   211,   211,   212,   213,   213,   214,
     214,   215,   215,   215,   215,   215,   216,   216
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     2,     3,     3,     6,     4,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     3,     1,     1,
       3,     3,     1,     3,     3,     3,     2,     2,     2,     1,
       2,     1,     1,     1,     1,     2,     1,     1,     1,     3,
       1,     1,     1,     3,     1,     1,     1,     1,     1,     3,
       1,     1,     1,     3,     1,     1,     3,     1,     1,     3,
       1,     1,     1,     1,     1,     1,     3,     1,     1,     0,
       1,     3,     1,     1,     3,     3,     2,     3,     1,     0,
       1,     3,     3,     2,     3,     1,     3,     3,     5,     2,
       3,     1,     0,     1,     3,     2,     3,     1,     3,     1,
       1,     0,     2,     3,     1,     3,     1,     1,     0,     1,
       1,     1,     4,     5,     6,     5,     6,     4,     5,     6,
       5,     6,     3,     5,     5,     4,     5,     6,     5,     6,
       1,     1,     3,     7,     0,     7,     1,     1,     1,     2,
       0,     8,     0,     7,     0,     5,     1,     1,     1,     1,
       1,     1,     0,    10,     1,     0,     9,     0,     5,     0,
       4,     0,     7,     1,     1,     1,     2,     0,     0,    10,
       0,     7,     0,     8,     0,     9,     0,     6,     0,     7,
       5,     5,     3,     2,     2,     2,     5,     5,     3,     1,
       7,     1,     9,     8,     3,     5,     3,     1,     3,     3,
       3,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     2,     1,     0,     1,
       1,     1,     1,     1,     1,     1,     1,     2,     1,     0,
       1,     1,     1,     1,     2,     1,     0,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     2,     1,
       0,     1,     2,     1,     0,     1,     1,     3,     1,     1,
       3,     1,     1,     3,     1,     1,     2,     2,     3,     1,
       3,     1,     2,     2,     3,     4,     1,     3
};


/* YYDPREC[RULE-NUM] -- Dynamic precedence of rule #RULE-NUM (0 if none).  */
static const yytype_int8 yydprec[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     3,     2,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0
};

/* YYMERGER[RULE-NUM] -- Index of merging function for rule #RULE-NUM.  */
static const yytype_int8 yymerger[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0
};

/* YYIMMEDIATE[RULE-NUM] -- True iff rule #RULE-NUM is not to be deferred, as
   in the case of predicates.  */
static const yybool yyimmediate[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0
};

/* YYCONFLP[YYPACT[STATE-NUM]] -- Pointer into YYCONFL of start of
   list of conflicting reductions corresponding to action entry for
   state STATE-NUM in yytable.  0 means no conflicts.  The list in
   yyconfl is terminated by a rule number of 0.  */
static const yytype_int8 yyconflp[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       9,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     1,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     3,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     5,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     7,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    11,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      13,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0
};

/* YYCONFL[I] -- lists of conflicting rule numbers, each terminated by
   0, pointed into by YYCONFLP.  */
static const short yyconfl[] =
{
       0,   111,     0,   118,     0,   111,     0,   118,     0,   118,
       0,    11,     0,   118,     0
};


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;        \
          (Current).first_column = YYRHSLOC (Rhs, 1).first_column;      \
          (Current).last_line    = YYRHSLOC (Rhs, N).last_line;         \
          (Current).last_column  = YYRHSLOC (Rhs, N).last_column;       \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).first_line   = (Current).last_line   =              \
            YYRHSLOC (Rhs, 0).last_line;                                \
          (Current).first_column = (Current).last_column =              \
            YYRHSLOC (Rhs, 0).last_column;                              \
        }                                                               \
    while (0)
#endif

# define YYRHSLOC(Rhs, K) ((Rhs)[K].yystate.yyloc)


YYSTYPE yylval;
YYLTYPE yylloc;

int yynerrs;
int yychar;

enum { YYENOMEM = -2 };

typedef enum { yyok, yyaccept, yyabort, yyerr, yynomem } YYRESULTTAG;

#define YYCHK(YYE)                              \
  do {                                          \
    YYRESULTTAG yychk_flag = YYE;               \
    if (yychk_flag != yyok)                     \
      return yychk_flag;                        \
  } while (0)

/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYMAXDEPTH * sizeof (GLRStackItem)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif

/* Minimum number of free items on the stack allowed after an
   allocation.  This is to allow allocation and initialization
   to be completed by functions that call yyexpandGLRStack before the
   stack is expanded, thus insuring that all necessary pointers get
   properly redirected to new data.  */
#define YYHEADROOM 2

#ifndef YYSTACKEXPANDABLE
#  define YYSTACKEXPANDABLE 1
#endif

#if YYSTACKEXPANDABLE
# define YY_RESERVE_GLRSTACK(Yystack)                   \
  do {                                                  \
    if (Yystack->yyspaceLeft < YYHEADROOM)              \
      yyexpandGLRStack (Yystack);                       \
  } while (0)
#else
# define YY_RESERVE_GLRSTACK(Yystack)                   \
  do {                                                  \
    if (Yystack->yyspaceLeft < YYHEADROOM)              \
      yyMemoryExhausted (Yystack);                      \
  } while (0)
#endif

/** State numbers. */
typedef int yy_state_t;

/** Rule numbers. */
typedef int yyRuleNum;

/** Item references. */
typedef short yyItemNum;

typedef struct yyGLRState yyGLRState;
typedef struct yyGLRStateSet yyGLRStateSet;
typedef struct yySemanticOption yySemanticOption;
typedef union yyGLRStackItem yyGLRStackItem;
typedef struct yyGLRStack yyGLRStack;

struct yyGLRState
{
  /** Type tag: always true.  */
  yybool yyisState;
  /** Type tag for yysemantics.  If true, yyval applies, otherwise
   *  yyfirstVal applies.  */
  yybool yyresolved;
  /** Number of corresponding LALR(1) machine state.  */
  yy_state_t yylrState;
  /** Preceding state in this stack */
  yyGLRState* yypred;
  /** Source position of the last token produced by my symbol */
  YYPTRDIFF_T yyposn;
  union {
    /** First in a chain of alternative reductions producing the
     *  nonterminal corresponding to this state, threaded through
     *  yynext.  */
    yySemanticOption* yyfirstVal;
    /** Semantic value for this state.  */
    YYSTYPE yyval;
  } yysemantics;
  /** Source location for this state.  */
  YYLTYPE yyloc;
};

struct yyGLRStateSet
{
  yyGLRState** yystates;
  /** During nondeterministic operation, yylookaheadNeeds tracks which
   *  stacks have actually needed the current lookahead.  During deterministic
   *  operation, yylookaheadNeeds[0] is not maintained since it would merely
   *  duplicate yychar != YYEMPTY.  */
  yybool* yylookaheadNeeds;
  YYPTRDIFF_T yysize;
  YYPTRDIFF_T yycapacity;
};

struct yySemanticOption
{
  /** Type tag: always false.  */
  yybool yyisState;
  /** Rule number for this reduction */
  yyRuleNum yyrule;
  /** The last RHS state in the list of states to be reduced.  */
  yyGLRState* yystate;
  /** The lookahead for this reduction.  */
  int yyrawchar;
  YYSTYPE yyval;
  YYLTYPE yyloc;
  /** Next sibling in chain of options.  To facilitate merging,
   *  options are chained in decreasing order by address.  */
  yySemanticOption* yynext;
};

/** Type of the items in the GLR stack.  The yyisState field
 *  indicates which item of the union is valid.  */
union yyGLRStackItem {
  yyGLRState yystate;
  yySemanticOption yyoption;
};

struct yyGLRStack {
  int yyerrState;
  /* To compute the location of the error token.  */
  yyGLRStackItem yyerror_range[3];

  YYJMP_BUF yyexception_buffer;
  yyGLRStackItem* yyitems;
  yyGLRStackItem* yynextFree;
  YYPTRDIFF_T yyspaceLeft;
  yyGLRState* yysplitPoint;
  yyGLRState* yylastDeleted;
  yyGLRStateSet yytops;
};

#if YYSTACKEXPANDABLE
static void yyexpandGLRStack (yyGLRStack* yystackp);
#endif

_Noreturn static void
yyFail (yyGLRStack* yystackp, const char* yymsg)
{
  if (yymsg != YY_NULLPTR)
    yyerror (yymsg);
  YYLONGJMP (yystackp->yyexception_buffer, 1);
}

_Noreturn static void
yyMemoryExhausted (yyGLRStack* yystackp)
{
  YYLONGJMP (yystackp->yyexception_buffer, 2);
}

/** Accessing symbol of state YYSTATE.  */
static inline yysymbol_kind_t
yy_accessing_symbol (yy_state_t yystate)
{
  return YY_CAST (yysymbol_kind_t, yystos[yystate]);
}

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "PROGRAM", "CLASS",
  "STRUCT", "TYPE", "FUNCTION", "OPERATOR", "AUTO", "LET", "IF", "ELSE",
  "FOR", "IN", "WHILE", "DO", "WITH", "ASSERT", "RETURN", "FACTOR",
  "PHANTOM", "CPP", "HPP", "THIS", "SUPER", "GLOBAL", "PARALLEL",
  "DYNAMIC", "ABSTRACT", "OVERRIDE", "FINAL", "ACYCLIC", "NIL",
  "DOUBLE_BRACE_OPEN", "DOUBLE_BRACE_CLOSE", "NAME", "BOOL_LITERAL",
  "INT_LITERAL", "REAL_LITERAL", "STRING_LITERAL", "LEFT_OP", "RIGHT_OP",
  "LEFT_TILDE_OP", "RIGHT_TILDE_OP", "LEFT_QUERY_OP", "AND_OP", "OR_OP",
  "LE_OP", "GE_OP", "EQ_OP", "NE_OP", "RANGE_OP", "'('", "')'", "'['",
  "']'", "'?'", "'\\\\'", "','", "'.'", "'!'", "'+'", "'-'", "'*'", "'/'",
  "'<'", "'>'", "'~'", "':'", "'_'", "';'", "'='", "'{'", "'}'", "'&'",
  "$accept", "name", "bool_literal", "int_literal", "real_literal",
  "string_literal", "literal", "identifier", "parens_expression",
  "sequence_expression", "cast_expression", "function_expression",
  "this_expression", "super_expression", "nil_expression",
  "primary_expression", "slice_expression", "slice_expression_list",
  "slice", "postfix_expression", "query_expression", "prefix_operator",
  "prefix_expression", "multiplicative_operator",
  "multiplicative_expression", "additive_operator", "additive_expression",
  "relational_operator", "relational_expression", "equality_operator",
  "equality_expression", "logical_and_operator", "logical_and_expression",
  "logical_or_operator", "logical_or_expression", "assign_operator",
  "assign_expression", "expression", "optional_expression",
  "expression_list", "span_expression", "span_list", "brackets",
  "parameters", "optional_parameters", "parameter_list", "parameter",
  "options", "option_list", "option", "arguments", "optional_arguments",
  "shape", "generics", "generic_list", "generic", "optional_generics",
  "generic_arguments", "generic_argument_list", "generic_argument",
  "optional_generic_arguments", "init_operator",
  "global_variable_declaration", "member_variable_declaration",
  "member_phantom_declaration", "local_variable_declaration",
  "tuple_variable", "tuple_variables", "tuple_variables_declaration",
  "function_declaration", "$@1", "member_function_annotation",
  "member_function_declaration", "$@2", "$@3", "program_declaration",
  "$@4", "binary_operator", "binary_operator_declaration", "$@5",
  "unary_operator", "unary_operator_declaration", "$@6",
  "assignment_operator_declaration", "$@7",
  "conversion_operator_declaration", "$@8", "slice_operator_declaration",
  "$@9", "class_annotation", "class_declaration", "$@10", "$@11", "$@12",
  "struct_declaration", "$@13", "$@14", "$@15", "basic_declaration", "cpp",
  "hpp", "expression_statement", "if", "for_variable_declaration", "for",
  "parallel_annotation", "parallel", "while", "do_while", "with", "block",
  "assertion", "return", "factor", "statement", "statements",
  "optional_statements", "class_statement", "class_statements",
  "optional_class_statements", "struct_statement", "struct_statements",
  "optional_struct_statements", "file_statement", "file_statements",
  "optional_file_statements", "file", "return_type",
  "optional_return_type", "optional_auto_return_type", "braces",
  "optional_braces", "class_braces", "optional_class_braces",
  "struct_braces", "optional_struct_braces", "double_braces", "named_type",
  "primary_type", "type", "type_list", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

/** Left-hand-side symbol for rule #YYRULE.  */
static inline yysymbol_kind_t
yylhsNonterm (yyRuleNum yyrule)
{
  return YY_CAST (yysymbol_kind_t, yyr1[yyrule]);
}

#if YYDEBUG

# ifndef YYFPRINTF
#  define YYFPRINTF fprintf
# endif

# define YY_FPRINTF                             \
  YY_IGNORE_USELESS_CAST_BEGIN YY_FPRINTF_

# define YY_FPRINTF_(Args)                      \
  do {                                          \
    YYFPRINTF Args;                             \
    YY_IGNORE_USELESS_CAST_END                  \
  } while (0)

# define YY_DPRINTF                             \
  YY_IGNORE_USELESS_CAST_BEGIN YY_DPRINTF_

# define YY_DPRINTF_(Args)                      \
  do {                                          \
    if (yydebug)                                \
      YYFPRINTF Args;                           \
    YY_IGNORE_USELESS_CAST_END                  \
  } while (0)


/* YYLOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

# ifndef YYLOCATION_PRINT

#  if defined YY_LOCATION_PRINT

   /* Temporary convenience wrapper in case some people defined the
      undocumented and private YY_LOCATION_PRINT macros.  */
#   define YYLOCATION_PRINT(File, Loc)  YY_LOCATION_PRINT(File, *(Loc))

#  elif defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL

/* Print *YYLOCP on YYO.  Private, do not rely on its existence. */

YY_ATTRIBUTE_UNUSED
static int
yy_location_print_ (FILE *yyo, YYLTYPE const * const yylocp)
{
  int res = 0;
  int end_col = 0 != yylocp->last_column ? yylocp->last_column - 1 : 0;
  if (0 <= yylocp->first_line)
    {
      res += YYFPRINTF (yyo, "%d", yylocp->first_line);
      if (0 <= yylocp->first_column)
        res += YYFPRINTF (yyo, ".%d", yylocp->first_column);
    }
  if (0 <= yylocp->last_line)
    {
      if (yylocp->first_line < yylocp->last_line)
        {
          res += YYFPRINTF (yyo, "-%d", yylocp->last_line);
          if (0 <= end_col)
            res += YYFPRINTF (yyo, ".%d", end_col);
        }
      else if (0 <= end_col && yylocp->first_column < end_col)
        res += YYFPRINTF (yyo, "-%d", end_col);
    }
  return res;
}

#   define YYLOCATION_PRINT  yy_location_print_

    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT(File, Loc)  YYLOCATION_PRINT(File, &(Loc))

#  else

#   define YYLOCATION_PRINT(File, Loc) ((void) 0)
    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT  YYLOCATION_PRINT

#  endif
# endif /* !defined YYLOCATION_PRINT */



/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  YY_USE (yylocationp);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  YYLOCATION_PRINT (yyo, yylocationp);
  YYFPRINTF (yyo, ": ");
  yy_symbol_value_print (yyo, yykind, yyvaluep, yylocationp);
  YYFPRINTF (yyo, ")");
}

# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                  \
  do {                                                                  \
    if (yydebug)                                                        \
      {                                                                 \
        YY_FPRINTF ((stderr, "%s ", Title));                            \
        yy_symbol_print (stderr, Kind, Value, Location);        \
        YY_FPRINTF ((stderr, "\n"));                                    \
      }                                                                 \
  } while (0)

static inline void
yy_reduce_print (yybool yynormal, yyGLRStackItem* yyvsp, YYPTRDIFF_T yyk,
                 yyRuleNum yyrule);

# define YY_REDUCE_PRINT(Args)          \
  do {                                  \
    if (yydebug)                        \
      yy_reduce_print Args;             \
  } while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;

static void yypstack (yyGLRStack* yystackp, YYPTRDIFF_T yyk)
  YY_ATTRIBUTE_UNUSED;
static void yypdumpstack (yyGLRStack* yystackp)
  YY_ATTRIBUTE_UNUSED;

#else /* !YYDEBUG */

# define YY_DPRINTF(Args) do {} while (yyfalse)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_REDUCE_PRINT(Args)

#endif /* !YYDEBUG */



/** Fill in YYVSP[YYLOW1 .. YYLOW0-1] from the chain of states starting
 *  at YYVSP[YYLOW0].yystate.yypred.  Leaves YYVSP[YYLOW1].yystate.yypred
 *  containing the pointer to the next state in the chain.  */
static void yyfillin (yyGLRStackItem *, int, int) YY_ATTRIBUTE_UNUSED;
static void
yyfillin (yyGLRStackItem *yyvsp, int yylow0, int yylow1)
{
  int i;
  yyGLRState *s = yyvsp[yylow0].yystate.yypred;
  for (i = yylow0-1; i >= yylow1; i -= 1)
    {
#if YYDEBUG
      yyvsp[i].yystate.yylrState = s->yylrState;
#endif
      yyvsp[i].yystate.yyresolved = s->yyresolved;
      if (s->yyresolved)
        yyvsp[i].yystate.yysemantics.yyval = s->yysemantics.yyval;
      else
        /* The effect of using yyval or yyloc (in an immediate rule) is
         * undefined.  */
        yyvsp[i].yystate.yysemantics.yyfirstVal = YY_NULLPTR;
      yyvsp[i].yystate.yyloc = s->yyloc;
      s = yyvsp[i].yystate.yypred = s->yypred;
    }
}


/** If yychar is empty, fetch the next token.  */
static inline yysymbol_kind_t
yygetToken (int *yycharp)
{
  yysymbol_kind_t yytoken;
  if (*yycharp == YYEMPTY)
    {
      YY_DPRINTF ((stderr, "Reading a token\n"));
      *yycharp = yylex ();
    }
  if (*yycharp <= YYEOF)
    {
      *yycharp = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YY_DPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (*yycharp);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }
  return yytoken;
}

/* Do nothing if YYNORMAL or if *YYLOW <= YYLOW1.  Otherwise, fill in
 * YYVSP[YYLOW1 .. *YYLOW-1] as in yyfillin and set *YYLOW = YYLOW1.
 * For convenience, always return YYLOW1.  */
static inline int yyfill (yyGLRStackItem *, int *, int, yybool)
     YY_ATTRIBUTE_UNUSED;
static inline int
yyfill (yyGLRStackItem *yyvsp, int *yylow, int yylow1, yybool yynormal)
{
  if (!yynormal && yylow1 < *yylow)
    {
      yyfillin (yyvsp, *yylow, yylow1);
      *yylow = yylow1;
    }
  return yylow1;
}

/** Perform user action for rule number YYN, with RHS length YYRHSLEN,
 *  and top stack item YYVSP.  YYLVALP points to place to put semantic
 *  value ($$), and yylocp points to place for location information
 *  (@$).  Returns yyok for normal return, yyaccept for YYACCEPT,
 *  yyerr for YYERROR, yyabort for YYABORT, yynomem for YYNOMEM.  */
static YYRESULTTAG
yyuserAction (yyRuleNum yyrule, int yyrhslen, yyGLRStackItem* yyvsp,
              yyGLRStack* yystackp, YYPTRDIFF_T yyk,
              YYSTYPE* yyvalp, YYLTYPE *yylocp)
{
  const yybool yynormal YY_ATTRIBUTE_UNUSED = yystackp->yysplitPoint == YY_NULLPTR;
  int yylow = 1;
  YY_USE (yyvalp);
  YY_USE (yylocp);
  YY_USE (yyk);
  YY_USE (yyrhslen);
# undef yyerrok
# define yyerrok (yystackp->yyerrState = 0)
# undef YYACCEPT
# define YYACCEPT return yyaccept
# undef YYABORT
# define YYABORT return yyabort
# undef YYNOMEM
# define YYNOMEM return yynomem
# undef YYERROR
# define YYERROR return yyerrok, yyerr
# undef YYRECOVERING
# define YYRECOVERING() (yystackp->yyerrState != 0)
# undef yyclearin
# define yyclearin (yychar = YYEMPTY)
# undef YYFILL
# define YYFILL(N) yyfill (yyvsp, &yylow, (N), yynormal)
# undef YYBACKUP
# define YYBACKUP(Token, Value)                                              \
  return yyerror (YY_("syntax error: cannot back up")),     \
         yyerrok, yyerr

  if (yyrhslen == 0)
    *yyvalp = yyval_default;
  else
    *yyvalp = yyvsp[YYFILL (1-yyrhslen)].yystate.yysemantics.yyval;
  /* Default location. */
  YYLLOC_DEFAULT ((*yylocp), (yyvsp - yyrhslen), yyrhslen);
  yystackp->yyerror_range[1].yystate.yyloc = *yylocp;
  /* If yyk == -1, we are running a deferred action on a temporary
     stack.  In that case, YY_REDUCE_PRINT must not play with YYFILL,
     so pretend the stack is "normal". */
  YY_REDUCE_PRINT ((yynormal || yyk == -1, yyvsp, yyk, yyrule));
  switch (yyrule)
    {
  case 2: /* name: NAME  */
#line 170 "src/parser.ypp"
            { ((*yyvalp).valName) = new birch::Name((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valString)); }
#line 1879 "src/parser.cpp"
    break;

  case 3: /* bool_literal: BOOL_LITERAL  */
#line 178 "src/parser.ypp"
                    { ((*yyvalp).valExpression) = new birch::Literal<bool>((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valString), make_loc((*yylocp))); }
#line 1885 "src/parser.cpp"
    break;

  case 4: /* int_literal: INT_LITERAL  */
#line 182 "src/parser.ypp"
                   { ((*yyvalp).valExpression) = new birch::Literal<int64_t>((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valString), make_loc((*yylocp))); }
#line 1891 "src/parser.cpp"
    break;

  case 5: /* real_literal: REAL_LITERAL  */
#line 186 "src/parser.ypp"
                    { ((*yyvalp).valExpression) = new birch::Literal<double>((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valString), make_loc((*yylocp))); }
#line 1897 "src/parser.cpp"
    break;

  case 6: /* string_literal: STRING_LITERAL  */
#line 190 "src/parser.ypp"
                      { ((*yyvalp).valExpression) = new birch::Literal<const char*>((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valString), make_loc((*yylocp))); }
#line 1903 "src/parser.cpp"
    break;

  case 11: /* identifier: name optional_generic_arguments  */
#line 201 "src/parser.ypp"
                                       { ((*yyvalp).valExpression) = new birch::NamedExpression((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valType), make_loc((*yylocp))); }
#line 1909 "src/parser.cpp"
    break;

  case 12: /* parens_expression: '(' expression_list ')'  */
#line 205 "src/parser.ypp"
                               { ((*yyvalp).valExpression) = new birch::Parentheses((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 1915 "src/parser.cpp"
    break;

  case 13: /* sequence_expression: '[' expression_list ']'  */
#line 209 "src/parser.ypp"
                               { ((*yyvalp).valExpression) = new birch::Sequence((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 1921 "src/parser.cpp"
    break;

  case 14: /* cast_expression: name optional_generic_arguments '?' '(' expression ')'  */
#line 213 "src/parser.ypp"
                                                              { ((*yyvalp).valExpression) = new birch::Cast(new birch::NamedType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valType), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 1927 "src/parser.cpp"
    break;

  case 15: /* function_expression: '\\' parameters optional_auto_return_type optional_braces  */
#line 217 "src/parser.ypp"
                                                                 { ((*yyvalp).valExpression) = new birch::LambdaFunction((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_loc((*yylocp))); }
#line 1933 "src/parser.cpp"
    break;

  case 16: /* this_expression: THIS  */
#line 221 "src/parser.ypp"
            { ((*yyvalp).valExpression) = new birch::This(make_loc((*yylocp))); }
#line 1939 "src/parser.cpp"
    break;

  case 17: /* super_expression: SUPER  */
#line 225 "src/parser.ypp"
             { ((*yyvalp).valExpression) = new birch::Super(make_loc((*yylocp))); }
#line 1945 "src/parser.cpp"
    break;

  case 18: /* nil_expression: NIL  */
#line 229 "src/parser.ypp"
           { ((*yyvalp).valExpression) = new birch::Nil(make_loc((*yylocp))); }
#line 1951 "src/parser.cpp"
    break;

  case 27: /* slice_expression: expression RANGE_OP expression  */
#line 244 "src/parser.ypp"
                                      { ((*yyvalp).valExpression) = new birch::Range((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 1957 "src/parser.cpp"
    break;

  case 30: /* slice_expression_list: slice_expression ',' slice_expression_list  */
#line 250 "src/parser.ypp"
                                                  { ((*yyvalp).valExpression) = new birch::ExpressionList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 1963 "src/parser.cpp"
    break;

  case 31: /* slice: '[' slice_expression_list ']'  */
#line 254 "src/parser.ypp"
                                     { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression); }
#line 1969 "src/parser.cpp"
    break;

  case 33: /* postfix_expression: super_expression '.' identifier  */
#line 259 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::Member((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 1975 "src/parser.cpp"
    break;

  case 34: /* postfix_expression: GLOBAL '.' identifier  */
#line 260 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::Global((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 1981 "src/parser.cpp"
    break;

  case 35: /* postfix_expression: postfix_expression '.' identifier  */
#line 261 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::Member((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 1987 "src/parser.cpp"
    break;

  case 36: /* postfix_expression: postfix_expression slice  */
#line 262 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::Slice((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 1993 "src/parser.cpp"
    break;

  case 37: /* postfix_expression: postfix_expression arguments  */
#line 263 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::Call((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 1999 "src/parser.cpp"
    break;

  case 38: /* postfix_expression: postfix_expression '!'  */
#line 264 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::Get((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2005 "src/parser.cpp"
    break;

  case 40: /* query_expression: postfix_expression '?'  */
#line 271 "src/parser.ypp"
                              { ((*yyvalp).valExpression) = new birch::Query((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2011 "src/parser.cpp"
    break;

  case 41: /* prefix_operator: '+'  */
#line 275 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("+"); }
#line 2017 "src/parser.cpp"
    break;

  case 42: /* prefix_operator: '-'  */
#line 276 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("-"); }
#line 2023 "src/parser.cpp"
    break;

  case 43: /* prefix_operator: '!'  */
#line 277 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("!"); }
#line 2029 "src/parser.cpp"
    break;

  case 45: /* prefix_expression: prefix_operator prefix_expression  */
#line 282 "src/parser.ypp"
                                         { ((*yyvalp).valExpression) = new birch::UnaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2035 "src/parser.cpp"
    break;

  case 46: /* multiplicative_operator: '*'  */
#line 286 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("*"); }
#line 2041 "src/parser.cpp"
    break;

  case 47: /* multiplicative_operator: '/'  */
#line 287 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("/"); }
#line 2047 "src/parser.cpp"
    break;

  case 49: /* multiplicative_expression: multiplicative_expression multiplicative_operator prefix_expression  */
#line 292 "src/parser.ypp"
                                                                           { ((*yyvalp).valExpression) = new birch::BinaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2053 "src/parser.cpp"
    break;

  case 50: /* additive_operator: '+'  */
#line 296 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("+"); }
#line 2059 "src/parser.cpp"
    break;

  case 51: /* additive_operator: '-'  */
#line 297 "src/parser.ypp"
           { ((*yyvalp).valName) = new birch::Name("-"); }
#line 2065 "src/parser.cpp"
    break;

  case 53: /* additive_expression: additive_expression additive_operator multiplicative_expression  */
#line 302 "src/parser.ypp"
                                                                       { ((*yyvalp).valExpression) = new birch::BinaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2071 "src/parser.cpp"
    break;

  case 54: /* relational_operator: '<'  */
#line 306 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name("<"); }
#line 2077 "src/parser.cpp"
    break;

  case 55: /* relational_operator: '>'  */
#line 307 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name(">"); }
#line 2083 "src/parser.cpp"
    break;

  case 56: /* relational_operator: LE_OP  */
#line 308 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name("<="); }
#line 2089 "src/parser.cpp"
    break;

  case 57: /* relational_operator: GE_OP  */
#line 309 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name(">="); }
#line 2095 "src/parser.cpp"
    break;

  case 59: /* relational_expression: relational_expression relational_operator additive_expression  */
#line 319 "src/parser.ypp"
                                                                               { ((*yyvalp).valExpression) = new birch::BinaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2101 "src/parser.cpp"
    break;

  case 60: /* equality_operator: EQ_OP  */
#line 323 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name("=="); }
#line 2107 "src/parser.cpp"
    break;

  case 61: /* equality_operator: NE_OP  */
#line 324 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name("!="); }
#line 2113 "src/parser.cpp"
    break;

  case 63: /* equality_expression: equality_expression equality_operator relational_expression  */
#line 329 "src/parser.ypp"
                                                                   { ((*yyvalp).valExpression) = new birch::BinaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2119 "src/parser.cpp"
    break;

  case 64: /* logical_and_operator: AND_OP  */
#line 333 "src/parser.ypp"
              { ((*yyvalp).valName) = new birch::Name("&&"); }
#line 2125 "src/parser.cpp"
    break;

  case 66: /* logical_and_expression: logical_and_expression logical_and_operator equality_expression  */
#line 338 "src/parser.ypp"
                                                                       { ((*yyvalp).valExpression) = new birch::BinaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2131 "src/parser.cpp"
    break;

  case 67: /* logical_or_operator: OR_OP  */
#line 342 "src/parser.ypp"
             { ((*yyvalp).valName) = new birch::Name("||"); }
#line 2137 "src/parser.cpp"
    break;

  case 69: /* logical_or_expression: logical_or_expression logical_or_operator logical_and_expression  */
#line 347 "src/parser.ypp"
                                                                        { ((*yyvalp).valExpression) = new birch::BinaryCall((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2143 "src/parser.cpp"
    break;

  case 70: /* assign_operator: LEFT_OP  */
#line 351 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("<-"); }
#line 2149 "src/parser.cpp"
    break;

  case 71: /* assign_operator: LEFT_QUERY_OP  */
#line 352 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("<-?"); }
#line 2155 "src/parser.cpp"
    break;

  case 72: /* assign_operator: LEFT_TILDE_OP  */
#line 353 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("<~"); }
#line 2161 "src/parser.cpp"
    break;

  case 73: /* assign_operator: RIGHT_TILDE_OP  */
#line 354 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("~>"); }
#line 2167 "src/parser.cpp"
    break;

  case 74: /* assign_operator: '~'  */
#line 355 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("~"); }
#line 2173 "src/parser.cpp"
    break;

  case 76: /* assign_expression: logical_or_expression assign_operator assign_expression  */
#line 360 "src/parser.ypp"
                                                               { ((*yyvalp).valExpression) = new birch::Assign((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2179 "src/parser.cpp"
    break;

  case 79: /* optional_expression: %empty  */
#line 369 "src/parser.ypp"
                  { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2185 "src/parser.cpp"
    break;

  case 81: /* expression_list: expression ',' expression_list  */
#line 374 "src/parser.ypp"
                                      { ((*yyvalp).valExpression) = new birch::ExpressionList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2191 "src/parser.cpp"
    break;

  case 82: /* span_expression: expression  */
#line 378 "src/parser.ypp"
                   { ((*yyvalp).valExpression) = new birch::Span((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2197 "src/parser.cpp"
    break;

  case 84: /* span_list: span_expression ',' span_list  */
#line 383 "src/parser.ypp"
                                     { ((*yyvalp).valExpression) = new birch::ExpressionList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2203 "src/parser.cpp"
    break;

  case 85: /* brackets: '[' span_list ']'  */
#line 387 "src/parser.ypp"
                         { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression); }
#line 2209 "src/parser.cpp"
    break;

  case 86: /* parameters: '(' ')'  */
#line 391 "src/parser.ypp"
                              { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2215 "src/parser.cpp"
    break;

  case 87: /* parameters: '(' parameter_list ')'  */
#line 392 "src/parser.ypp"
                              { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression); }
#line 2221 "src/parser.cpp"
    break;

  case 89: /* optional_parameters: %empty  */
#line 397 "src/parser.ypp"
                  { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2227 "src/parser.cpp"
    break;

  case 91: /* parameter_list: parameter ',' parameter_list  */
#line 402 "src/parser.ypp"
                                    { ((*yyvalp).valExpression) = new birch::ExpressionList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2233 "src/parser.cpp"
    break;

  case 92: /* parameter: name ':' type  */
#line 406 "src/parser.ypp"
                     { ((*yyvalp).valExpression) = new birch::Parameter(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valType), empty_name((*yylocp)), empty_expr((*yylocp)), make_loc((*yylocp))); }
#line 2239 "src/parser.cpp"
    break;

  case 93: /* options: '(' ')'  */
#line 410 "src/parser.ypp"
                           { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2245 "src/parser.cpp"
    break;

  case 94: /* options: '(' option_list ')'  */
#line 411 "src/parser.ypp"
                           { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression); }
#line 2251 "src/parser.cpp"
    break;

  case 96: /* option_list: option ',' option_list  */
#line 416 "src/parser.ypp"
                              { ((*yyvalp).valExpression) = new birch::ExpressionList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2257 "src/parser.cpp"
    break;

  case 97: /* option: name ':' type  */
#line 420 "src/parser.ypp"
                                        { ((*yyvalp).valExpression) = new birch::Parameter(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valType), empty_name((*yylocp)), empty_expr((*yylocp)), make_loc((*yylocp))); }
#line 2263 "src/parser.cpp"
    break;

  case 98: /* option: name ':' type LEFT_OP expression  */
#line 421 "src/parser.ypp"
                                        { ((*yyvalp).valExpression) = new birch::Parameter(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), new birch::Name((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valString)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2269 "src/parser.cpp"
    break;

  case 99: /* arguments: '(' ')'  */
#line 425 "src/parser.ypp"
                               { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2275 "src/parser.cpp"
    break;

  case 100: /* arguments: '(' expression_list ')'  */
#line 426 "src/parser.ypp"
                               { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression); }
#line 2281 "src/parser.cpp"
    break;

  case 102: /* optional_arguments: %empty  */
#line 431 "src/parser.ypp"
                 { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2287 "src/parser.cpp"
    break;

  case 103: /* shape: '_'  */
#line 435 "src/parser.ypp"
                     { ((*yyvalp).valInt) = 1; }
#line 2293 "src/parser.cpp"
    break;

  case 104: /* shape: '_' ',' shape  */
#line 436 "src/parser.ypp"
                     { ((*yyvalp).valInt) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valInt) + 1; }
#line 2299 "src/parser.cpp"
    break;

  case 105: /* generics: '<' '>'  */
#line 440 "src/parser.ypp"
                            { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2305 "src/parser.cpp"
    break;

  case 106: /* generics: '<' generic_list '>'  */
#line 441 "src/parser.ypp"
                            { ((*yyvalp).valExpression) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression); }
#line 2311 "src/parser.cpp"
    break;

  case 108: /* generic_list: generic ',' generic_list  */
#line 446 "src/parser.ypp"
                                { ((*yyvalp).valExpression) = new birch::ExpressionList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2317 "src/parser.cpp"
    break;

  case 109: /* generic: name  */
#line 450 "src/parser.ypp"
            { ((*yyvalp).valExpression) = new birch::Generic(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valName), empty_type((*yylocp)), make_loc((*yylocp))); }
#line 2323 "src/parser.cpp"
    break;

  case 111: /* optional_generics: %empty  */
#line 455 "src/parser.ypp"
                { ((*yyvalp).valExpression) = empty_expr((*yylocp)); }
#line 2329 "src/parser.cpp"
    break;

  case 112: /* generic_arguments: '<' '>'  */
#line 459 "src/parser.ypp"
                                     { ((*yyvalp).valType) = empty_type((*yylocp)); }
#line 2335 "src/parser.cpp"
    break;

  case 113: /* generic_arguments: '<' generic_argument_list '>'  */
#line 460 "src/parser.ypp"
                                     { ((*yyvalp).valType) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valType); }
#line 2341 "src/parser.cpp"
    break;

  case 115: /* generic_argument_list: generic_argument ',' generic_argument_list  */
#line 465 "src/parser.ypp"
                                                  { ((*yyvalp).valType) = new birch::TypeList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valType), make_loc((*yylocp))); }
#line 2347 "src/parser.cpp"
    break;

  case 118: /* optional_generic_arguments: %empty  */
#line 474 "src/parser.ypp"
                         { ((*yyvalp).valType) = empty_type((*yylocp)); }
#line 2353 "src/parser.cpp"
    break;

  case 119: /* init_operator: LEFT_OP  */
#line 483 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("<-"); }
#line 2359 "src/parser.cpp"
    break;

  case 120: /* init_operator: LEFT_TILDE_OP  */
#line 484 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("<~"); }
#line 2365 "src/parser.cpp"
    break;

  case 121: /* init_operator: '~'  */
#line 485 "src/parser.ypp"
                      { ((*yyvalp).valName) = new birch::Name("~"); }
#line 2371 "src/parser.cpp"
    break;

  case 122: /* global_variable_declaration: name ':' type ';'  */
#line 489 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::GlobalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valType), empty_expr((*yylocp)), empty_expr((*yylocp)), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2377 "src/parser.cpp"
    break;

  case 123: /* global_variable_declaration: name ':' type arguments ';'  */
#line 490 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::GlobalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2383 "src/parser.cpp"
    break;

  case 124: /* global_variable_declaration: name ':' type init_operator expression ';'  */
#line 491 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::GlobalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valType), empty_expr((*yylocp)), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), make_doc_loc((*yylocp))); }
#line 2389 "src/parser.cpp"
    break;

  case 125: /* global_variable_declaration: name ':' type brackets ';'  */
#line 492 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::GlobalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valName), new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression)->width(), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), empty_expr((*yylocp)), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2395 "src/parser.cpp"
    break;

  case 126: /* global_variable_declaration: name ':' type brackets arguments ';'  */
#line 493 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::GlobalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valName), new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression)->width(), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2401 "src/parser.cpp"
    break;

  case 127: /* member_variable_declaration: name ':' type ';'  */
#line 497 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::MemberVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valType), empty_expr((*yylocp)), empty_expr((*yylocp)), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2407 "src/parser.cpp"
    break;

  case 128: /* member_variable_declaration: name ':' type arguments ';'  */
#line 498 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::MemberVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2413 "src/parser.cpp"
    break;

  case 129: /* member_variable_declaration: name ':' type init_operator expression ';'  */
#line 499 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::MemberVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valType), empty_expr((*yylocp)), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), make_doc_loc((*yylocp))); }
#line 2419 "src/parser.cpp"
    break;

  case 130: /* member_variable_declaration: name ':' type brackets ';'  */
#line 500 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::MemberVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valName), new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression)->width(), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), empty_expr((*yylocp)), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2425 "src/parser.cpp"
    break;

  case 131: /* member_variable_declaration: name ':' type brackets arguments ';'  */
#line 501 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::MemberVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valName), new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression)->width(), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2431 "src/parser.cpp"
    break;

  case 132: /* member_phantom_declaration: PHANTOM name ';'  */
#line 505 "src/parser.ypp"
                        { push_raw(); ((*yyvalp).valStatement) = new birch::MemberPhantom(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valName), make_doc_loc((*yylocp))); }
#line 2437 "src/parser.cpp"
    break;

  case 133: /* local_variable_declaration: AUTO name init_operator expression ';'  */
#line 509 "src/parser.ypp"
                                                  { yywarn("the auto keyword is deprecated, use let instead"); push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::LET, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valName), empty_type((*yylocp)), empty_expr((*yylocp)), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), make_doc_loc((*yylocp))); }
#line 2443 "src/parser.cpp"
    break;

  case 134: /* local_variable_declaration: LET name init_operator expression ';'  */
#line 510 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::LET, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valName), empty_type((*yylocp)), empty_expr((*yylocp)), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), make_doc_loc((*yylocp))); }
#line 2449 "src/parser.cpp"
    break;

  case 135: /* local_variable_declaration: name ':' type ';'  */
#line 511 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valType), empty_expr((*yylocp)), empty_expr((*yylocp)), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2455 "src/parser.cpp"
    break;

  case 136: /* local_variable_declaration: name ':' type arguments ';'  */
#line 512 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2461 "src/parser.cpp"
    break;

  case 137: /* local_variable_declaration: name ':' type init_operator expression ';'  */
#line 513 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valType), empty_expr((*yylocp)), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), make_doc_loc((*yylocp))); }
#line 2467 "src/parser.cpp"
    break;

  case 138: /* local_variable_declaration: name ':' type brackets ';'  */
#line 514 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valName), new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression)->width(), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), empty_expr((*yylocp)), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2473 "src/parser.cpp"
    break;

  case 139: /* local_variable_declaration: name ':' type brackets arguments ';'  */
#line 515 "src/parser.ypp"
                                                  { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valName), new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression)->width(), make_loc((*yylocp))), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2479 "src/parser.cpp"
    break;

  case 140: /* tuple_variable: name  */
#line 519 "src/parser.ypp"
            { push_raw(); ((*yyvalp).valStatement) = new birch::LocalVariable(birch::LET, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valName), empty_type((*yylocp)), empty_expr((*yylocp)), empty_expr((*yylocp)), empty_name((*yylocp)), empty_expr((*yylocp)), make_doc_loc((*yylocp))); }
#line 2485 "src/parser.cpp"
    break;

  case 142: /* tuple_variables: tuple_variable ',' tuple_variables  */
#line 524 "src/parser.ypp"
                                          { ((*yyvalp).valStatement) = new birch::StatementList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_loc((*yylocp))); }
#line 2491 "src/parser.cpp"
    break;

  case 143: /* tuple_variables_declaration: LET '(' tuple_variables ')' init_operator expression ';'  */
#line 528 "src/parser.ypp"
                                                               { push_raw(); ((*yyvalp).valStatement) = new birch::TupleVariable(birch::LET, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), make_doc_loc((*yylocp))); }
#line 2497 "src/parser.cpp"
    break;

  case 144: /* $@1: %empty  */
#line 532 "src/parser.ypp"
                                                                           { push_raw(); }
#line 2503 "src/parser.cpp"
    break;

  case 145: /* function_declaration: FUNCTION name optional_generics parameters optional_auto_return_type $@1 optional_braces  */
#line 532 "src/parser.ypp"
                                                                                                            { ((*yyvalp).valStatement) = new birch::Function(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_doc_loc((*yylocp))); }
#line 2509 "src/parser.cpp"
    break;

  case 146: /* member_function_annotation: ABSTRACT  */
#line 536 "src/parser.ypp"
                      { ((*yyvalp).valAnnotation) = birch::ABSTRACT; }
#line 2515 "src/parser.cpp"
    break;

  case 147: /* member_function_annotation: FINAL  */
#line 537 "src/parser.ypp"
                      { ((*yyvalp).valAnnotation) = birch::FINAL; }
#line 2521 "src/parser.cpp"
    break;

  case 148: /* member_function_annotation: OVERRIDE  */
#line 538 "src/parser.ypp"
                      { ((*yyvalp).valAnnotation) = birch::OVERRIDE; }
#line 2527 "src/parser.cpp"
    break;

  case 149: /* member_function_annotation: FINAL OVERRIDE  */
#line 539 "src/parser.ypp"
                      { ((*yyvalp).valAnnotation) = birch::Annotation(birch::FINAL|birch::OVERRIDE); }
#line 2533 "src/parser.cpp"
    break;

  case 150: /* $@2: %empty  */
#line 545 "src/parser.ypp"
                                                                                                      { push_raw(); }
#line 2539 "src/parser.cpp"
    break;

  case 151: /* member_function_declaration: member_function_annotation FUNCTION name optional_generics parameters optional_auto_return_type $@2 optional_braces  */
#line 545 "src/parser.ypp"
                                                                                                                                       { ((*yyvalp).valStatement) = new birch::MemberFunction((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-7)].yystate.yysemantics.yyval.valAnnotation), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_doc_loc((*yylocp))); }
#line 2545 "src/parser.cpp"
    break;

  case 152: /* $@3: %empty  */
#line 546 "src/parser.ypp"
                                                                           { push_raw(); }
#line 2551 "src/parser.cpp"
    break;

  case 153: /* member_function_declaration: FUNCTION name optional_generics parameters optional_auto_return_type $@3 optional_braces  */
#line 546 "src/parser.ypp"
                                                                                                            { ((*yyvalp).valStatement) = new birch::MemberFunction(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_doc_loc((*yylocp))); }
#line 2557 "src/parser.cpp"
    break;

  case 154: /* $@4: %empty  */
#line 550 "src/parser.ypp"
                           { push_raw(); }
#line 2563 "src/parser.cpp"
    break;

  case 155: /* program_declaration: PROGRAM name options $@4 optional_braces  */
#line 550 "src/parser.ypp"
                                                            { ((*yyvalp).valStatement) = new birch::Program((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_doc_loc((*yylocp))); }
#line 2569 "src/parser.cpp"
    break;

  case 162: /* $@5: %empty  */
#line 563 "src/parser.ypp"
                                                                                                       { push_raw(); }
#line 2575 "src/parser.cpp"
    break;

  case 163: /* binary_operator_declaration: OPERATOR optional_generics '(' parameter binary_operator parameter ')' optional_auto_return_type $@5 optional_braces  */
#line 563 "src/parser.ypp"
                                                                                                                                        { ((*yyvalp).valStatement) = new birch::BinaryOperator(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-8)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-6)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_doc_loc((*yylocp))); }
#line 2581 "src/parser.cpp"
    break;

  case 165: /* $@6: %empty  */
#line 571 "src/parser.ypp"
                                                                                            { push_raw(); }
#line 2587 "src/parser.cpp"
    break;

  case 166: /* unary_operator_declaration: OPERATOR optional_generics '(' unary_operator parameter ')' optional_auto_return_type $@6 optional_braces  */
#line 571 "src/parser.ypp"
                                                                                                                             { ((*yyvalp).valStatement) = new birch::UnaryOperator(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-7)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_doc_loc((*yylocp))); }
#line 2593 "src/parser.cpp"
    break;

  case 167: /* $@7: %empty  */
#line 575 "src/parser.ypp"
                                 { push_raw(); }
#line 2599 "src/parser.cpp"
    break;

  case 168: /* assignment_operator_declaration: OPERATOR LEFT_OP parameter $@7 optional_braces  */
#line 575 "src/parser.ypp"
                                                                  { ((*yyvalp).valStatement) = new birch::AssignmentOperator(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_doc_loc((*yylocp))); }
#line 2605 "src/parser.cpp"
    break;

  case 169: /* $@8: %empty  */
#line 579 "src/parser.ypp"
                           { push_raw(); }
#line 2611 "src/parser.cpp"
    break;

  case 170: /* conversion_operator_declaration: OPERATOR return_type $@8 optional_braces  */
#line 579 "src/parser.ypp"
                                                            { ((*yyvalp).valStatement) = new birch::ConversionOperator(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_doc_loc((*yylocp))); }
#line 2617 "src/parser.cpp"
    break;

  case 171: /* $@9: %empty  */
#line 583 "src/parser.ypp"
                                                  { push_raw(); }
#line 2623 "src/parser.cpp"
    break;

  case 172: /* slice_operator_declaration: OPERATOR '[' parameter_list ']' return_type $@9 optional_braces  */
#line 583 "src/parser.ypp"
                                                                                   { ((*yyvalp).valStatement) = new birch::SliceOperator(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_doc_loc((*yylocp))); }
#line 2629 "src/parser.cpp"
    break;

  case 173: /* class_annotation: ABSTRACT  */
#line 587 "src/parser.ypp"
                     { ((*yyvalp).valAnnotation) = birch::ABSTRACT; }
#line 2635 "src/parser.cpp"
    break;

  case 174: /* class_annotation: FINAL  */
#line 588 "src/parser.ypp"
                     { ((*yyvalp).valAnnotation) = birch::FINAL; }
#line 2641 "src/parser.cpp"
    break;

  case 175: /* class_annotation: ACYCLIC  */
#line 589 "src/parser.ypp"
                     { ((*yyvalp).valAnnotation) = birch::ACYCLIC; }
#line 2647 "src/parser.cpp"
    break;

  case 176: /* class_annotation: FINAL ACYCLIC  */
#line 590 "src/parser.ypp"
                     { ((*yyvalp).valAnnotation) = birch::Annotation(birch::FINAL|birch::ACYCLIC); }
#line 2653 "src/parser.cpp"
    break;

  case 177: /* class_annotation: %empty  */
#line 591 "src/parser.ypp"
                     { ((*yyvalp).valAnnotation) = birch::NONE; }
#line 2659 "src/parser.cpp"
    break;

  case 178: /* $@10: %empty  */
#line 595 "src/parser.ypp"
                                                                                                          { push_raw(); }
#line 2665 "src/parser.cpp"
    break;

  case 179: /* class_declaration: class_annotation CLASS name optional_generics optional_parameters '<' named_type optional_arguments $@10 optional_class_braces  */
#line 595 "src/parser.ypp"
                                                                                                                                                 { ((*yyvalp).valStatement) = new birch::Class((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-9)].yystate.yysemantics.yyval.valAnnotation), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-7)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-6)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valType), false, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_doc_loc((*yylocp))); }
#line 2671 "src/parser.cpp"
    break;

  case 180: /* $@11: %empty  */
#line 596 "src/parser.ypp"
                                                                        { push_raw(); }
#line 2677 "src/parser.cpp"
    break;

  case 181: /* class_declaration: class_annotation CLASS name optional_generics optional_parameters $@11 optional_class_braces  */
#line 596 "src/parser.ypp"
                                                                                                                                                 { ((*yyvalp).valStatement) = new birch::Class((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-6)].yystate.yysemantics.yyval.valAnnotation), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), empty_type((*yylocp)), false, empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_doc_loc((*yylocp))); }
#line 2683 "src/parser.cpp"
    break;

  case 182: /* $@12: %empty  */
#line 597 "src/parser.ypp"
                                                                   { push_raw(); }
#line 2689 "src/parser.cpp"
    break;

  case 183: /* class_declaration: class_annotation CLASS name optional_generics '=' named_type $@12 ';'  */
#line 597 "src/parser.ypp"
                                                                                                                                                 { ((*yyvalp).valStatement) = new birch::Class((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-7)].yystate.yysemantics.yyval.valAnnotation), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valExpression), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), true, empty_expr((*yylocp)), empty_stmt((*yylocp)), make_doc_loc((*yylocp))); }
#line 2695 "src/parser.cpp"
    break;

  case 184: /* $@13: %empty  */
#line 601 "src/parser.ypp"
                                                                                          { push_raw(); }
#line 2701 "src/parser.cpp"
    break;

  case 185: /* struct_declaration: STRUCT name optional_generics optional_parameters '<' named_type optional_arguments $@13 optional_struct_braces  */
#line 601 "src/parser.ypp"
                                                                                                                                  { ((*yyvalp).valStatement) = new birch::Struct(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-7)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-6)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valType), false, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_doc_loc((*yylocp))); }
#line 2707 "src/parser.cpp"
    break;

  case 186: /* $@14: %empty  */
#line 602 "src/parser.ypp"
                                                        { push_raw(); }
#line 2713 "src/parser.cpp"
    break;

  case 187: /* struct_declaration: STRUCT name optional_generics optional_parameters $@14 optional_struct_braces  */
#line 602 "src/parser.ypp"
                                                                                                                                  { ((*yyvalp).valStatement) = new birch::Struct(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valExpression), empty_type((*yylocp)), false, empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_doc_loc((*yylocp))); }
#line 2719 "src/parser.cpp"
    break;

  case 188: /* $@15: %empty  */
#line 603 "src/parser.ypp"
                                                   { push_raw(); }
#line 2725 "src/parser.cpp"
    break;

  case 189: /* struct_declaration: STRUCT name optional_generics '=' named_type $@15 ';'  */
#line 603 "src/parser.ypp"
                                                                                                                                  { ((*yyvalp).valStatement) = new birch::Struct(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-4)].yystate.yysemantics.yyval.valExpression), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), true, empty_expr((*yylocp)), empty_stmt((*yylocp)), make_doc_loc((*yylocp))); }
#line 2731 "src/parser.cpp"
    break;

  case 190: /* basic_declaration: TYPE name '<' named_type ';'  */
#line 607 "src/parser.ypp"
                                    { push_raw(); ((*yyvalp).valStatement) = new birch::Basic(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valName), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valType), false, make_doc_loc((*yylocp))); }
#line 2737 "src/parser.cpp"
    break;

  case 191: /* basic_declaration: TYPE name '=' named_type ';'  */
#line 608 "src/parser.ypp"
                                    { push_raw(); ((*yyvalp).valStatement) = new birch::Basic(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valName), empty_expr((*yylocp)), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valType), true, make_doc_loc((*yylocp))); }
#line 2743 "src/parser.cpp"
    break;

  case 192: /* basic_declaration: TYPE name ';'  */
#line 609 "src/parser.ypp"
                                    { push_raw(); ((*yyvalp).valStatement) = new birch::Basic(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valName), empty_expr((*yylocp)), empty_type((*yylocp)), false, make_doc_loc((*yylocp))); }
#line 2749 "src/parser.cpp"
    break;

  case 193: /* cpp: CPP double_braces  */
#line 613 "src/parser.ypp"
                         { push_raw(); ((*yyvalp).valStatement) = new birch::Raw(new birch::Name("cpp"), pop_raw(), make_loc((*yylocp))); }
#line 2755 "src/parser.cpp"
    break;

  case 194: /* hpp: HPP double_braces  */
#line 617 "src/parser.ypp"
                         { push_raw(); ((*yyvalp).valStatement) = new birch::Raw(new birch::Name("hpp"), pop_raw(), make_loc((*yylocp))); }
#line 2761 "src/parser.cpp"
    break;

  case 195: /* expression_statement: expression ';'  */
#line 621 "src/parser.ypp"
                      { ((*yyvalp).valStatement) = new birch::ExpressionStatement((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2767 "src/parser.cpp"
    break;

  case 196: /* if: IF expression braces ELSE braces  */
#line 625 "src/parser.ypp"
                                        { ((*yyvalp).valStatement) = new birch::If((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_loc((*yylocp))); }
#line 2773 "src/parser.cpp"
    break;

  case 197: /* if: IF expression braces ELSE if  */
#line 626 "src/parser.ypp"
                                        { ((*yyvalp).valStatement) = new birch::If((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_loc((*yylocp))); }
#line 2779 "src/parser.cpp"
    break;

  case 198: /* if: IF expression braces  */
#line 627 "src/parser.ypp"
                                        { ((*yyvalp).valStatement) = new birch::If((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), empty_stmt((*yylocp)), make_loc((*yylocp))); }
#line 2785 "src/parser.cpp"
    break;

  case 199: /* for_variable_declaration: name  */
#line 631 "src/parser.ypp"
                          { ((*yyvalp).valStatement) = new birch::LocalVariable((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valName), new birch::NamedType(new birch::Name("Integer")), make_loc((*yylocp))); }
#line 2791 "src/parser.cpp"
    break;

  case 200: /* for: FOR for_variable_declaration IN expression RANGE_OP expression braces  */
#line 635 "src/parser.ypp"
                                                                             { ((*yyvalp).valStatement) = new birch::For(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_loc((*yylocp))); }
#line 2797 "src/parser.cpp"
    break;

  case 201: /* parallel_annotation: DYNAMIC  */
#line 639 "src/parser.ypp"
               { ((*yyvalp).valAnnotation) = birch::DYNAMIC; }
#line 2803 "src/parser.cpp"
    break;

  case 202: /* parallel: parallel_annotation PARALLEL FOR for_variable_declaration IN expression RANGE_OP expression braces  */
#line 645 "src/parser.ypp"
                                                                                                          { ((*yyvalp).valStatement) = new birch::Parallel((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-8)].yystate.yysemantics.yyval.valAnnotation), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_loc((*yylocp))); }
#line 2809 "src/parser.cpp"
    break;

  case 203: /* parallel: PARALLEL FOR for_variable_declaration IN expression RANGE_OP expression braces  */
#line 646 "src/parser.ypp"
                                                                                                          { ((*yyvalp).valStatement) = new birch::Parallel(birch::NONE, (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-5)].yystate.yysemantics.yyval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_loc((*yylocp))); }
#line 2815 "src/parser.cpp"
    break;

  case 204: /* while: WHILE expression braces  */
#line 650 "src/parser.ypp"
                               { ((*yyvalp).valStatement) = new birch::While((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_loc((*yylocp))); }
#line 2821 "src/parser.cpp"
    break;

  case 205: /* do_while: DO braces WHILE expression ';'  */
#line 654 "src/parser.ypp"
                                      { ((*yyvalp).valStatement) = new birch::DoWhile((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2827 "src/parser.cpp"
    break;

  case 206: /* with: WITH expression braces  */
#line 658 "src/parser.ypp"
                              { ((*yyvalp).valStatement) = new birch::With((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_loc((*yylocp))); }
#line 2833 "src/parser.cpp"
    break;

  case 207: /* block: braces  */
#line 662 "src/parser.ypp"
              { ((*yyvalp).valStatement) = new birch::Block((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_loc((*yylocp))); }
#line 2839 "src/parser.cpp"
    break;

  case 208: /* assertion: ASSERT expression ';'  */
#line 666 "src/parser.ypp"
                             { ((*yyvalp).valStatement) = new birch::Assert((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2845 "src/parser.cpp"
    break;

  case 209: /* return: RETURN optional_expression ';'  */
#line 670 "src/parser.ypp"
                                      { ((*yyvalp).valStatement) = new birch::Return((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2851 "src/parser.cpp"
    break;

  case 210: /* factor: FACTOR optional_expression ';'  */
#line 674 "src/parser.ypp"
                                      { ((*yyvalp).valStatement) = new birch::Factor((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valExpression), make_loc((*yylocp))); }
#line 2857 "src/parser.cpp"
    break;

  case 226: /* statements: statement statements  */
#line 696 "src/parser.ypp"
                            { ((*yyvalp).valStatement) = new birch::StatementList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_loc((*yylocp))); }
#line 2863 "src/parser.cpp"
    break;

  case 228: /* optional_statements: %empty  */
#line 701 "src/parser.ypp"
                  { ((*yyvalp).valStatement) = empty_stmt((*yylocp)); }
#line 2869 "src/parser.cpp"
    break;

  case 237: /* class_statements: class_statement class_statements  */
#line 716 "src/parser.ypp"
                                        { ((*yyvalp).valStatement) = new birch::StatementList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_loc((*yylocp))); }
#line 2875 "src/parser.cpp"
    break;

  case 239: /* optional_class_statements: %empty  */
#line 721 "src/parser.ypp"
                        { ((*yyvalp).valStatement) = empty_stmt((*yylocp)); }
#line 2881 "src/parser.cpp"
    break;

  case 244: /* struct_statements: struct_statement struct_statements  */
#line 732 "src/parser.ypp"
                                          { ((*yyvalp).valStatement) = new birch::StatementList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_loc((*yylocp))); }
#line 2887 "src/parser.cpp"
    break;

  case 246: /* optional_struct_statements: %empty  */
#line 737 "src/parser.ypp"
                        { ((*yyvalp).valStatement) = empty_stmt((*yylocp)); }
#line 2893 "src/parser.cpp"
    break;

  case 258: /* file_statements: file_statement file_statements  */
#line 755 "src/parser.ypp"
                                      { ((*yyvalp).valStatement) = new birch::StatementList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valStatement), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement), make_loc((*yylocp))); }
#line 2899 "src/parser.cpp"
    break;

  case 260: /* optional_file_statements: %empty  */
#line 760 "src/parser.ypp"
                       { ((*yyvalp).valStatement) = empty_stmt((*yylocp)); }
#line 2905 "src/parser.cpp"
    break;

  case 261: /* file: optional_file_statements  */
#line 764 "src/parser.ypp"
                                { compiler->setRoot((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valStatement)); }
#line 2911 "src/parser.cpp"
    break;

  case 262: /* return_type: RIGHT_OP type  */
#line 768 "src/parser.ypp"
                     { ((*yyvalp).valType) = (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valType); }
#line 2917 "src/parser.cpp"
    break;

  case 264: /* optional_return_type: %empty  */
#line 773 "src/parser.ypp"
                   { ((*yyvalp).valType) = empty_type((*yylocp)); }
#line 2923 "src/parser.cpp"
    break;

  case 266: /* optional_auto_return_type: RIGHT_OP  */
#line 778 "src/parser.ypp"
                            { ((*yyvalp).valType) = new birch::DeducedType(make_loc((*yylocp))); }
#line 2929 "src/parser.cpp"
    break;

  case 267: /* braces: '{' optional_statements '}'  */
#line 782 "src/parser.ypp"
                                   { ((*yyvalp).valStatement) = new birch::Braces((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valStatement), make_loc((*yylocp))); }
#line 2935 "src/parser.cpp"
    break;

  case 269: /* optional_braces: ';'  */
#line 787 "src/parser.ypp"
              { ((*yyvalp).valStatement) = empty_stmt((*yylocp)); }
#line 2941 "src/parser.cpp"
    break;

  case 270: /* class_braces: '{' optional_class_statements '}'  */
#line 791 "src/parser.ypp"
                                         { ((*yyvalp).valStatement) = new birch::Braces((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valStatement), make_loc((*yylocp))); }
#line 2947 "src/parser.cpp"
    break;

  case 272: /* optional_class_braces: ';'  */
#line 796 "src/parser.ypp"
                    { ((*yyvalp).valStatement) = empty_stmt((*yylocp)); }
#line 2953 "src/parser.cpp"
    break;

  case 273: /* struct_braces: '{' optional_struct_statements '}'  */
#line 800 "src/parser.ypp"
                                          { ((*yyvalp).valStatement) = new birch::Braces((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valStatement), make_loc((*yylocp))); }
#line 2959 "src/parser.cpp"
    break;

  case 275: /* optional_struct_braces: ';'  */
#line 805 "src/parser.ypp"
                     { ((*yyvalp).valStatement) = empty_stmt((*yylocp)); }
#line 2965 "src/parser.cpp"
    break;

  case 277: /* named_type: name optional_generic_arguments  */
#line 818 "src/parser.ypp"
                                           { ((*yyvalp).valType) = new birch::NamedType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valType), make_loc((*yylocp))); }
#line 2971 "src/parser.cpp"
    break;

  case 278: /* named_type: name optional_generic_arguments '&'  */
#line 819 "src/parser.ypp"
                                           { yywarn("using weak pointers is no longer necessary"); ((*yyvalp).valType) = new birch::NamedType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valName), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valType), make_loc((*yylocp))); }
#line 2977 "src/parser.cpp"
    break;

  case 280: /* primary_type: '(' type_list ')'  */
#line 824 "src/parser.ypp"
                         { ((*yyvalp).valType) = new birch::TupleType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valType), make_loc((*yylocp))); }
#line 2983 "src/parser.cpp"
    break;

  case 282: /* type: type '?'  */
#line 829 "src/parser.ypp"
                                                            { ((*yyvalp).valType) = new birch::OptionalType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valType), make_loc((*yylocp))); }
#line 2989 "src/parser.cpp"
    break;

  case 283: /* type: type '!'  */
#line 830 "src/parser.ypp"
                                                            { ((*yyvalp).valType) = new birch::FutureType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valType), make_loc((*yylocp))); }
#line 2995 "src/parser.cpp"
    break;

  case 284: /* type: named_type '.' named_type  */
#line 831 "src/parser.ypp"
                                                            { ((*yyvalp).valType) = new birch::MemberType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valType), make_loc((*yylocp))); }
#line 3001 "src/parser.cpp"
    break;

  case 285: /* type: type '[' shape ']'  */
#line 832 "src/parser.ypp"
                                                            { ((*yyvalp).valType) = new birch::ArrayType((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-3)].yystate.yysemantics.yyval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-1)].yystate.yysemantics.yyval.valInt), make_loc((*yylocp))); }
#line 3007 "src/parser.cpp"
    break;

  case 287: /* type_list: type ',' type_list  */
#line 837 "src/parser.ypp"
                          { ((*yyvalp).valType) = new birch::TypeList((YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (-2)].yystate.yysemantics.yyval.valType), (YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL (0)].yystate.yysemantics.yyval.valType), make_loc((*yylocp))); }
#line 3013 "src/parser.cpp"
    break;


#line 3017 "src/parser.cpp"

      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yylhsNonterm (yyrule), yyvalp, yylocp);

  return yyok;
# undef yyerrok
# undef YYABORT
# undef YYACCEPT
# undef YYNOMEM
# undef YYERROR
# undef YYBACKUP
# undef yyclearin
# undef YYRECOVERING
}


static void
yyuserMerge (int yyn, YYSTYPE* yy0, YYSTYPE* yy1)
{
  YY_USE (yy0);
  YY_USE (yy1);

  switch (yyn)
    {

      default: break;
    }
}

                              /* Bison grammar-table manipulation.  */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
{
  YY_USE (yyvaluep);
  YY_USE (yylocationp);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}

/** Number of symbols composing the right hand side of rule #RULE.  */
static inline int
yyrhsLength (yyRuleNum yyrule)
{
  return yyr2[yyrule];
}

static void
yydestroyGLRState (char const *yymsg, yyGLRState *yys)
{
  if (yys->yyresolved)
    yydestruct (yymsg, yy_accessing_symbol (yys->yylrState),
                &yys->yysemantics.yyval, &yys->yyloc);
  else
    {
#if YYDEBUG
      if (yydebug)
        {
          if (yys->yysemantics.yyfirstVal)
            YY_FPRINTF ((stderr, "%s unresolved", yymsg));
          else
            YY_FPRINTF ((stderr, "%s incomplete", yymsg));
          YY_SYMBOL_PRINT ("", yy_accessing_symbol (yys->yylrState), YY_NULLPTR, &yys->yyloc);
        }
#endif

      if (yys->yysemantics.yyfirstVal)
        {
          yySemanticOption *yyoption = yys->yysemantics.yyfirstVal;
          yyGLRState *yyrh;
          int yyn;
          for (yyrh = yyoption->yystate, yyn = yyrhsLength (yyoption->yyrule);
               yyn > 0;
               yyrh = yyrh->yypred, yyn -= 1)
            yydestroyGLRState (yymsg, yyrh);
        }
    }
}

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

/** True iff LR state YYSTATE has only a default reduction (regardless
 *  of token).  */
static inline yybool
yyisDefaultedState (yy_state_t yystate)
{
  return yypact_value_is_default (yypact[yystate]);
}

/** The default reduction for YYSTATE, assuming it has one.  */
static inline yyRuleNum
yydefaultAction (yy_state_t yystate)
{
  return yydefact[yystate];
}

#define yytable_value_is_error(Yyn) \
  0

/** The action to take in YYSTATE on seeing YYTOKEN.
 *  Result R means
 *    R < 0:  Reduce on rule -R.
 *    R = 0:  Error.
 *    R > 0:  Shift to state R.
 *  Set *YYCONFLICTS to a pointer into yyconfl to a 0-terminated list
 *  of conflicting reductions.
 */
static inline int
yygetLRActions (yy_state_t yystate, yysymbol_kind_t yytoken, const short** yyconflicts)
{
  int yyindex = yypact[yystate] + yytoken;
  if (yytoken == YYSYMBOL_YYerror)
    {
      // This is the error token.
      *yyconflicts = yyconfl;
      return 0;
    }
  else if (yyisDefaultedState (yystate)
           || yyindex < 0 || YYLAST < yyindex || yycheck[yyindex] != yytoken)
    {
      *yyconflicts = yyconfl;
      return -yydefact[yystate];
    }
  else if (! yytable_value_is_error (yytable[yyindex]))
    {
      *yyconflicts = yyconfl + yyconflp[yyindex];
      return yytable[yyindex];
    }
  else
    {
      *yyconflicts = yyconfl + yyconflp[yyindex];
      return 0;
    }
}

/** Compute post-reduction state.
 * \param yystate   the current state
 * \param yysym     the nonterminal to push on the stack
 */
static inline yy_state_t
yyLRgotoState (yy_state_t yystate, yysymbol_kind_t yysym)
{
  int yyr = yypgoto[yysym - YYNTOKENS] + yystate;
  if (0 <= yyr && yyr <= YYLAST && yycheck[yyr] == yystate)
    return yytable[yyr];
  else
    return yydefgoto[yysym - YYNTOKENS];
}

static inline yybool
yyisShiftAction (int yyaction)
{
  return 0 < yyaction;
}

static inline yybool
yyisErrorAction (int yyaction)
{
  return yyaction == 0;
}

                                /* GLRStates */

/** Return a fresh GLRStackItem in YYSTACKP.  The item is an LR state
 *  if YYISSTATE, and otherwise a semantic option.  Callers should call
 *  YY_RESERVE_GLRSTACK afterwards to make sure there is sufficient
 *  headroom.  */

static inline yyGLRStackItem*
yynewGLRStackItem (yyGLRStack* yystackp, yybool yyisState)
{
  yyGLRStackItem* yynewItem = yystackp->yynextFree;
  yystackp->yyspaceLeft -= 1;
  yystackp->yynextFree += 1;
  yynewItem->yystate.yyisState = yyisState;
  return yynewItem;
}

/** Add a new semantic action that will execute the action for rule
 *  YYRULE on the semantic values in YYRHS to the list of
 *  alternative actions for YYSTATE.  Assumes that YYRHS comes from
 *  stack #YYK of *YYSTACKP. */
static void
yyaddDeferredAction (yyGLRStack* yystackp, YYPTRDIFF_T yyk, yyGLRState* yystate,
                     yyGLRState* yyrhs, yyRuleNum yyrule)
{
  yySemanticOption* yynewOption =
    &yynewGLRStackItem (yystackp, yyfalse)->yyoption;
  YY_ASSERT (!yynewOption->yyisState);
  yynewOption->yystate = yyrhs;
  yynewOption->yyrule = yyrule;
  if (yystackp->yytops.yylookaheadNeeds[yyk])
    {
      yynewOption->yyrawchar = yychar;
      yynewOption->yyval = yylval;
      yynewOption->yyloc = yylloc;
    }
  else
    yynewOption->yyrawchar = YYEMPTY;
  yynewOption->yynext = yystate->yysemantics.yyfirstVal;
  yystate->yysemantics.yyfirstVal = yynewOption;

  YY_RESERVE_GLRSTACK (yystackp);
}

                                /* GLRStacks */

/** Initialize YYSET to a singleton set containing an empty stack.  */
static yybool
yyinitStateSet (yyGLRStateSet* yyset)
{
  yyset->yysize = 1;
  yyset->yycapacity = 16;
  yyset->yystates
    = YY_CAST (yyGLRState**,
               YYMALLOC (YY_CAST (YYSIZE_T, yyset->yycapacity)
                         * sizeof yyset->yystates[0]));
  if (! yyset->yystates)
    return yyfalse;
  yyset->yystates[0] = YY_NULLPTR;
  yyset->yylookaheadNeeds
    = YY_CAST (yybool*,
               YYMALLOC (YY_CAST (YYSIZE_T, yyset->yycapacity)
                         * sizeof yyset->yylookaheadNeeds[0]));
  if (! yyset->yylookaheadNeeds)
    {
      YYFREE (yyset->yystates);
      return yyfalse;
    }
  memset (yyset->yylookaheadNeeds,
          0,
          YY_CAST (YYSIZE_T, yyset->yycapacity) * sizeof yyset->yylookaheadNeeds[0]);
  return yytrue;
}

static void yyfreeStateSet (yyGLRStateSet* yyset)
{
  YYFREE (yyset->yystates);
  YYFREE (yyset->yylookaheadNeeds);
}

/** Initialize *YYSTACKP to a single empty stack, with total maximum
 *  capacity for all stacks of YYSIZE.  */
static yybool
yyinitGLRStack (yyGLRStack* yystackp, YYPTRDIFF_T yysize)
{
  yystackp->yyerrState = 0;
  yynerrs = 0;
  yystackp->yyspaceLeft = yysize;
  yystackp->yyitems
    = YY_CAST (yyGLRStackItem*,
               YYMALLOC (YY_CAST (YYSIZE_T, yysize)
                         * sizeof yystackp->yynextFree[0]));
  if (!yystackp->yyitems)
    return yyfalse;
  yystackp->yynextFree = yystackp->yyitems;
  yystackp->yysplitPoint = YY_NULLPTR;
  yystackp->yylastDeleted = YY_NULLPTR;
  return yyinitStateSet (&yystackp->yytops);
}


#if YYSTACKEXPANDABLE
# define YYRELOC(YYFROMITEMS, YYTOITEMS, YYX, YYTYPE)                   \
  &((YYTOITEMS)                                                         \
    - ((YYFROMITEMS) - YY_REINTERPRET_CAST (yyGLRStackItem*, (YYX))))->YYTYPE

/** If *YYSTACKP is expandable, extend it.  WARNING: Pointers into the
    stack from outside should be considered invalid after this call.
    We always expand when there are 1 or fewer items left AFTER an
    allocation, so that we can avoid having external pointers exist
    across an allocation.  */
static void
yyexpandGLRStack (yyGLRStack* yystackp)
{
  yyGLRStackItem* yynewItems;
  yyGLRStackItem* yyp0, *yyp1;
  YYPTRDIFF_T yynewSize;
  YYPTRDIFF_T yyn;
  YYPTRDIFF_T yysize = yystackp->yynextFree - yystackp->yyitems;
  if (YYMAXDEPTH - YYHEADROOM < yysize)
    yyMemoryExhausted (yystackp);
  yynewSize = 2*yysize;
  if (YYMAXDEPTH < yynewSize)
    yynewSize = YYMAXDEPTH;
  yynewItems
    = YY_CAST (yyGLRStackItem*,
               YYMALLOC (YY_CAST (YYSIZE_T, yynewSize)
                         * sizeof yynewItems[0]));
  if (! yynewItems)
    yyMemoryExhausted (yystackp);
  for (yyp0 = yystackp->yyitems, yyp1 = yynewItems, yyn = yysize;
       0 < yyn;
       yyn -= 1, yyp0 += 1, yyp1 += 1)
    {
      *yyp1 = *yyp0;
      if (*YY_REINTERPRET_CAST (yybool *, yyp0))
        {
          yyGLRState* yys0 = &yyp0->yystate;
          yyGLRState* yys1 = &yyp1->yystate;
          if (yys0->yypred != YY_NULLPTR)
            yys1->yypred =
              YYRELOC (yyp0, yyp1, yys0->yypred, yystate);
          if (! yys0->yyresolved && yys0->yysemantics.yyfirstVal != YY_NULLPTR)
            yys1->yysemantics.yyfirstVal =
              YYRELOC (yyp0, yyp1, yys0->yysemantics.yyfirstVal, yyoption);
        }
      else
        {
          yySemanticOption* yyv0 = &yyp0->yyoption;
          yySemanticOption* yyv1 = &yyp1->yyoption;
          if (yyv0->yystate != YY_NULLPTR)
            yyv1->yystate = YYRELOC (yyp0, yyp1, yyv0->yystate, yystate);
          if (yyv0->yynext != YY_NULLPTR)
            yyv1->yynext = YYRELOC (yyp0, yyp1, yyv0->yynext, yyoption);
        }
    }
  if (yystackp->yysplitPoint != YY_NULLPTR)
    yystackp->yysplitPoint = YYRELOC (yystackp->yyitems, yynewItems,
                                      yystackp->yysplitPoint, yystate);

  for (yyn = 0; yyn < yystackp->yytops.yysize; yyn += 1)
    if (yystackp->yytops.yystates[yyn] != YY_NULLPTR)
      yystackp->yytops.yystates[yyn] =
        YYRELOC (yystackp->yyitems, yynewItems,
                 yystackp->yytops.yystates[yyn], yystate);
  YYFREE (yystackp->yyitems);
  yystackp->yyitems = yynewItems;
  yystackp->yynextFree = yynewItems + yysize;
  yystackp->yyspaceLeft = yynewSize - yysize;
}
#endif

static void
yyfreeGLRStack (yyGLRStack* yystackp)
{
  YYFREE (yystackp->yyitems);
  yyfreeStateSet (&yystackp->yytops);
}

/** Assuming that YYS is a GLRState somewhere on *YYSTACKP, update the
 *  splitpoint of *YYSTACKP, if needed, so that it is at least as deep as
 *  YYS.  */
static inline void
yyupdateSplit (yyGLRStack* yystackp, yyGLRState* yys)
{
  if (yystackp->yysplitPoint != YY_NULLPTR && yystackp->yysplitPoint > yys)
    yystackp->yysplitPoint = yys;
}

/** Invalidate stack #YYK in *YYSTACKP.  */
static inline void
yymarkStackDeleted (yyGLRStack* yystackp, YYPTRDIFF_T yyk)
{
  if (yystackp->yytops.yystates[yyk] != YY_NULLPTR)
    yystackp->yylastDeleted = yystackp->yytops.yystates[yyk];
  yystackp->yytops.yystates[yyk] = YY_NULLPTR;
}

/** Undelete the last stack in *YYSTACKP that was marked as deleted.  Can
    only be done once after a deletion, and only when all other stacks have
    been deleted.  */
static void
yyundeleteLastStack (yyGLRStack* yystackp)
{
  if (yystackp->yylastDeleted == YY_NULLPTR || yystackp->yytops.yysize != 0)
    return;
  yystackp->yytops.yystates[0] = yystackp->yylastDeleted;
  yystackp->yytops.yysize = 1;
  YY_DPRINTF ((stderr, "Restoring last deleted stack as stack #0.\n"));
  yystackp->yylastDeleted = YY_NULLPTR;
}

static inline void
yyremoveDeletes (yyGLRStack* yystackp)
{
  YYPTRDIFF_T yyi, yyj;
  yyi = yyj = 0;
  while (yyj < yystackp->yytops.yysize)
    {
      if (yystackp->yytops.yystates[yyi] == YY_NULLPTR)
        {
          if (yyi == yyj)
            YY_DPRINTF ((stderr, "Removing dead stacks.\n"));
          yystackp->yytops.yysize -= 1;
        }
      else
        {
          yystackp->yytops.yystates[yyj] = yystackp->yytops.yystates[yyi];
          /* In the current implementation, it's unnecessary to copy
             yystackp->yytops.yylookaheadNeeds[yyi] since, after
             yyremoveDeletes returns, the parser immediately either enters
             deterministic operation or shifts a token.  However, it doesn't
             hurt, and the code might evolve to need it.  */
          yystackp->yytops.yylookaheadNeeds[yyj] =
            yystackp->yytops.yylookaheadNeeds[yyi];
          if (yyj != yyi)
            YY_DPRINTF ((stderr, "Rename stack %ld -> %ld.\n",
                        YY_CAST (long, yyi), YY_CAST (long, yyj)));
          yyj += 1;
        }
      yyi += 1;
    }
}

/** Shift to a new state on stack #YYK of *YYSTACKP, corresponding to LR
 * state YYLRSTATE, at input position YYPOSN, with (resolved) semantic
 * value *YYVALP and source location *YYLOCP.  */
static inline void
yyglrShift (yyGLRStack* yystackp, YYPTRDIFF_T yyk, yy_state_t yylrState,
            YYPTRDIFF_T yyposn,
            YYSTYPE* yyvalp, YYLTYPE* yylocp)
{
  yyGLRState* yynewState = &yynewGLRStackItem (yystackp, yytrue)->yystate;

  yynewState->yylrState = yylrState;
  yynewState->yyposn = yyposn;
  yynewState->yyresolved = yytrue;
  yynewState->yypred = yystackp->yytops.yystates[yyk];
  yynewState->yysemantics.yyval = *yyvalp;
  yynewState->yyloc = *yylocp;
  yystackp->yytops.yystates[yyk] = yynewState;

  YY_RESERVE_GLRSTACK (yystackp);
}

/** Shift stack #YYK of *YYSTACKP, to a new state corresponding to LR
 *  state YYLRSTATE, at input position YYPOSN, with the (unresolved)
 *  semantic value of YYRHS under the action for YYRULE.  */
static inline void
yyglrShiftDefer (yyGLRStack* yystackp, YYPTRDIFF_T yyk, yy_state_t yylrState,
                 YYPTRDIFF_T yyposn, yyGLRState* yyrhs, yyRuleNum yyrule)
{
  yyGLRState* yynewState = &yynewGLRStackItem (yystackp, yytrue)->yystate;
  YY_ASSERT (yynewState->yyisState);

  yynewState->yylrState = yylrState;
  yynewState->yyposn = yyposn;
  yynewState->yyresolved = yyfalse;
  yynewState->yypred = yystackp->yytops.yystates[yyk];
  yynewState->yysemantics.yyfirstVal = YY_NULLPTR;
  yystackp->yytops.yystates[yyk] = yynewState;

  /* Invokes YY_RESERVE_GLRSTACK.  */
  yyaddDeferredAction (yystackp, yyk, yynewState, yyrhs, yyrule);
}

#if YYDEBUG

/*----------------------------------------------------------------------.
| Report that stack #YYK of *YYSTACKP is going to be reduced by YYRULE. |
`----------------------------------------------------------------------*/

static inline void
yy_reduce_print (yybool yynormal, yyGLRStackItem* yyvsp, YYPTRDIFF_T yyk,
                 yyRuleNum yyrule)
{
  int yynrhs = yyrhsLength (yyrule);
  int yylow = 1;
  int yyi;
  YY_FPRINTF ((stderr, "Reducing stack %ld by rule %d (line %d):\n",
               YY_CAST (long, yyk), yyrule - 1, yyrline[yyrule]));
  if (! yynormal)
    yyfillin (yyvsp, 1, -yynrhs);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YY_FPRINTF ((stderr, "   $%d = ", yyi + 1));
      yy_symbol_print (stderr,
                       yy_accessing_symbol (yyvsp[yyi - yynrhs + 1].yystate.yylrState),
                       &yyvsp[yyi - yynrhs + 1].yystate.yysemantics.yyval,
                       &(YY_CAST (yyGLRStackItem const *, yyvsp)[YYFILL ((yyi + 1) - (yynrhs))].yystate.yyloc)                       );
      if (!yyvsp[yyi - yynrhs + 1].yystate.yyresolved)
        YY_FPRINTF ((stderr, " (unresolved)"));
      YY_FPRINTF ((stderr, "\n"));
    }
}
#endif

/** Pop the symbols consumed by reduction #YYRULE from the top of stack
 *  #YYK of *YYSTACKP, and perform the appropriate semantic action on their
 *  semantic values.  Assumes that all ambiguities in semantic values
 *  have been previously resolved.  Set *YYVALP to the resulting value,
 *  and *YYLOCP to the computed location (if any).  Return value is as
 *  for userAction.  */
static inline YYRESULTTAG
yydoAction (yyGLRStack* yystackp, YYPTRDIFF_T yyk, yyRuleNum yyrule,
            YYSTYPE* yyvalp, YYLTYPE *yylocp)
{
  int yynrhs = yyrhsLength (yyrule);

  if (yystackp->yysplitPoint == YY_NULLPTR)
    {
      /* Standard special case: single stack.  */
      yyGLRStackItem* yyrhs
        = YY_REINTERPRET_CAST (yyGLRStackItem*, yystackp->yytops.yystates[yyk]);
      YY_ASSERT (yyk == 0);
      yystackp->yynextFree -= yynrhs;
      yystackp->yyspaceLeft += yynrhs;
      yystackp->yytops.yystates[0] = & yystackp->yynextFree[-1].yystate;
      return yyuserAction (yyrule, yynrhs, yyrhs, yystackp, yyk,
                           yyvalp, yylocp);
    }
  else
    {
      yyGLRStackItem yyrhsVals[YYMAXRHS + YYMAXLEFT + 1];
      yyGLRState* yys = yyrhsVals[YYMAXRHS + YYMAXLEFT].yystate.yypred
        = yystackp->yytops.yystates[yyk];
      int yyi;
      if (yynrhs == 0)
        /* Set default location.  */
        yyrhsVals[YYMAXRHS + YYMAXLEFT - 1].yystate.yyloc = yys->yyloc;
      for (yyi = 0; yyi < yynrhs; yyi += 1)
        {
          yys = yys->yypred;
          YY_ASSERT (yys);
        }
      yyupdateSplit (yystackp, yys);
      yystackp->yytops.yystates[yyk] = yys;
      return yyuserAction (yyrule, yynrhs, yyrhsVals + YYMAXRHS + YYMAXLEFT - 1,
                           yystackp, yyk, yyvalp, yylocp);
    }
}

/** Pop items off stack #YYK of *YYSTACKP according to grammar rule YYRULE,
 *  and push back on the resulting nonterminal symbol.  Perform the
 *  semantic action associated with YYRULE and store its value with the
 *  newly pushed state, if YYFORCEEVAL or if *YYSTACKP is currently
 *  unambiguous.  Otherwise, store the deferred semantic action with
 *  the new state.  If the new state would have an identical input
 *  position, LR state, and predecessor to an existing state on the stack,
 *  it is identified with that existing state, eliminating stack #YYK from
 *  *YYSTACKP.  In this case, the semantic value is
 *  added to the options for the existing state's semantic value.
 */
static inline YYRESULTTAG
yyglrReduce (yyGLRStack* yystackp, YYPTRDIFF_T yyk, yyRuleNum yyrule,
             yybool yyforceEval)
{
  YYPTRDIFF_T yyposn = yystackp->yytops.yystates[yyk]->yyposn;

  if (yyforceEval || yystackp->yysplitPoint == YY_NULLPTR)
    {
      YYSTYPE yyval;
      YYLTYPE yyloc;

      YYRESULTTAG yyflag = yydoAction (yystackp, yyk, yyrule, &yyval, &yyloc);
      if (yyflag == yyerr && yystackp->yysplitPoint != YY_NULLPTR)
        YY_DPRINTF ((stderr,
                     "Parse on stack %ld rejected by rule %d (line %d).\n",
                     YY_CAST (long, yyk), yyrule - 1, yyrline[yyrule]));
      if (yyflag != yyok)
        return yyflag;
      yyglrShift (yystackp, yyk,
                  yyLRgotoState (yystackp->yytops.yystates[yyk]->yylrState,
                                 yylhsNonterm (yyrule)),
                  yyposn, &yyval, &yyloc);
    }
  else
    {
      YYPTRDIFF_T yyi;
      int yyn;
      yyGLRState* yys, *yys0 = yystackp->yytops.yystates[yyk];
      yy_state_t yynewLRState;

      for (yys = yystackp->yytops.yystates[yyk], yyn = yyrhsLength (yyrule);
           0 < yyn; yyn -= 1)
        {
          yys = yys->yypred;
          YY_ASSERT (yys);
        }
      yyupdateSplit (yystackp, yys);
      yynewLRState = yyLRgotoState (yys->yylrState, yylhsNonterm (yyrule));
      YY_DPRINTF ((stderr,
                   "Reduced stack %ld by rule %d (line %d); action deferred.  "
                   "Now in state %d.\n",
                   YY_CAST (long, yyk), yyrule - 1, yyrline[yyrule],
                   yynewLRState));
      for (yyi = 0; yyi < yystackp->yytops.yysize; yyi += 1)
        if (yyi != yyk && yystackp->yytops.yystates[yyi] != YY_NULLPTR)
          {
            yyGLRState *yysplit = yystackp->yysplitPoint;
            yyGLRState *yyp = yystackp->yytops.yystates[yyi];
            while (yyp != yys && yyp != yysplit && yyp->yyposn >= yyposn)
              {
                if (yyp->yylrState == yynewLRState && yyp->yypred == yys)
                  {
                    yyaddDeferredAction (yystackp, yyk, yyp, yys0, yyrule);
                    yymarkStackDeleted (yystackp, yyk);
                    YY_DPRINTF ((stderr, "Merging stack %ld into stack %ld.\n",
                                 YY_CAST (long, yyk), YY_CAST (long, yyi)));
                    return yyok;
                  }
                yyp = yyp->yypred;
              }
          }
      yystackp->yytops.yystates[yyk] = yys;
      yyglrShiftDefer (yystackp, yyk, yynewLRState, yyposn, yys0, yyrule);
    }
  return yyok;
}

static YYPTRDIFF_T
yysplitStack (yyGLRStack* yystackp, YYPTRDIFF_T yyk)
{
  if (yystackp->yysplitPoint == YY_NULLPTR)
    {
      YY_ASSERT (yyk == 0);
      yystackp->yysplitPoint = yystackp->yytops.yystates[yyk];
    }
  if (yystackp->yytops.yycapacity <= yystackp->yytops.yysize)
    {
      YYPTRDIFF_T state_size = YYSIZEOF (yystackp->yytops.yystates[0]);
      YYPTRDIFF_T half_max_capacity = YYSIZE_MAXIMUM / 2 / state_size;
      if (half_max_capacity < yystackp->yytops.yycapacity)
        yyMemoryExhausted (yystackp);
      yystackp->yytops.yycapacity *= 2;

      {
        yyGLRState** yynewStates
          = YY_CAST (yyGLRState**,
                     YYREALLOC (yystackp->yytops.yystates,
                                (YY_CAST (YYSIZE_T, yystackp->yytops.yycapacity)
                                 * sizeof yynewStates[0])));
        if (yynewStates == YY_NULLPTR)
          yyMemoryExhausted (yystackp);
        yystackp->yytops.yystates = yynewStates;
      }

      {
        yybool* yynewLookaheadNeeds
          = YY_CAST (yybool*,
                     YYREALLOC (yystackp->yytops.yylookaheadNeeds,
                                (YY_CAST (YYSIZE_T, yystackp->yytops.yycapacity)
                                 * sizeof yynewLookaheadNeeds[0])));
        if (yynewLookaheadNeeds == YY_NULLPTR)
          yyMemoryExhausted (yystackp);
        yystackp->yytops.yylookaheadNeeds = yynewLookaheadNeeds;
      }
    }
  yystackp->yytops.yystates[yystackp->yytops.yysize]
    = yystackp->yytops.yystates[yyk];
  yystackp->yytops.yylookaheadNeeds[yystackp->yytops.yysize]
    = yystackp->yytops.yylookaheadNeeds[yyk];
  yystackp->yytops.yysize += 1;
  return yystackp->yytops.yysize - 1;
}

/** True iff YYY0 and YYY1 represent identical options at the top level.
 *  That is, they represent the same rule applied to RHS symbols
 *  that produce the same terminal symbols.  */
static yybool
yyidenticalOptions (yySemanticOption* yyy0, yySemanticOption* yyy1)
{
  if (yyy0->yyrule == yyy1->yyrule)
    {
      yyGLRState *yys0, *yys1;
      int yyn;
      for (yys0 = yyy0->yystate, yys1 = yyy1->yystate,
           yyn = yyrhsLength (yyy0->yyrule);
           yyn > 0;
           yys0 = yys0->yypred, yys1 = yys1->yypred, yyn -= 1)
        if (yys0->yyposn != yys1->yyposn)
          return yyfalse;
      return yytrue;
    }
  else
    return yyfalse;
}

/** Assuming identicalOptions (YYY0,YYY1), destructively merge the
 *  alternative semantic values for the RHS-symbols of YYY1 and YYY0.  */
static void
yymergeOptionSets (yySemanticOption* yyy0, yySemanticOption* yyy1)
{
  yyGLRState *yys0, *yys1;
  int yyn;
  for (yys0 = yyy0->yystate, yys1 = yyy1->yystate,
       yyn = yyrhsLength (yyy0->yyrule);
       0 < yyn;
       yys0 = yys0->yypred, yys1 = yys1->yypred, yyn -= 1)
    {
      if (yys0 == yys1)
        break;
      else if (yys0->yyresolved)
        {
          yys1->yyresolved = yytrue;
          yys1->yysemantics.yyval = yys0->yysemantics.yyval;
        }
      else if (yys1->yyresolved)
        {
          yys0->yyresolved = yytrue;
          yys0->yysemantics.yyval = yys1->yysemantics.yyval;
        }
      else
        {
          yySemanticOption** yyz0p = &yys0->yysemantics.yyfirstVal;
          yySemanticOption* yyz1 = yys1->yysemantics.yyfirstVal;
          while (yytrue)
            {
              if (yyz1 == *yyz0p || yyz1 == YY_NULLPTR)
                break;
              else if (*yyz0p == YY_NULLPTR)
                {
                  *yyz0p = yyz1;
                  break;
                }
              else if (*yyz0p < yyz1)
                {
                  yySemanticOption* yyz = *yyz0p;
                  *yyz0p = yyz1;
                  yyz1 = yyz1->yynext;
                  (*yyz0p)->yynext = yyz;
                }
              yyz0p = &(*yyz0p)->yynext;
            }
          yys1->yysemantics.yyfirstVal = yys0->yysemantics.yyfirstVal;
        }
    }
}

/** Y0 and Y1 represent two possible actions to take in a given
 *  parsing state; return 0 if no combination is possible,
 *  1 if user-mergeable, 2 if Y0 is preferred, 3 if Y1 is preferred.  */
static int
yypreference (yySemanticOption* y0, yySemanticOption* y1)
{
  yyRuleNum r0 = y0->yyrule, r1 = y1->yyrule;
  int p0 = yydprec[r0], p1 = yydprec[r1];

  if (p0 == p1)
    {
      if (yymerger[r0] == 0 || yymerger[r0] != yymerger[r1])
        return 0;
      else
        return 1;
    }
  if (p0 == 0 || p1 == 0)
    return 0;
  if (p0 < p1)
    return 3;
  if (p1 < p0)
    return 2;
  return 0;
}

static YYRESULTTAG
yyresolveValue (yyGLRState* yys, yyGLRStack* yystackp);


/** Resolve the previous YYN states starting at and including state YYS
 *  on *YYSTACKP. If result != yyok, some states may have been left
 *  unresolved possibly with empty semantic option chains.  Regardless
 *  of whether result = yyok, each state has been left with consistent
 *  data so that yydestroyGLRState can be invoked if necessary.  */
static YYRESULTTAG
yyresolveStates (yyGLRState* yys, int yyn,
                 yyGLRStack* yystackp)
{
  if (0 < yyn)
    {
      YY_ASSERT (yys->yypred);
      YYCHK (yyresolveStates (yys->yypred, yyn-1, yystackp));
      if (! yys->yyresolved)
        YYCHK (yyresolveValue (yys, yystackp));
    }
  return yyok;
}

/** Resolve the states for the RHS of YYOPT on *YYSTACKP, perform its
 *  user action, and return the semantic value and location in *YYVALP
 *  and *YYLOCP.  Regardless of whether result = yyok, all RHS states
 *  have been destroyed (assuming the user action destroys all RHS
 *  semantic values if invoked).  */
static YYRESULTTAG
yyresolveAction (yySemanticOption* yyopt, yyGLRStack* yystackp,
                 YYSTYPE* yyvalp, YYLTYPE *yylocp)
{
  yyGLRStackItem yyrhsVals[YYMAXRHS + YYMAXLEFT + 1];
  int yynrhs = yyrhsLength (yyopt->yyrule);
  YYRESULTTAG yyflag =
    yyresolveStates (yyopt->yystate, yynrhs, yystackp);
  if (yyflag != yyok)
    {
      yyGLRState *yys;
      for (yys = yyopt->yystate; yynrhs > 0; yys = yys->yypred, yynrhs -= 1)
        yydestroyGLRState ("Cleanup: popping", yys);
      return yyflag;
    }

  yyrhsVals[YYMAXRHS + YYMAXLEFT].yystate.yypred = yyopt->yystate;
  if (yynrhs == 0)
    /* Set default location.  */
    yyrhsVals[YYMAXRHS + YYMAXLEFT - 1].yystate.yyloc = yyopt->yystate->yyloc;
  {
    int yychar_current = yychar;
    YYSTYPE yylval_current = yylval;
    YYLTYPE yylloc_current = yylloc;
    yychar = yyopt->yyrawchar;
    yylval = yyopt->yyval;
    yylloc = yyopt->yyloc;
    yyflag = yyuserAction (yyopt->yyrule, yynrhs,
                           yyrhsVals + YYMAXRHS + YYMAXLEFT - 1,
                           yystackp, -1, yyvalp, yylocp);
    yychar = yychar_current;
    yylval = yylval_current;
    yylloc = yylloc_current;
  }
  return yyflag;
}

#if YYDEBUG
static void
yyreportTree (yySemanticOption* yyx, int yyindent)
{
  int yynrhs = yyrhsLength (yyx->yyrule);
  int yyi;
  yyGLRState* yys;
  yyGLRState* yystates[1 + YYMAXRHS];
  yyGLRState yyleftmost_state;

  for (yyi = yynrhs, yys = yyx->yystate; 0 < yyi; yyi -= 1, yys = yys->yypred)
    yystates[yyi] = yys;
  if (yys == YY_NULLPTR)
    {
      yyleftmost_state.yyposn = 0;
      yystates[0] = &yyleftmost_state;
    }
  else
    yystates[0] = yys;

  if (yyx->yystate->yyposn < yys->yyposn + 1)
    YY_FPRINTF ((stderr, "%*s%s -> <Rule %d, empty>\n",
                 yyindent, "", yysymbol_name (yylhsNonterm (yyx->yyrule)),
                 yyx->yyrule - 1));
  else
    YY_FPRINTF ((stderr, "%*s%s -> <Rule %d, tokens %ld .. %ld>\n",
                 yyindent, "", yysymbol_name (yylhsNonterm (yyx->yyrule)),
                 yyx->yyrule - 1, YY_CAST (long, yys->yyposn + 1),
                 YY_CAST (long, yyx->yystate->yyposn)));
  for (yyi = 1; yyi <= yynrhs; yyi += 1)
    {
      if (yystates[yyi]->yyresolved)
        {
          if (yystates[yyi-1]->yyposn+1 > yystates[yyi]->yyposn)
            YY_FPRINTF ((stderr, "%*s%s <empty>\n", yyindent+2, "",
                         yysymbol_name (yy_accessing_symbol (yystates[yyi]->yylrState))));
          else
            YY_FPRINTF ((stderr, "%*s%s <tokens %ld .. %ld>\n", yyindent+2, "",
                         yysymbol_name (yy_accessing_symbol (yystates[yyi]->yylrState)),
                         YY_CAST (long, yystates[yyi-1]->yyposn + 1),
                         YY_CAST (long, yystates[yyi]->yyposn)));
        }
      else
        yyreportTree (yystates[yyi]->yysemantics.yyfirstVal, yyindent+2);
    }
}
#endif

static YYRESULTTAG
yyreportAmbiguity (yySemanticOption* yyx0,
                   yySemanticOption* yyx1)
{
  YY_USE (yyx0);
  YY_USE (yyx1);

#if YYDEBUG
  YY_FPRINTF ((stderr, "Ambiguity detected.\n"));
  YY_FPRINTF ((stderr, "Option 1,\n"));
  yyreportTree (yyx0, 2);
  YY_FPRINTF ((stderr, "\nOption 2,\n"));
  yyreportTree (yyx1, 2);
  YY_FPRINTF ((stderr, "\n"));
#endif

  yyerror (YY_("syntax is ambiguous"));
  return yyabort;
}

/** Resolve the locations for each of the YYN1 states in *YYSTACKP,
 *  ending at YYS1.  Has no effect on previously resolved states.
 *  The first semantic option of a state is always chosen.  */
static void
yyresolveLocations (yyGLRState *yys1, int yyn1,
                    yyGLRStack *yystackp)
{
  if (0 < yyn1)
    {
      yyresolveLocations (yys1->yypred, yyn1 - 1, yystackp);
      if (!yys1->yyresolved)
        {
          yyGLRStackItem yyrhsloc[1 + YYMAXRHS];
          int yynrhs;
          yySemanticOption *yyoption = yys1->yysemantics.yyfirstVal;
          YY_ASSERT (yyoption);
          yynrhs = yyrhsLength (yyoption->yyrule);
          if (0 < yynrhs)
            {
              yyGLRState *yys;
              int yyn;
              yyresolveLocations (yyoption->yystate, yynrhs,
                                  yystackp);
              for (yys = yyoption->yystate, yyn = yynrhs;
                   yyn > 0;
                   yys = yys->yypred, yyn -= 1)
                yyrhsloc[yyn].yystate.yyloc = yys->yyloc;
            }
          else
            {
              /* Both yyresolveAction and yyresolveLocations traverse the GSS
                 in reverse rightmost order.  It is only necessary to invoke
                 yyresolveLocations on a subforest for which yyresolveAction
                 would have been invoked next had an ambiguity not been
                 detected.  Thus the location of the previous state (but not
                 necessarily the previous state itself) is guaranteed to be
                 resolved already.  */
              yyGLRState *yyprevious = yyoption->yystate;
              yyrhsloc[0].yystate.yyloc = yyprevious->yyloc;
            }
          YYLLOC_DEFAULT ((yys1->yyloc), yyrhsloc, yynrhs);
        }
    }
}

/** Resolve the ambiguity represented in state YYS in *YYSTACKP,
 *  perform the indicated actions, and set the semantic value of YYS.
 *  If result != yyok, the chain of semantic options in YYS has been
 *  cleared instead or it has been left unmodified except that
 *  redundant options may have been removed.  Regardless of whether
 *  result = yyok, YYS has been left with consistent data so that
 *  yydestroyGLRState can be invoked if necessary.  */
static YYRESULTTAG
yyresolveValue (yyGLRState* yys, yyGLRStack* yystackp)
{
  yySemanticOption* yyoptionList = yys->yysemantics.yyfirstVal;
  yySemanticOption* yybest = yyoptionList;
  yySemanticOption** yypp;
  yybool yymerge = yyfalse;
  YYSTYPE yyval;
  YYRESULTTAG yyflag;
  YYLTYPE *yylocp = &yys->yyloc;

  for (yypp = &yyoptionList->yynext; *yypp != YY_NULLPTR; )
    {
      yySemanticOption* yyp = *yypp;

      if (yyidenticalOptions (yybest, yyp))
        {
          yymergeOptionSets (yybest, yyp);
          *yypp = yyp->yynext;
        }
      else
        {
          switch (yypreference (yybest, yyp))
            {
            case 0:
              yyresolveLocations (yys, 1, yystackp);
              return yyreportAmbiguity (yybest, yyp);
              break;
            case 1:
              yymerge = yytrue;
              break;
            case 2:
              break;
            case 3:
              yybest = yyp;
              yymerge = yyfalse;
              break;
            default:
              /* This cannot happen so it is not worth a YY_ASSERT (yyfalse),
                 but some compilers complain if the default case is
                 omitted.  */
              break;
            }
          yypp = &yyp->yynext;
        }
    }

  if (yymerge)
    {
      yySemanticOption* yyp;
      int yyprec = yydprec[yybest->yyrule];
      yyflag = yyresolveAction (yybest, yystackp, &yyval, yylocp);
      if (yyflag == yyok)
        for (yyp = yybest->yynext; yyp != YY_NULLPTR; yyp = yyp->yynext)
          {
            if (yyprec == yydprec[yyp->yyrule])
              {
                YYSTYPE yyval_other;
                YYLTYPE yydummy;
                yyflag = yyresolveAction (yyp, yystackp, &yyval_other, &yydummy);
                if (yyflag != yyok)
                  {
                    yydestruct ("Cleanup: discarding incompletely merged value for",
                                yy_accessing_symbol (yys->yylrState),
                                &yyval, yylocp);
                    break;
                  }
                yyuserMerge (yymerger[yyp->yyrule], &yyval, &yyval_other);
              }
          }
    }
  else
    yyflag = yyresolveAction (yybest, yystackp, &yyval, yylocp);

  if (yyflag == yyok)
    {
      yys->yyresolved = yytrue;
      yys->yysemantics.yyval = yyval;
    }
  else
    yys->yysemantics.yyfirstVal = YY_NULLPTR;
  return yyflag;
}

static YYRESULTTAG
yyresolveStack (yyGLRStack* yystackp)
{
  if (yystackp->yysplitPoint != YY_NULLPTR)
    {
      yyGLRState* yys;
      int yyn;

      for (yyn = 0, yys = yystackp->yytops.yystates[0];
           yys != yystackp->yysplitPoint;
           yys = yys->yypred, yyn += 1)
        continue;
      YYCHK (yyresolveStates (yystackp->yytops.yystates[0], yyn, yystackp
                             ));
    }
  return yyok;
}

/** Called when returning to deterministic operation to clean up the extra
 * stacks. */
static void
yycompressStack (yyGLRStack* yystackp)
{
  /* yyr is the state after the split point.  */
  yyGLRState *yyr;

  if (yystackp->yytops.yysize != 1 || yystackp->yysplitPoint == YY_NULLPTR)
    return;

  {
    yyGLRState *yyp, *yyq;
    for (yyp = yystackp->yytops.yystates[0], yyq = yyp->yypred, yyr = YY_NULLPTR;
         yyp != yystackp->yysplitPoint;
         yyr = yyp, yyp = yyq, yyq = yyp->yypred)
      yyp->yypred = yyr;
  }

  yystackp->yyspaceLeft += yystackp->yynextFree - yystackp->yyitems;
  yystackp->yynextFree = YY_REINTERPRET_CAST (yyGLRStackItem*, yystackp->yysplitPoint) + 1;
  yystackp->yyspaceLeft -= yystackp->yynextFree - yystackp->yyitems;
  yystackp->yysplitPoint = YY_NULLPTR;
  yystackp->yylastDeleted = YY_NULLPTR;

  while (yyr != YY_NULLPTR)
    {
      yystackp->yynextFree->yystate = *yyr;
      yyr = yyr->yypred;
      yystackp->yynextFree->yystate.yypred = &yystackp->yynextFree[-1].yystate;
      yystackp->yytops.yystates[0] = &yystackp->yynextFree->yystate;
      yystackp->yynextFree += 1;
      yystackp->yyspaceLeft -= 1;
    }
}

static YYRESULTTAG
yyprocessOneStack (yyGLRStack* yystackp, YYPTRDIFF_T yyk,
                   YYPTRDIFF_T yyposn)
{
  while (yystackp->yytops.yystates[yyk] != YY_NULLPTR)
    {
      yy_state_t yystate = yystackp->yytops.yystates[yyk]->yylrState;
      YY_DPRINTF ((stderr, "Stack %ld Entering state %d\n",
                   YY_CAST (long, yyk), yystate));

      YY_ASSERT (yystate != YYFINAL);

      if (yyisDefaultedState (yystate))
        {
          YYRESULTTAG yyflag;
          yyRuleNum yyrule = yydefaultAction (yystate);
          if (yyrule == 0)
            {
              YY_DPRINTF ((stderr, "Stack %ld dies.\n", YY_CAST (long, yyk)));
              yymarkStackDeleted (yystackp, yyk);
              return yyok;
            }
          yyflag = yyglrReduce (yystackp, yyk, yyrule, yyimmediate[yyrule]);
          if (yyflag == yyerr)
            {
              YY_DPRINTF ((stderr,
                           "Stack %ld dies "
                           "(predicate failure or explicit user error).\n",
                           YY_CAST (long, yyk)));
              yymarkStackDeleted (yystackp, yyk);
              return yyok;
            }
          if (yyflag != yyok)
            return yyflag;
        }
      else
        {
          yysymbol_kind_t yytoken = yygetToken (&yychar);
          const short* yyconflicts;
          const int yyaction = yygetLRActions (yystate, yytoken, &yyconflicts);
          yystackp->yytops.yylookaheadNeeds[yyk] = yytrue;

          for (/* nothing */; *yyconflicts; yyconflicts += 1)
            {
              YYRESULTTAG yyflag;
              YYPTRDIFF_T yynewStack = yysplitStack (yystackp, yyk);
              YY_DPRINTF ((stderr, "Splitting off stack %ld from %ld.\n",
                           YY_CAST (long, yynewStack), YY_CAST (long, yyk)));
              yyflag = yyglrReduce (yystackp, yynewStack,
                                    *yyconflicts,
                                    yyimmediate[*yyconflicts]);
              if (yyflag == yyok)
                YYCHK (yyprocessOneStack (yystackp, yynewStack,
                                          yyposn));
              else if (yyflag == yyerr)
                {
                  YY_DPRINTF ((stderr, "Stack %ld dies.\n", YY_CAST (long, yynewStack)));
                  yymarkStackDeleted (yystackp, yynewStack);
                }
              else
                return yyflag;
            }

          if (yyisShiftAction (yyaction))
            break;
          else if (yyisErrorAction (yyaction))
            {
              YY_DPRINTF ((stderr, "Stack %ld dies.\n", YY_CAST (long, yyk)));
              yymarkStackDeleted (yystackp, yyk);
              break;
            }
          else
            {
              YYRESULTTAG yyflag = yyglrReduce (yystackp, yyk, -yyaction,
                                                yyimmediate[-yyaction]);
              if (yyflag == yyerr)
                {
                  YY_DPRINTF ((stderr,
                               "Stack %ld dies "
                               "(predicate failure or explicit user error).\n",
                               YY_CAST (long, yyk)));
                  yymarkStackDeleted (yystackp, yyk);
                  break;
                }
              else if (yyflag != yyok)
                return yyflag;
            }
        }
    }
  return yyok;
}






static void
yyreportSyntaxError (yyGLRStack* yystackp)
{
  if (yystackp->yyerrState != 0)
    return;
  yyerror (YY_("syntax error"));
  yynerrs += 1;
}

/* Recover from a syntax error on *YYSTACKP, assuming that *YYSTACKP->YYTOKENP,
   yylval, and yylloc are the syntactic category, semantic value, and location
   of the lookahead.  */
static void
yyrecoverSyntaxError (yyGLRStack* yystackp)
{
  if (yystackp->yyerrState == 3)
    /* We just shifted the error token and (perhaps) took some
       reductions.  Skip tokens until we can proceed.  */
    while (yytrue)
      {
        yysymbol_kind_t yytoken;
        int yyj;
        if (yychar == YYEOF)
          yyFail (yystackp, YY_NULLPTR);
        if (yychar != YYEMPTY)
          {
            /* We throw away the lookahead, but the error range
               of the shifted error token must take it into account.  */
            yyGLRState *yys = yystackp->yytops.yystates[0];
            yyGLRStackItem yyerror_range[3];
            yyerror_range[1].yystate.yyloc = yys->yyloc;
            yyerror_range[2].yystate.yyloc = yylloc;
            YYLLOC_DEFAULT ((yys->yyloc), yyerror_range, 2);
            yytoken = YYTRANSLATE (yychar);
            yydestruct ("Error: discarding",
                        yytoken, &yylval, &yylloc);
            yychar = YYEMPTY;
          }
        yytoken = yygetToken (&yychar);
        yyj = yypact[yystackp->yytops.yystates[0]->yylrState];
        if (yypact_value_is_default (yyj))
          return;
        yyj += yytoken;
        if (yyj < 0 || YYLAST < yyj || yycheck[yyj] != yytoken)
          {
            if (yydefact[yystackp->yytops.yystates[0]->yylrState] != 0)
              return;
          }
        else if (! yytable_value_is_error (yytable[yyj]))
          return;
      }

  /* Reduce to one stack.  */
  {
    YYPTRDIFF_T yyk;
    for (yyk = 0; yyk < yystackp->yytops.yysize; yyk += 1)
      if (yystackp->yytops.yystates[yyk] != YY_NULLPTR)
        break;
    if (yyk >= yystackp->yytops.yysize)
      yyFail (yystackp, YY_NULLPTR);
    for (yyk += 1; yyk < yystackp->yytops.yysize; yyk += 1)
      yymarkStackDeleted (yystackp, yyk);
    yyremoveDeletes (yystackp);
    yycompressStack (yystackp);
  }

  /* Pop stack until we find a state that shifts the error token.  */
  yystackp->yyerrState = 3;
  while (yystackp->yytops.yystates[0] != YY_NULLPTR)
    {
      yyGLRState *yys = yystackp->yytops.yystates[0];
      int yyj = yypact[yys->yylrState];
      if (! yypact_value_is_default (yyj))
        {
          yyj += YYSYMBOL_YYerror;
          if (0 <= yyj && yyj <= YYLAST && yycheck[yyj] == YYSYMBOL_YYerror
              && yyisShiftAction (yytable[yyj]))
            {
              /* Shift the error token.  */
              int yyaction = yytable[yyj];
              /* First adjust its location.*/
              YYLTYPE yyerrloc;
              yystackp->yyerror_range[2].yystate.yyloc = yylloc;
              YYLLOC_DEFAULT (yyerrloc, (yystackp->yyerror_range), 2);
              YY_SYMBOL_PRINT ("Shifting", yy_accessing_symbol (yyaction),
                               &yylval, &yyerrloc);
              yyglrShift (yystackp, 0, yyaction,
                          yys->yyposn, &yylval, &yyerrloc);
              yys = yystackp->yytops.yystates[0];
              break;
            }
        }
      yystackp->yyerror_range[1].yystate.yyloc = yys->yyloc;
      if (yys->yypred != YY_NULLPTR)
        yydestroyGLRState ("Error: popping", yys);
      yystackp->yytops.yystates[0] = yys->yypred;
      yystackp->yynextFree -= 1;
      yystackp->yyspaceLeft += 1;
    }
  if (yystackp->yytops.yystates[0] == YY_NULLPTR)
    yyFail (yystackp, YY_NULLPTR);
}

#define YYCHK1(YYE)                             \
  do {                                          \
    switch (YYE) {                              \
    case yyok:     break;                       \
    case yyabort:  goto yyabortlab;             \
    case yyaccept: goto yyacceptlab;            \
    case yyerr:    goto yyuser_error;           \
    case yynomem:  goto yyexhaustedlab;         \
    default:       goto yybuglab;               \
    }                                           \
  } while (0)

/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
  int yyresult;
  yyGLRStack yystack;
  yyGLRStack* const yystackp = &yystack;
  YYPTRDIFF_T yyposn;

  YY_DPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY;
  yylval = yyval_default;
  yylloc = yyloc_default;

  if (! yyinitGLRStack (yystackp, YYINITDEPTH))
    goto yyexhaustedlab;
  switch (YYSETJMP (yystack.yyexception_buffer))
    {
    case 0: break;
    case 1: goto yyabortlab;
    case 2: goto yyexhaustedlab;
    default: goto yybuglab;
    }
  yyglrShift (&yystack, 0, 0, 0, &yylval, &yylloc);
  yyposn = 0;

  while (yytrue)
    {
      /* For efficiency, we have two loops, the first of which is
         specialized to deterministic operation (single stack, no
         potential ambiguity).  */
      /* Standard mode. */
      while (yytrue)
        {
          yy_state_t yystate = yystack.yytops.yystates[0]->yylrState;
          YY_DPRINTF ((stderr, "Entering state %d\n", yystate));
          if (yystate == YYFINAL)
            goto yyacceptlab;
          if (yyisDefaultedState (yystate))
            {
              yyRuleNum yyrule = yydefaultAction (yystate);
              if (yyrule == 0)
                {
                  yystack.yyerror_range[1].yystate.yyloc = yylloc;
                  yyreportSyntaxError (&yystack);
                  goto yyuser_error;
                }
              YYCHK1 (yyglrReduce (&yystack, 0, yyrule, yytrue));
            }
          else
            {
              yysymbol_kind_t yytoken = yygetToken (&yychar);
              const short* yyconflicts;
              int yyaction = yygetLRActions (yystate, yytoken, &yyconflicts);
              if (*yyconflicts)
                /* Enter nondeterministic mode.  */
                break;
              if (yyisShiftAction (yyaction))
                {
                  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
                  yychar = YYEMPTY;
                  yyposn += 1;
                  yyglrShift (&yystack, 0, yyaction, yyposn, &yylval, &yylloc);
                  if (0 < yystack.yyerrState)
                    yystack.yyerrState -= 1;
                }
              else if (yyisErrorAction (yyaction))
                {
                  yystack.yyerror_range[1].yystate.yyloc = yylloc;
                  /* Issue an error message unless the scanner already
                     did. */
                  if (yychar != YYerror)
                    yyreportSyntaxError (&yystack);
                  goto yyuser_error;
                }
              else
                YYCHK1 (yyglrReduce (&yystack, 0, -yyaction, yytrue));
            }
        }

      /* Nondeterministic mode. */
      while (yytrue)
        {
          yysymbol_kind_t yytoken_to_shift;
          YYPTRDIFF_T yys;

          for (yys = 0; yys < yystack.yytops.yysize; yys += 1)
            yystackp->yytops.yylookaheadNeeds[yys] = yychar != YYEMPTY;

          /* yyprocessOneStack returns one of three things:

              - An error flag.  If the caller is yyprocessOneStack, it
                immediately returns as well.  When the caller is finally
                yyparse, it jumps to an error label via YYCHK1.

              - yyok, but yyprocessOneStack has invoked yymarkStackDeleted
                (&yystack, yys), which sets the top state of yys to NULL.  Thus,
                yyparse's following invocation of yyremoveDeletes will remove
                the stack.

              - yyok, when ready to shift a token.

             Except in the first case, yyparse will invoke yyremoveDeletes and
             then shift the next token onto all remaining stacks.  This
             synchronization of the shift (that is, after all preceding
             reductions on all stacks) helps prevent double destructor calls
             on yylval in the event of memory exhaustion.  */

          for (yys = 0; yys < yystack.yytops.yysize; yys += 1)
            YYCHK1 (yyprocessOneStack (&yystack, yys, yyposn));
          yyremoveDeletes (&yystack);
          if (yystack.yytops.yysize == 0)
            {
              yyundeleteLastStack (&yystack);
              if (yystack.yytops.yysize == 0)
                yyFail (&yystack, YY_("syntax error"));
              YYCHK1 (yyresolveStack (&yystack));
              YY_DPRINTF ((stderr, "Returning to deterministic operation.\n"));
              yystack.yyerror_range[1].yystate.yyloc = yylloc;
              yyreportSyntaxError (&yystack);
              goto yyuser_error;
            }

          /* If any yyglrShift call fails, it will fail after shifting.  Thus,
             a copy of yylval will already be on stack 0 in the event of a
             failure in the following loop.  Thus, yychar is set to YYEMPTY
             before the loop to make sure the user destructor for yylval isn't
             called twice.  */
          yytoken_to_shift = YYTRANSLATE (yychar);
          yychar = YYEMPTY;
          yyposn += 1;
          for (yys = 0; yys < yystack.yytops.yysize; yys += 1)
            {
              yy_state_t yystate = yystack.yytops.yystates[yys]->yylrState;
              const short* yyconflicts;
              int yyaction = yygetLRActions (yystate, yytoken_to_shift,
                              &yyconflicts);
              /* Note that yyconflicts were handled by yyprocessOneStack.  */
              YY_DPRINTF ((stderr, "On stack %ld, ", YY_CAST (long, yys)));
              YY_SYMBOL_PRINT ("shifting", yytoken_to_shift, &yylval, &yylloc);
              yyglrShift (&yystack, yys, yyaction, yyposn,
                          &yylval, &yylloc);
              YY_DPRINTF ((stderr, "Stack %ld now in state %d\n",
                           YY_CAST (long, yys),
                           yystack.yytops.yystates[yys]->yylrState));
            }

          if (yystack.yytops.yysize == 1)
            {
              YYCHK1 (yyresolveStack (&yystack));
              YY_DPRINTF ((stderr, "Returning to deterministic operation.\n"));
              yycompressStack (&yystack);
              break;
            }
        }
      continue;
    yyuser_error:
      yyrecoverSyntaxError (&yystack);
      yyposn = yystack.yytops.yystates[0]->yyposn;
    }

 yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;

 yybuglab:
  YY_ASSERT (yyfalse);
  goto yyabortlab;

 yyabortlab:
  yyresult = 1;
  goto yyreturnlab;

 yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;

 yyreturnlab:
  if (yychar != YYEMPTY)
    yydestruct ("Cleanup: discarding lookahead",
                YYTRANSLATE (yychar), &yylval, &yylloc);

  /* If the stack is well-formed, pop the stack until it is empty,
     destroying its entries as we go.  But free the stack regardless
     of whether it is well-formed.  */
  if (yystack.yyitems)
    {
      yyGLRState** yystates = yystack.yytops.yystates;
      if (yystates)
        {
          YYPTRDIFF_T yysize = yystack.yytops.yysize;
          YYPTRDIFF_T yyk;
          for (yyk = 0; yyk < yysize; yyk += 1)
            if (yystates[yyk])
              {
                while (yystates[yyk])
                  {
                    yyGLRState *yys = yystates[yyk];
                    yystack.yyerror_range[1].yystate.yyloc = yys->yyloc;
                    if (yys->yypred != YY_NULLPTR)
                      yydestroyGLRState ("Cleanup: popping", yys);
                    yystates[yyk] = yys->yypred;
                    yystack.yynextFree -= 1;
                    yystack.yyspaceLeft += 1;
                  }
                break;
              }
        }
      yyfreeGLRStack (&yystack);
    }

  return yyresult;
}

/* DEBUGGING ONLY */
#if YYDEBUG
/* Print *YYS and its predecessors. */
static void
yy_yypstack (yyGLRState* yys)
{
  if (yys->yypred)
    {
      yy_yypstack (yys->yypred);
      YY_FPRINTF ((stderr, " -> "));
    }
  YY_FPRINTF ((stderr, "%d@%ld", yys->yylrState, YY_CAST (long, yys->yyposn)));
}

/* Print YYS (possibly NULL) and its predecessors. */
static void
yypstates (yyGLRState* yys)
{
  if (yys == YY_NULLPTR)
    YY_FPRINTF ((stderr, "<null>"));
  else
    yy_yypstack (yys);
  YY_FPRINTF ((stderr, "\n"));
}

/* Print the stack #YYK.  */
static void
yypstack (yyGLRStack* yystackp, YYPTRDIFF_T yyk)
{
  yypstates (yystackp->yytops.yystates[yyk]);
}

/* Print all the stacks.  */
static void
yypdumpstack (yyGLRStack* yystackp)
{
#define YYINDEX(YYX)                                                    \
  YY_CAST (long,                                                        \
           ((YYX)                                                       \
            ? YY_REINTERPRET_CAST (yyGLRStackItem*, (YYX)) - yystackp->yyitems \
            : -1))

  yyGLRStackItem* yyp;
  for (yyp = yystackp->yyitems; yyp < yystackp->yynextFree; yyp += 1)
    {
      YY_FPRINTF ((stderr, "%3ld. ",
                   YY_CAST (long, yyp - yystackp->yyitems)));
      if (*YY_REINTERPRET_CAST (yybool *, yyp))
        {
          YY_ASSERT (yyp->yystate.yyisState);
          YY_ASSERT (yyp->yyoption.yyisState);
          YY_FPRINTF ((stderr, "Res: %d, LR State: %d, posn: %ld, pred: %ld",
                       yyp->yystate.yyresolved, yyp->yystate.yylrState,
                       YY_CAST (long, yyp->yystate.yyposn),
                       YYINDEX (yyp->yystate.yypred)));
          if (! yyp->yystate.yyresolved)
            YY_FPRINTF ((stderr, ", firstVal: %ld",
                         YYINDEX (yyp->yystate.yysemantics.yyfirstVal)));
        }
      else
        {
          YY_ASSERT (!yyp->yystate.yyisState);
          YY_ASSERT (!yyp->yyoption.yyisState);
          YY_FPRINTF ((stderr, "Option. rule: %d, state: %ld, next: %ld",
                       yyp->yyoption.yyrule - 1,
                       YYINDEX (yyp->yyoption.yystate),
                       YYINDEX (yyp->yyoption.yynext)));
        }
      YY_FPRINTF ((stderr, "\n"));
    }

  YY_FPRINTF ((stderr, "Tops:"));
  {
    YYPTRDIFF_T yyi;
    for (yyi = 0; yyi < yystackp->yytops.yysize; yyi += 1)
      YY_FPRINTF ((stderr, "%ld: %ld; ", YY_CAST (long, yyi),
                   YYINDEX (yystackp->yytops.yystates[yyi])));
    YY_FPRINTF ((stderr, "\n"));
  }
#undef YYINDEX
}
#endif

#undef yylval
#undef yychar
#undef yynerrs
#undef yylloc




#line 840 "src/parser.ypp"

