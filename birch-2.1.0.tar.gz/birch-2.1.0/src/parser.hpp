/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Skeleton interface for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2021 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_SRC_PARSER_HPP_INCLUDED
# define YY_YY_SRC_PARSER_HPP_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 1 "src/parser.ypp"

  #include "src/lexer.hpp"
  #include "src/build/Compiler.hpp"

#line 49 "src/parser.hpp"

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    PROGRAM = 258,                 /* PROGRAM  */
    CLASS = 259,                   /* CLASS  */
    STRUCT = 260,                  /* STRUCT  */
    TYPE = 261,                    /* TYPE  */
    FUNCTION = 262,                /* FUNCTION  */
    OPERATOR = 263,                /* OPERATOR  */
    AUTO = 264,                    /* AUTO  */
    LET = 265,                     /* LET  */
    IF = 266,                      /* IF  */
    ELSE = 267,                    /* ELSE  */
    FOR = 268,                     /* FOR  */
    IN = 269,                      /* IN  */
    WHILE = 270,                   /* WHILE  */
    DO = 271,                      /* DO  */
    WITH = 272,                    /* WITH  */
    ASSERT = 273,                  /* ASSERT  */
    RETURN = 274,                  /* RETURN  */
    FACTOR = 275,                  /* FACTOR  */
    PHANTOM = 276,                 /* PHANTOM  */
    CPP = 277,                     /* CPP  */
    HPP = 278,                     /* HPP  */
    THIS = 279,                    /* THIS  */
    SUPER = 280,                   /* SUPER  */
    GLOBAL = 281,                  /* GLOBAL  */
    PARALLEL = 282,                /* PARALLEL  */
    DYNAMIC = 283,                 /* DYNAMIC  */
    ABSTRACT = 284,                /* ABSTRACT  */
    OVERRIDE = 285,                /* OVERRIDE  */
    FINAL = 286,                   /* FINAL  */
    ACYCLIC = 287,                 /* ACYCLIC  */
    NIL = 288,                     /* NIL  */
    DOUBLE_BRACE_OPEN = 289,       /* DOUBLE_BRACE_OPEN  */
    DOUBLE_BRACE_CLOSE = 290,      /* DOUBLE_BRACE_CLOSE  */
    NAME = 291,                    /* NAME  */
    BOOL_LITERAL = 292,            /* BOOL_LITERAL  */
    INT_LITERAL = 293,             /* INT_LITERAL  */
    REAL_LITERAL = 294,            /* REAL_LITERAL  */
    STRING_LITERAL = 295,          /* STRING_LITERAL  */
    LEFT_OP = 296,                 /* LEFT_OP  */
    RIGHT_OP = 297,                /* RIGHT_OP  */
    LEFT_TILDE_OP = 298,           /* LEFT_TILDE_OP  */
    RIGHT_TILDE_OP = 299,          /* RIGHT_TILDE_OP  */
    LEFT_QUERY_OP = 300,           /* LEFT_QUERY_OP  */
    AND_OP = 301,                  /* AND_OP  */
    OR_OP = 302,                   /* OR_OP  */
    LE_OP = 303,                   /* LE_OP  */
    GE_OP = 304,                   /* GE_OP  */
    EQ_OP = 305,                   /* EQ_OP  */
    NE_OP = 306,                   /* NE_OP  */
    RANGE_OP = 307                 /* RANGE_OP  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 78 "src/parser.ypp"

  int32_t valInt;
  double valReal;
  const char* valString;
  
  birch::Annotation valAnnotation;
  birch::Name* valName;
  birch::Expression* valExpression;
  birch::Type* valType;
  birch::Statement* valStatement;

#line 130 "src/parser.hpp"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif


extern YYSTYPE yylval;
extern YYLTYPE yylloc;
int yyparse (void);

#endif /* !YY_YY_SRC_PARSER_HPP_INCLUDED  */
